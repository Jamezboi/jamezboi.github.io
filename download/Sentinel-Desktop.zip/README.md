Sentinel — desk-camera and desktop focus enforcement

Uses a desk-facing camera to detect a phone and checks the active desktop app
for distractions. The default desk mode does not start face, gaze, presence,
posture, or drowsiness tracking. It is designed for a camera pointed at the
desk, not at you.

Privacy (read this first)
All detection and training run locally. No face processing is used in desk
mode. In desk mode, the upper camera region is discarded before phone detection
or any other component receives a frame. Sentinel saves one local evidence image
only for a confirmed sustained phone or desktop-distraction violation. Images
are queued locally in `evidence/`; they are never
uploaded until an approved upload destination is configured.

SQLite stores scores, timestamps, window titles, evidence references, and the
apps you explicitly train as work or distractions.
Install & run
pip install -r requirements.txt
python main.py --doctor     # verify everything (run this first)
python main.py              # study session
python main.py --simulate   # 60s scripted session — see all 4 tiers safely
python main.py --dashboard  # open saved analytics at http://127.0.0.1:8765

macOS permissions (System Settings → Privacy & Security)
Camera (for the app/terminal), Screen Recording (mss), Accessibility(window titles). Linux: install tesseract-ocr + espeak for full features;xdotool for window titles. Wayland sessions: window titles may be unavailable —Sentinel degrades to screenshot/OCR classification.

Tuning
Everything is in config.yaml. Before studying, use the central Sentinel window
to enter your work goal. To train it, focus an app and choose “This is work”
or “This is distraction”; that decision persists in `sentinel.db` for future
sessions. Desktop classification priority is blacklist → whitelist → trained
app → configured patterns → OCR assist.

Chrome website blacklist (optional)

Set `browser.chrome_debug_enabled: true` in `config.yaml`, then launch Chrome
with `--remote-debugging-port=9222`. Sentinel reads only the active Chrome tab's
domain from Chrome's local debugging interface and matches it against
`browser.website_blacklist` or `browser.website_whitelist`. It does not use
browser history, an extension, or a remote service. Add your own domains to the
lists in `config.yaml`.

Dashboard

The live dashboard starts with a study session at `http://127.0.0.1:8765`. It
shows the score trajectory, state distribution, distraction sources, events,
evidence queue, training counts, and the 14-day distraction heatmap. Run
`python main.py --dashboard` to inspect saved analytics without turning on the
camera.

Notes & honest limitations
Phone detection uses YOLOv8n and requires `ultralytics`. Point the camera at
the desk and keep faces outside the frame. The 5–10s phone gray zone logs as a
glance with its duration recorded. Quit with “End session” or Ctrl+C. A session
report opens automatically.
