class BaseSentinel:
    """Contract for every Sentinel module. Constructed with the Arbiter hub;
    self-registers on the bus. Drop-in replaceable."""
    name = "base"
    def __init__(self, arbiter):
        self.arbiter = arbiter
        self.bus, self.cfg, self.db = arbiter.bus, arbiter.cfg, arbiter.db
    def start(self): pass
    def stop(self): pass
    def status(self): return {"name": self.name, "running": True}