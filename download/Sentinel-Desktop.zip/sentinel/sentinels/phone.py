import threading
import time
from .base import BaseSentinel


class PhoneSentinel(BaseSentinel):
    """Two redundant methods (spec 4.2):
      (A) YOLOv8n 'cell phone' detection on its own thread (optional dep)
      (B) hand-near-face (MediaPipe Hands) + strong down-gaze heuristic
    Episodes: <5s glance, >=10s sustained. 5–10s gray zone logged as glance
    with duration (documented in README)."""

    name = "phone"

    def __init__(self, arbiter):
        super().__init__(arbiter)
        g = lambda k, d: self.cfg.get(f"phone.{k}", d)
        self.glance_s, self.sustained_s = (
            g("glance_s", 5),
            g("sustained_s", 10),
        )
        self.debounce, self.quiet_s = g("debounce_s", 0.8), g("quiet_s", 3.0)
        self.gaze_min = self.cfg.get("gaze.phone_gaze_min", 0.45)
        self._raw_since = None
        self._last_raw_at = None
        self._active = False
        self._episode_start = None
        self._sustained_fired = False
        self._last_yolo = 0.0
        self._latest_confidence = 0.0
        self._phone_threshold = self.db.phone_threshold(g("yolo_confidence", 0.45))
        self._yolo_phone = False
        self._latest_frame = None
        self._yolo_seen = False
        self._model = None
        self._stop = threading.Event()
        mode = str(self.cfg.get("phone.yolo_enabled", "auto"))
        self._yolo_wanted = mode == "on" or (
            mode == "auto" and self._ultralytics_available()
        )
        if self._yolo_wanted and arbiter.camera:
            arbiter.camera.add_subscriber(self._grab_frame)
            self.thread = threading.Thread(
                target=self._yolo_loop, daemon=True, name="yolo"
            )
        else:
            self.thread = None
        self.bus.subscribe("obs", self._on_obs)

    @staticmethod
    def _ultralytics_available():
        try:
            import ultralytics

            return True
        except Exception:
            return False

    def _grab_frame(self, frame, t, luma):
        self._latest_frame = frame

    def _yolo_loop(self):
        try:
            from ultralytics import YOLO

            self._model = YOLO("yolov8n.pt")
        except Exception as e:
            self.db.log_event(
                "phone.yolo_unavailable",
                {"error": str(e)[:80]},
                source="phone",
            )
            self.bus.publish("warning.phone_detector_unavailable", {"detail": "Phone detection is unavailable: " + str(e)[:100]})
            return
        conf = min(self.cfg.get("phone.yolo_min_confidence", 0.10), self._phone_threshold)
        interval = self.cfg.get("phone.yolo_interval_s", 0.5)
        while not self._stop.is_set():
            f = self._latest_frame
            if f is not None:
                try:
                    r = self._model(
                        f, verbose=False, conf=conf, classes=[67]
                    )  # COCO: cell phone
                    boxes = r[0].boxes
                    self._latest_confidence = float(boxes.conf.max().item()) if len(boxes) else 0.0
                    self._yolo_phone = self._latest_confidence >= self._phone_threshold
                    self._last_yolo = time.time()
                    # Desk-camera mode deliberately has no face-pose pipeline,
                    # so YOLO drives phone episodes directly in that mode.
                    self._evaluate(self._yolo_phone, self._yolo_phone)
                except Exception:
                    pass
            time.sleep(interval)

    def _on_obs(self, o):
        heuristic = (
            bool(o.get("hand_near_face"))
            and o.get("gaze_v") is not None
            and o["gaze_v"] > self.gaze_min
        )
        now = time.time()
        yolo = self._yolo_phone and (now - self._last_yolo < 1.5)
        self._evaluate(yolo or heuristic, yolo)

    def _evaluate(self, raw, yolo):
        now = time.time()
        if yolo:
            self._yolo_seen = True
        if raw:
            if self._raw_since is None:
                self._raw_since = now
            self._last_raw_at = now
        if (
            not raw
            and self._raw_since is not None
            and now - (self._last_raw_at or self._raw_since) > self.quiet_s
        ):
            self._raw_since = None

        if (
            self._raw_since is not None
            and now - self._raw_since >= self.debounce
        ):
            if not self._active:
                self._active = True
                self._episode_start = now
                self._sustained_fired = False
                self._yolo_seen = yolo
                self.bus.publish(
                    "phone.active",
                    {
                        "active": True,
                        "method": "yolo" if yolo else "hands+gaze",
                    },
                )
            # A short quiet window avoids flicker from intermittent hand
            # tracking, but must not turn that quiet time into phone use.
            dur = (self._last_raw_at or now) - self._episode_start
            # With YOLO loaded, the hands+gaze heuristic alone (chin on hand
            # while reading!) can escalate only to a GLANCE — a sustained
            # violation requires at least one YOLO phone detection.
            need_yolo = self._model is not None and self.cfg.get(
                "phone.require_yolo_for_sustained", True
            )
            if (
                dur >= self.sustained_s
                and not self._sustained_fired
                and (not need_yolo or self._yolo_seen)
            ):
                self._sustained_fired = True
                self.bus.publish(
                    "phone.sustained",
                    {
                        "duration": round(dur, 1),
                        "method": "yolo" if self._yolo_seen else "hands+gaze",
                    },
                )
                if getattr(self.arbiter, "evidence", None):
                    self.arbiter.evidence.capture_desk("phone_sustained")
        elif self._active and self._raw_since is None:
            dur = max(0.0, (self._last_raw_at or now) - self._episode_start)
            self._active = False
            self.bus.publish("phone.active", {"active": False})
            if not self._sustained_fired:
                self.bus.publish(
                    "phone.glance",
                    {
                        "duration": round(dur, 1),
                        "heuristic_only": not self._yolo_seen,
                    },
                )
            self.db.log_event(
                "phone.episode_end",
                {
                    "duration": round(dur, 1),
                    "yolo_confirmed": self._yolo_seen,
                },
                source="phone",
            )

    def start(self):
        if self.thread:
            self.thread.start()

    def stop(self):
        self._stop.set()

    def train_current(self, is_phone):
        """Persist a yes/no label for the current desk-camera phone confidence."""
        self.db.train_phone(is_phone, self._latest_confidence)
        self._phone_threshold = self.db.phone_threshold(self.cfg.get("phone.yolo_confidence", 0.45))
        self.db.log_event("phone.training", {"is_phone": bool(is_phone),
                          "confidence": round(self._latest_confidence, 3),
                          "threshold": round(self._phone_threshold, 3)}, source="phone")
        return self._phone_threshold

    def status(self):
        return {
            "name": self.name,
            "active": self._active,
            "yolo": self._model is not None,
        }
