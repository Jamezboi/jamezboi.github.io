import time, threading
from collections import deque, Counter
from .base import BaseSentinel

class GazeSentinel(BaseSentinel):
    """Classifies PAPER / SCREEN / PHONE-look / AWAY / ABSENT from calibrated
    head pose + iris gaze. Rolling 5-frame majority vote (spec 4.1)."""
    name = "gaze"
    def __init__(self, arbiter):
        super().__init__(arbiter)
        self.baseline = None
        self._votes = deque(maxlen=int(self.cfg.get("gaze.smoothing_frames", 5)))
        self._current = "UNCALIBRATED"
        self.bus.subscribe("obs", self._on_obs)
        self.bus.subscribe("calibration.done", self._on_cal)

    def _on_cal(self, base): self.baseline = base

    def _classify(self, o):
        if not o.get("face"): return "ABSENT"
        if not self.baseline or o.get("low_light"): 
            return "UNCALIBRATED" if not self.baseline else self._current  # freeze in low light
        b = self.baseline["screen"]
        g = self.cfg
        pitch, yaw, gv = o.get("pitch"), o.get("yaw"), o.get("gaze_v")
        if pitch is None or yaw is None or b.get("pitch") is None: return self._current
        axis = self.baseline.get("paper_axis", 1.0)
        dp = axis * (pitch - b["pitch"])                      # + = toward paper
        dy = abs(yaw - (b.get("yaw") or 0.0))
        if dy > g.get("gaze.yaw_away_deg", 45): return "AWAY"
        if (g.get("gaze.paper_pitch_min", 10) <= dp <= g.get("gaze.paper_pitch_max", 55)
                and (gv is None or gv > g.get("gaze.gaze_down_min", 0.25))): return "PAPER"
        if gv is not None and gv > g.get("gaze.phone_gaze_min", 0.45) and dp > 3: return "PHONE"
        if abs(dp) <= g.get("gaze.screen_band_deg", 8) and dy <= g.get("gaze.screen_yaw_band_deg", 25):
            return "SCREEN"
        return "SCREEN"

    def _on_obs(self, o):
        raw = self._classify(o)
        self._votes.append(raw)
        winner, n = Counter(self._votes).most_common(1)[0]
        if n < max(2, len(self._votes) // 2 + 1): return       # no majority yet → hold
        if winner != self._current:
            self._current = winner
            self.bus.publish("gaze.state", {"class": winner})
            self.db.log_event("gaze.state", {"class": winner}, source="gaze")

    def start(self):
        self.bus.publish("gaze.state", {"class": self._current})
    def status(self):
        return {"name": self.name, "state": self._current, "calibrated": self.baseline is not None}