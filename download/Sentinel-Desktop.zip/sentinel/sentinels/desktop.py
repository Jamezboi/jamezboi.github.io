import time, random, threading, subprocess
from .base import BaseSentinel
from ..vision.classifiers import RuleBasedClassifier, LocalVisionClassifier, NEUTRAL

class DesktopSentinel(BaseSentinel):
    """Every interval±jitter: active window title (+process) + screenshot →
    swappable classifier → desktop.activity event. Screenshots stay in RAM
    unless privacy.store_screenshots (default false)."""
    name = "desktop"
    
    def __init__(self, arbiter):
        super().__init__(arbiter)
        self.rules = RuleBasedClassifier(self.cfg, self.db.activity_labels())
        self.clf = self.rules
        if self.cfg.get("desktop.vision_endpoint"):
            self.clf = LocalVisionClassifier(self.cfg, self.rules)
        self._ocr = None
        mode = str(self.cfg.get("desktop.ocr", "auto"))
        if mode in ("on", "auto"):
            try:
                import pytesseract
                pytesseract.get_tesseract_version()
                self._ocr = pytesseract
            except Exception:
                if mode == "on": 
                    self.db.log_event("desktop.ocr_missing", {}, source="desktop")
        self._stop = threading.Event()
        self._thread = threading.Thread(target=self._run, daemon=True, name="desktop")

    def reload_rules(self):
        """Re-compile rule classifier from current config and database training."""
        self.rules = RuleBasedClassifier(self.cfg, self.db.activity_labels())
        if self.cfg.get("desktop.vision_endpoint"):
            self.clf = LocalVisionClassifier(self.cfg, self.rules)
        else:
            self.clf = self.rules

    def inspect_current(self):
        """Inspect the active window without triggering violation alarms or evidence capture."""
        from ..utils import platform
        from ..utils.browser import active_chrome_domain
        title, proc = platform.active_window()
        domain = active_chrome_domain(title, proc, self.cfg)
        label, evidence = self.clf.classify(title, proc, "", None, browser_domain=domain)
        return {
            "title": title,
            "process": proc,
            "domain": domain,
            "label": label,
            "evidence": evidence,
            "classifier": type(self.clf).__name__,
        }

    def _shot(self):
        import numpy as np, cv2
        from ..utils.platform import mss_instance
        with mss_instance() as sct:
            idx = int(self.cfg.get("desktop.monitor_index", 1))
            mon = sct.monitors[min(idx, len(sct.monitors) - 1)]
            img = np.array(sct.grab(mon))[:, :, :3]
            return cv2.cvtColor(img, cv2.COLOR_BGR2RGB)

    def _run(self):
        while not self._stop.is_set():
            interval = self.cfg.get("desktop.interval_s", 20) + random.uniform(0, self.cfg.get("desktop.jitter_s", 6))
            self._stop.wait(interval)
            if self._stop.is_set(): 
                return
            self.run_once()

    def run_once(self):
        """Classify one screen sample; useful for deterministic diagnostics."""
        import cv2
        from ..utils import platform
        try:
            title, proc = platform.active_window()
            from ..utils.browser import active_chrome_domain
            domain = active_chrome_domain(title, proc, self.cfg)
            png = ocr_text = ""
            shot = self._shot()
            ok, buf = cv2.imencode(".png", shot, [cv2.IMWRITE_PNG_COMPRESSION, 6])
            if ok:
                png = buf.tobytes()
            if self._ocr is not None:
                small = cv2.resize(shot, (max(1, shot.shape[1] // 3), max(1, shot.shape[0] // 3)))
                try:
                    ocr_text = self._ocr.image_to_string(small)
                except Exception:
                    ocr_text = ""
            label, evidence = self.clf.classify(title, proc, ocr_text, png, browser_domain=domain)
            self.bus.publish("desktop.activity", {
                "label": label, "title": title, "process": proc, "domain": domain,
                "evidence": evidence, "method": type(self.clf).__name__
            })
            if label == "DISTRACTION" and getattr(self.arbiter, "evidence", None):
                self.arbiter.evidence.capture_desktop("desktop_distraction")
            return label, evidence
        except Exception as e:
            self.db.log_event("desktop.error", {"error": str(e)[:100]}, source="desktop")
            return None, f"error:{type(e).__name__}"

    def train_current(self, label):
        """Remember the user's classification of the currently focused app."""
        from ..utils import platform
        title, proc = platform.active_window()
        signature = self.db.train_activity(title, proc, label)
        self.rules.set_learned(self.db.activity_labels())
        self.db.log_event("desktop.training", {"label": str(label).upper(), "title": title, "process": proc}, source="desktop")
        return signature

    def start(self): 
        self._thread.start()
        
    def stop(self): 
        self._stop.set()
        
    def status(self): 
        return {
            "name": self.name, 
            "classifier": type(self.clf).__name__,
            "ocr": self._ocr is not None
        }
