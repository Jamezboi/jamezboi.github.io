import time
from .base import BaseSentinel

class PresenceSentinel(BaseSentinel):
    """LEFT FRAME only on SUSTAINED, RELIABLE absence. Frames we can't see
    (low light) never count toward absence — 'too dark to detect' is not
    evidence you left. A dead camera produces no obs → state freezes."""
    name = "presence"
    def __init__(self, arbiter):
        super().__init__(arbiter)
        self.grace = self.cfg.get("presence.grace_s", 8)
        self._absent_since = None; self._flagged = False; self._present = True
        self._dark_logged = 0
        self.bus.subscribe("obs", self._on_obs)

    def _on_obs(self, o):
        if o.get("low_light"):
            # Detection unreliable: don't accrue absence from frames we can't
            # see (the tamper plugin separately catches a covered/black lens).
            if self._absent_since and time.time() - self._dark_logged > 60:
                self._dark_logged = time.time()
                self.db.log_event("presence.suppressed_low_light",
                                  {"note": "absence timer paused: frame too dark"}, source="presence")
            return
        now = time.time()
        if o.get("face"):
            if self._absent_since is not None:
                dur = now - self._absent_since
                self._absent_since = None
                if self._flagged:
                    self._flagged = False
                    self.bus.publish("presence.returned", {"duration": round(dur, 1)})
                    self.db.log_event("presence.returned", {"duration": round(dur, 1)}, source="presence")
                elif dur > 2:
                    self.db.log_event("presence.lean", {"duration": round(dur, 1)}, source="presence")
            if not self._present:
                self._present = True
                self.bus.publish("presence.state", {"present": True})
            return
        if self._absent_since is None:
            self._absent_since = now
            self._present = False
            self.bus.publish("presence.state", {"present": False})
            return
        dur = now - self._absent_since
        if dur > self.grace and not self._flagged:
            self._flagged = True
            self.bus.publish("presence.absent", {"duration": round(dur, 1)})
            self.db.log_event("presence.absent", {"duration": round(dur, 1)}, source="presence")