import io, os, wave, sys, time, queue, threading, subprocess, tempfile, random
import numpy as np

PROCTOR_PHRASES = [
    "Eyes on the paper. Your future self is watching.",
    "We had an agreement. The books are still waiting.",
    "Discipline beats motivation. Sit up and get back to work.",
    "The feed will still scroll tomorrow. Your exam will not wait.",
    "I do not blink, and neither should your focus. Back to it.",
]

def synth_wav(freqs, duration, volume=0.6, sr=22050, fade=0.012):
    t = np.arange(int(sr * duration)) / sr
    sig = sum(np.sin(2 * np.pi * f * t) for f in freqs) / max(len(freqs), 1)
    env = np.ones_like(t); n = max(1, int(sr * fade))
    env[:n] = np.linspace(0, 1, n); env[-n:] = np.linspace(1, 0, n)
    data = (sig * env * volume * 32767).astype(np.int16)
    buf = io.BytesIO()
    with wave.open(buf, "wb") as w:
        w.setnchannels(1); w.setsampwidth(2); w.setframerate(sr); w.writeframes(data.tobytes())
    return buf.getvalue()

class Speaker(threading.Thread):
    """pyttsx3 in its own thread (runAndWait blocks). Never crashes the app."""
    def __init__(self, cfg):
        super().__init__(daemon=True); self.q = queue.Queue(); self.ok = False
        self.rate = cfg.get("audio.tts_rate", 165); self.voice = cfg.get("audio.tts_voice", "")
        self._used = []
    def run(self):
        try:
            import pyttsx3
            eng = pyttsx3.init(); eng.setProperty("rate", self.rate)
            if self.voice:
                for v in eng.getProperty("voices"):
                    if self.voice.lower() in str(getattr(v, "name", "")).lower():
                        eng.setProperty("voice", v.id); break
            self.ok = True
        except Exception:
            self.ok = False; return
        while True:
            msg = self.q.get()
            if msg is None: break
            try: eng.say(msg); eng.runAndWait()
            except Exception: pass
    def say(self, text): self.q.put(text)
    def proctor(self):
        unused = [p for p in PROCTOR_PHRASES if p not in self._used]
        if not unused: self._used = []
        phrase = random.choice(unused or PROCTOR_PHRASES)
        self._used.append(phrase); self.say(phrase)
    def shutdown(self): self.q.put(None)

class AudioEngine:
    """Offline audio: synthesized WAVs played via the platform player
    (winsound / afplay / paplay|aplay) + offline TTS. No network, no extra deps."""
    def __init__(self, cfg, db=None):
        self.cfg, self.db = cfg, db
        self.mute = bool(cfg.get("alerts.mute", False))
        self.vol = cfg.get("audio.volume", 0.7)
        self.speaker = Speaker(cfg); self.speaker.start()
        self._alarm_on = False
        self._alarm_thread = None
        self._tmp = tempfile.gettempdir(); self._n = 0
    def _path(self, wav):
        self._n += 1
        p = os.path.join(self._tmp, f"sentinel_tone_{os.getpid()}_{self._n}.wav")
        with open(p, "wb") as f: f.write(wav)
        return p
    def _play(self, wav):
        if self.mute: return
        try:
            if sys.platform == "win32":
                import winsound
                winsound.PlaySound(wav, winsound.SND_MEMORY | winsound.SND_ASYNC)
            else:
                p = self._path(wav)
                if sys.platform == "darwin":
                    subprocess.Popen(["afplay", p], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
                else:
                    for cmd in (["paplay"], ["aplay", "-q"],
                                ["ffplay", "-nodisp", "-autoexit", "-loglevel", "quiet"]):
                        if _which(cmd[0]):
                            subprocess.Popen(cmd + [p], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL); break
        except Exception:
            pass
    def beep(self, freq): self._play(synth_wav([freq], 0.12, self.vol))
    def chime(self):
        self._play(synth_wav([659.25], 0.16, self.vol * 0.8))
        threading.Timer(0.17, lambda: self._play(synth_wav([880.0], 0.22, self.vol * 0.8))).start()
    def warn(self, phrase="Attention: Distraction detected. Refocus immediately."):
        self.chime()
        if not self.mute and phrase:
            self.speak(phrase)
    def alarm_start(self):
        if self._alarm_on: return
        self._alarm_on = True
        self._alarm_thread = threading.Thread(target=self._alarm_loop, daemon=True)
        self._alarm_thread.start()
    def _alarm_loop(self):
        while self._alarm_on:
            self._play(synth_wav([880, 660], 0.35, min(self.vol + 0.2, 1.0)))
            time.sleep(0.12); self._play(synth_wav([880, 660], 0.35, min(self.vol + 0.2, 1.0)))
            time.sleep(0.55)
    def alarm_stop(self): self._alarm_on = False
    def speak(self, text):
        if not self.mute and self.speaker.ok: self.speaker.say(text)
    def speak_proctor(self):
        if not self.mute and self.speaker.ok: self.speaker.proctor()
    def shutdown(self):
        self.alarm_stop(); self.speaker.shutdown()
        for f in os.listdir(self._tmp):
            if f.startswith(f"sentinel_tone_{os.getpid()}"): 
                try: os.remove(os.path.join(self._tmp, f))
                except Exception: pass

def _which(b):
    from shutil import which; return which(b)