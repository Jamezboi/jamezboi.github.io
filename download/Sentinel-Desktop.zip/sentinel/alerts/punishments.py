"""Sentinel Serious Punishments & Tier Enforcement Engine.

Provides creative, configurable, and high-impact accountability punishments:
- App Slayer: Force terminate or gracefully close distracting applications/windows.
- Focus Commitment Pledge: Requires typing verbatim focus vows with anti-paste protection.
- Cognitive Math Reboot: Generates mental math equations to snap user out of dopamine haze.
- Mandatory Cooldown Lock: Locks acknowledgement for a configurable duration.
- Physical Reset Action: Enforces physical movement, posture realignment, or breathing pause.
- Instant Focus Score Tax: Deducts immediate penalty points upon tier escalation.
- Proctor-9 Audio Reprimands: Vocal condemnation of distractions.
All behaviors are toggleable and configurable per tier in settings and profiles.
"""
import logging
import random
import sys
import time
from typing import Any, Dict, Optional, Tuple

logger = logging.getLogger("sentinel.punishments")

PROTECTED_PROCESSES = {
    "explorer.exe",
    "python.exe",
    "pythonw.exe",
    "cmd.exe",
    "powershell.exe",
    "pwsh.exe",
    "dwm.exe",
    "taskmgr.exe",
    "services.exe",
    "lsass.exe",
    "csrss.exe",
    "smss.exe",
    "winlogon.exe",
    "system",
    "system idle process",
    "registry",
    "conhost.exe",
    "fontdrvhost.exe",
    "sentinel.exe",
}

DEFAULT_PLEDGES = [
    "I will not trade my long-term goals for short-term digital distractions.",
    "Deep focus is my competitive advantage. I choose discipline over instant gratification.",
    "My time and attention are non-negotiable. I return to my work right now.",
    "I refuse to let mindless browsing steal the future I am building.",
    "Action cures anxiety. I commit to staying in the arena and finishing my task.",
]

PHYSICAL_ACTIONS = [
    "Stand up, stretch your arms overhead, and take 3 slow diaphragmatic breaths.",
    "Roll your shoulders backwards 5 times, sit up straight, and unclench your jaw.",
    "Drink a sip of water, look away from all screens 20 feet away, and reset.",
]


class PunishmentManager:
    """Manages and executes tiered punishments, challenges, and enforcement."""

    def __init__(self, cfg, db, arbiter=None, audio=None):
        self.cfg = cfg
        self.db = db
        self.arbiter = arbiter
        self.audio = audio

    def is_enabled(self) -> bool:
        """Check if punishment system is enabled overall."""
        return bool(self.cfg.get("punishments.enabled", True))

    def get_tier_config(self, tier: int) -> Dict[str, Any]:
        """Return punishment configuration dictionary for a given tier (1, 2, 3, 4)."""
        defaults = {
            1: {
                "toast_nudge": True,
                "score_tax": 0,
            },
            2: {
                "toast_warning": True,
                "chime": True,
                "minimize_app": False,
                "score_tax": 0,
            },
            3: {
                "countdown_modal": True,
                "minimize_app": True,
                "kill_app": False,
                "typing_challenge": True,
                "math_challenge": False,
                "lock_seconds": 5,
                "score_tax": 10,
                "physical_action": False,
            },
            4: {
                "alarm_sound": True,
                "proctor_drill": True,
                "kill_app": True,
                "minimize_app": False,
                "typing_challenge": True,
                "math_challenge": True,
                "lock_seconds": 12,
                "score_tax": 25,
                "physical_action": True,
            },
        }
        tier_cfg = self.cfg.get(f"punishments.tier{tier}", {})
        merged = dict(defaults.get(tier, {}))
        if isinstance(tier_cfg, dict):
            merged.update(tier_cfg)
        return merged

    def generate_math_challenge(self, difficulty: str = "medium") -> Dict[str, Any]:
        """Generate a mental arithmetic challenge with varying complexity."""
        diff = (difficulty or "medium").lower()
        if diff == "easy":
            ops = ["+", "-"]
            op = random.choice(ops)
            if op == "+":
                a = random.randint(15, 60)
                b = random.randint(12, 45)
                return {"question": f"{a} + {b}", "answer": a + b, "difficulty": diff}
            else:
                a = random.randint(35, 95)
                b = random.randint(11, a - 5)
                return {"question": f"{a} - {b}", "answer": a - b, "difficulty": diff}

        elif diff == "hard":
            pattern = random.choice([1, 2, 3])
            if pattern == 1:
                a = random.randint(12, 22)
                b = random.randint(11, 19)
                c = random.randint(15, 85)
                return {"question": f"({a} × {b}) - {c}", "answer": (a * b) - c, "difficulty": diff}
            elif pattern == 2:
                a = random.randint(14, 25)
                b = random.randint(6, 12)
                c = random.randint(25, 90)
                return {"question": f"({a} × {b}) + {c}", "answer": (a * b) + c, "difficulty": diff}
            else:
                a = random.randint(11, 16)
                b = random.randint(11, 16)
                c = random.randint(11, 16)
                return {"question": f"({a} × {b}) + ({c} × 4)", "answer": (a * b) + (c * 4), "difficulty": diff}

        else:  # medium
            pattern = random.choice([1, 2, 3])
            if pattern == 1:
                a = random.randint(6, 12)
                b = random.randint(7, 14)
                c = random.randint(11, 35)
                return {"question": f"{a} × {b} - {c}", "answer": (a * b) - c, "difficulty": diff}
            elif pattern == 2:
                a = random.randint(15, 45)
                b = random.randint(15, 45)
                c = random.randint(2, 4)
                return {"question": f"({a} + {b}) × {c}", "answer": (a + b) * c, "difficulty": diff}
            else:
                a = random.randint(8, 15)
                b = random.randint(7, 12)
                c = random.randint(15, 50)
                return {"question": f"({a} × {b}) + {c}", "answer": (a * b) + c, "difficulty": diff}

    def get_typing_pledge(self) -> str:
        """Get the active typing pledge sentence."""
        configured = self.cfg.get("punishments.typing_pledge")
        if configured and str(configured).strip():
            return str(configured).strip()
        return DEFAULT_PLEDGES[0]

    def get_physical_action_text(self) -> str:
        """Get a physical action reset prompt."""
        custom = self.cfg.get("punishments.physical_action_text")
        if custom and str(custom).strip():
            return str(custom).strip()
        return random.choice(PHYSICAL_ACTIONS)

    def find_target_distraction(self, last_desktop: Optional[Dict[str, Any]] = None) -> Tuple[Optional[int], str, str]:
        """Locate PID, process name, and window title of the target distraction."""
        from sentinel.utils import platform as plat
        active_title, active_proc = plat.active_window()
        last_desktop = last_desktop or {}
        target_proc = last_desktop.get("process") or active_proc
        target_title = last_desktop.get("title") or active_title
        target_pid = last_desktop.get("pid")

        if not target_pid and target_proc:
            try:
                import psutil
                for p in psutil.process_iter(["pid", "name"]):
                    if p.info["name"] and p.info["name"].lower() == target_proc.lower():
                        target_pid = p.info["pid"]
                        break
            except Exception:
                pass

        return target_pid, target_proc or "Unknown", target_title or "Distraction"

    def execute_app_punishment(
        self,
        mode: str,
        last_desktop: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """Execute app slay/minimize action on the offending window or process."""
        pid, proc_name, title = self.find_target_distraction(last_desktop)
        result = {
            "mode": mode,
            "target_pid": pid,
            "target_proc": proc_name,
            "target_title": title,
            "success": False,
            "message": "",
        }

        # Safety Guard: Never kill protected system critical processes
        if proc_name.lower() in PROTECTED_PROCESSES:
            msg = f"Safety bypass: protected system process '{proc_name}' will not be terminated."
            logger.warning(msg)
            result["message"] = msg
            return result

        if mode == "minimize":
            try:
                if sys.platform == "win32":
                    import ctypes
                    user32 = ctypes.windll.user32
                    hwnd = user32.GetForegroundWindow()
                    if hwnd:
                        user32.ShowWindow(hwnd, 6)  # SW_MINIMIZE
                        result["success"] = True
                        result["message"] = f"Minimized window '{title[:35]}'"
                else:
                    result["message"] = "Minimize only supported on Windows"
            except Exception as exc:
                result["message"] = f"Minimize error: {exc}"

        elif mode in ("terminate", "kill"):
            try:
                if pid:
                    import psutil
                    proc = psutil.Process(pid)
                    proc.terminate()
                    result["success"] = True
                    result["message"] = f"Terminated distracting process '{proc_name}' (PID {pid})"
                elif sys.platform == "win32":
                    # Fallback to closing foreground window via WM_CLOSE
                    import ctypes
                    hwnd = ctypes.windll.user32.GetForegroundWindow()
                    if hwnd:
                        ctypes.windll.user32.PostMessageW(hwnd, 0x0010, 0, 0)  # WM_CLOSE
                        result["success"] = True
                        result["message"] = f"Closed window '{title[:35]}'"
            except Exception as exc:
                result["message"] = f"Terminate error: {exc}"

        elif mode == "close_window":
            try:
                if sys.platform == "win32":
                    import ctypes
                    hwnd = ctypes.windll.user32.GetForegroundWindow()
                    if hwnd:
                        ctypes.windll.user32.PostMessageW(hwnd, 0x0010, 0, 0)
                        result["success"] = True
                        result["message"] = f"Closed active window '{title[:35]}'"
            except Exception as exc:
                result["message"] = f"Close window error: {exc}"

        if result["success"]:
            self.db.log_event("alert.punishment.app_action", result, source="punishments")
        return result

    def prepare_and_apply(
        self,
        tier: int,
        snap: Dict[str, Any],
        last_desktop: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """Execute immediate consequences (app slaying, score tax) and assemble challenge parameters."""
        if not self.is_enabled():
            return {"enabled": False}

        cfg = self.get_tier_config(tier)
        result: Dict[str, Any] = {
            "tier": tier,
            "enabled": True,
            "actions_executed": [],
            "score_tax": 0,
            "typing_challenge": bool(cfg.get("typing_challenge", False)),
            "math_challenge": bool(cfg.get("math_challenge", False)),
            "lock_seconds": int(cfg.get("lock_seconds", 0)),
            "physical_action": bool(cfg.get("physical_action", False)),
            "proctor_drill": bool(cfg.get("proctor_drill", False)),
            "summary_badge": "",
        }

        # 1. Instant Score Tax
        tax = int(cfg.get("score_tax", 0))
        if tax > 0 and self.arbiter:
            try:
                self.arbiter.apply_penalty(-abs(tax), f"punishment_tax_tier{tier}")
                result["score_tax"] = tax
                result["actions_executed"].append(f"Score Tax: -{tax} pts")
            except Exception as exc:
                logger.error(f"Failed applying score tax: {exc}")

        # 2. App Action (Kill or Minimize)
        kill_mode = self.cfg.get("punishments.kill_mode", "terminate")
        app_res = None
        if cfg.get("kill_app", False):
            app_res = self.execute_app_punishment(kill_mode, last_desktop)
            if app_res.get("success"):
                result["actions_executed"].append(app_res.get("message", "App closed"))
                result["app_killed"] = app_res.get("target_proc")
        elif cfg.get("minimize_app", False):
            app_res = self.execute_app_punishment("minimize", last_desktop)
            if app_res.get("success"):
                result["actions_executed"].append(app_res.get("message", "App minimized"))
                result["app_minimized"] = True

        # 3. Assemble challenges
        if result["typing_challenge"]:
            result["typing_pledge"] = self.get_typing_pledge()

        if result["math_challenge"]:
            difficulty = self.cfg.get("punishments.math_difficulty", "medium")
            result["math_data"] = self.generate_math_challenge(difficulty)

        if result["physical_action"]:
            result["physical_action_text"] = self.get_physical_action_text()

        # Build summary badge
        if result["actions_executed"]:
            result["summary_badge"] = " · ".join(result["actions_executed"])

        self.db.log_event(
            "alert.punishment.prepared",
            {
                "tier": tier,
                "tax": result["score_tax"],
                "actions": result["actions_executed"],
                "lock_s": result["lock_seconds"],
                "challenges": [k for k in ["typing_challenge", "math_challenge", "physical_action"] if result.get(k)],
            },
            source="punishments",
        )
        return result
