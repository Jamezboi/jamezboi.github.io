import collections
import csv
import datetime
import http.server
import io
import json
import os
import re
import socketserver
import threading
import urllib.parse
from sentinel.core.profiles import (
    list_profiles,
    get_profile,
    apply_profile,
    save_custom_profile,
    delete_custom_profile,
    deep_merge,
)
from sentinel.core.plugins import list_available_plugins, toggle_plugin

_HTML_PAGE = """<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Sentinel | Control Center & Interactive Settings</title>
<style>
:root {
  --bg: #070e1c;
  --bg-surface: #0f1b2f;
  --bg-card: #14243d;
  --bg-card-hover: #192e4e;
  --border: #21375a;
  --border-focus: #3b82f6;
  --text: #f1f5f9;
  --text-muted: #94a3b8;
  --text-dim: #64748b;
  --primary: #38bdf8;
  --primary-hover: #0284c7;
  --accent: #2563eb;
  --success: #10b981;
  --warning: #f59e0b;
  --danger: #ef4444;
  --purple: #a855f7;
  --radius: 10px;
}
* { box-sizing: border-box; margin: 0; padding: 0; }
body {
  font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
  background: var(--bg);
  color: var(--text);
  line-height: 1.5;
  min-height: 100vh;
  display: flex;
  flex-direction: column;
}
/* Header */
header {
  background: var(--bg-surface);
  border-bottom: 1px solid var(--border);
  padding: 12px 28px;
  display: flex;
  align-items: center;
  justify-content: space-between;
  position: sticky;
  top: 0;
  z-index: 100;
}
.brand {
  display: flex;
  align-items: center;
  gap: 14px;
}
.brand-logo {
  width: 40px;
  height: 40px;
  border-radius: 50%;
  background: linear-gradient(135deg, #2563eb, #38bdf8);
  display: flex;
  align-items: center;
  justify-content: center;
  font-weight: 800;
  font-size: 20px;
  color: #fff;
  box-shadow: 0 0 16px rgba(56, 189, 248, 0.35);
}
.brand-titles h1 {
  font-size: 17px;
  font-weight: 700;
  letter-spacing: 0.5px;
}
.brand-titles p {
  font-size: 11px;
  color: var(--text-muted);
}
.header-actions {
  display: flex;
  align-items: center;
  gap: 14px;
}
.status-pill {
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 5px 12px;
  border-radius: 20px;
  background: rgba(16, 185, 129, 0.12);
  border: 1px solid rgba(16, 185, 129, 0.3);
  color: #34d399;
  font-size: 12px;
  font-weight: 600;
}
.pulse-dot {
  width: 8px;
  height: 8px;
  border-radius: 50%;
  background: #10b981;
  box-shadow: 0 0 8px #10b981;
  animation: pulse 2s infinite;
}
@keyframes pulse {
  0% { transform: scale(0.95); box-shadow: 0 0 0 0 rgba(16, 185, 129, 0.7); }
  70% { transform: scale(1); box-shadow: 0 0 0 8px rgba(16, 185, 129, 0); }
  100% { transform: scale(0.95); box-shadow: 0 0 0 0 rgba(16, 185, 129, 0); }
}
.profile-pill {
  display: flex;
  align-items: center;
  gap: 8px;
  background: var(--bg-card);
  border: 1px solid var(--border);
  padding: 6px 14px;
  border-radius: 20px;
  font-size: 12px;
  font-weight: 600;
  color: var(--primary);
  cursor: pointer;
  transition: all 0.2s;
}
.profile-pill:hover {
  border-color: var(--primary);
  background: var(--bg-card-hover);
}

/* Nav Tabs */
nav.tabs {
  background: var(--bg-surface);
  border-bottom: 1px solid var(--border);
  padding: 0 28px;
  display: flex;
  gap: 8px;
  overflow-x: auto;
}
.tab-btn {
  background: none;
  border: none;
  color: var(--text-muted);
  font-size: 13px;
  font-weight: 600;
  padding: 14px 16px;
  cursor: pointer;
  display: flex;
  align-items: center;
  gap: 8px;
  border-bottom: 2px solid transparent;
  transition: all 0.15s;
  white-space: nowrap;
}
.tab-btn:hover {
  color: var(--text);
}
.tab-btn.active {
  color: var(--primary);
  border-bottom-color: var(--primary);
}

/* Layout */
main {
  flex: 1;
  padding: 24px 28px;
  max-width: 1440px;
  margin: 0 auto;
  width: 100%;
}
.tab-pane {
  display: none;
}
.tab-pane.active {
  display: block;
  animation: fadeIn 0.2s ease-in-out;
}
@keyframes fadeIn {
  from { opacity: 0; transform: translateY(3px); }
  to { opacity: 1; transform: translateY(0); }
}

/* Cards & Grid */
.grid-2 { display: grid; grid-template-columns: 1fr 1fr; gap: 20px; }
.grid-3 { display: grid; grid-template-columns: repeat(3, 1fr); gap: 20px; }
.grid-4 { display: grid; grid-template-columns: repeat(auto-fill, minmax(280px, 1fr)); gap: 18px; }
@media (max-width: 1024px) {
  .grid-2, .grid-3 { grid-template-columns: 1fr; }
}

.card {
  background: var(--bg-card);
  border: 1px solid var(--border);
  border-radius: var(--radius);
  padding: 20px;
  margin-bottom: 20px;
  position: relative;
}
.card-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  margin-bottom: 16px;
  padding-bottom: 12px;
  border-bottom: 1px solid rgba(255, 255, 255, 0.06);
}
.card-title {
  font-size: 15px;
  font-weight: 700;
  color: var(--text);
  display: flex;
  align-items: center;
  gap: 8px;
}
.card-desc {
  font-size: 12px;
  color: var(--text-muted);
  margin-top: 2px;
}

/* Buttons */
.btn {
  background: var(--bg-surface);
  color: var(--text);
  border: 1px solid var(--border);
  padding: 8px 14px;
  border-radius: 6px;
  font-size: 13px;
  font-weight: 600;
  cursor: pointer;
  display: inline-flex;
  align-items: center;
  gap: 6px;
  transition: all 0.15s;
}
.btn:hover {
  background: var(--bg-card-hover);
  border-color: var(--text-muted);
}
.btn-primary {
  background: #2563eb;
  border-color: #3b82f6;
  color: #fff;
}
.btn-primary:hover {
  background: #1d4ed8;
  box-shadow: 0 0 12px rgba(37, 99, 235, 0.4);
}
.btn-success {
  background: #059669;
  border-color: #10b981;
  color: #fff;
}
.btn-success:hover {
  background: #047857;
}
.btn-danger {
  background: #dc2626;
  border-color: #ef4444;
  color: #fff;
}
.btn-danger:hover {
  background: #b91c1c;
}
.btn-sm {
  padding: 4px 10px;
  font-size: 12px;
}

/* Forms & Inputs */
.form-group {
  margin-bottom: 16px;
}
.form-label {
  display: block;
  font-size: 12px;
  font-weight: 600;
  color: var(--text-muted);
  margin-bottom: 6px;
}
.form-input, .form-select, textarea {
  width: 100%;
  background: #0a1424;
  border: 1px solid var(--border);
  border-radius: 6px;
  padding: 8px 12px;
  color: var(--text);
  font-size: 13px;
  font-family: inherit;
  transition: border-color 0.15s;
}
.form-input:focus, .form-select:focus, textarea:focus {
  outline: none;
  border-color: var(--border-focus);
  box-shadow: 0 0 0 2px rgba(59, 130, 246, 0.2);
}
.range-wrap {
  display: flex;
  align-items: center;
  gap: 14px;
}
.range-wrap input[type=range] {
  flex: 1;
  accent-color: var(--primary);
}
.range-val {
  font-size: 13px;
  font-weight: 700;
  color: var(--primary);
  min-width: 50px;
  text-align: right;
}

/* Chips / Tag Manager */
.chips-box {
  display: flex;
  flex-wrap: wrap;
  gap: 6px;
  background: #0a1424;
  border: 1px solid var(--border);
  border-radius: 6px;
  padding: 8px;
  min-height: 48px;
  align-items: center;
}
.chip {
  background: rgba(56, 189, 248, 0.12);
  border: 1px solid rgba(56, 189, 248, 0.3);
  color: #7dd3fc;
  font-size: 12px;
  padding: 3px 8px;
  border-radius: 14px;
  display: inline-flex;
  align-items: center;
  gap: 6px;
}
.chip.distract {
  background: rgba(239, 68, 68, 0.12);
  border-color: rgba(239, 68, 68, 0.3);
  color: #fca5a5;
}
.chip.neutral {
  background: rgba(148, 163, 184, 0.12);
  border-color: rgba(148, 163, 184, 0.3);
  color: #cbd5e1;
}
.chip-del {
  cursor: pointer;
  color: var(--text-muted);
  font-weight: bold;
}
.chip-del:hover {
  color: #fff;
}
.chip-add-form {
  display: flex;
  gap: 8px;
  margin-top: 8px;
}

/* Profile Cards */
.profile-card {
  background: var(--bg-card);
  border: 1px solid var(--border);
  border-radius: var(--radius);
  padding: 18px;
  cursor: pointer;
  transition: all 0.2s;
  display: flex;
  flex-direction: column;
  justify-content: space-between;
}
.profile-card:hover {
  border-color: var(--text-muted);
  transform: translateY(-2px);
}
.profile-card.active {
  border-color: var(--primary);
  background: linear-gradient(180deg, rgba(56, 189, 248, 0.08) 0%, var(--bg-card) 100%);
  box-shadow: 0 0 16px rgba(56, 189, 248, 0.15);
}
.badge {
  display: inline-block;
  padding: 2px 8px;
  border-radius: 10px;
  font-size: 11px;
  font-weight: 700;
  text-transform: uppercase;
}
.badge-study { background: rgba(16, 185, 129, 0.15); color: #34d399; border: 1px solid rgba(16, 185, 129, 0.3); }
.badge-distract { background: rgba(239, 68, 68, 0.15); color: #f87171; border: 1px solid rgba(239, 68, 68, 0.3); }
.badge-neutral { background: rgba(148, 163, 184, 0.15); color: #cbd5e1; border: 1px solid rgba(148, 163, 184, 0.3); }

/* Plugin Cards */
.plugin-card {
  background: var(--bg-card);
  border: 1px solid var(--border);
  border-radius: var(--radius);
  padding: 18px;
  display: flex;
  flex-direction: column;
  justify-content: space-between;
}
.plugin-header {
  display: flex;
  align-items: flex-start;
  justify-content: space-between;
  margin-bottom: 12px;
}
.switch {
  position: relative;
  display: inline-block;
  width: 44px;
  height: 24px;
}
.switch input { opacity: 0; width: 0; height: 0; }
.slider {
  position: absolute; cursor: pointer; top: 0; left: 0; right: 0; bottom: 0;
  background-color: #1e293b;
  transition: .3s;
  border-radius: 24px;
  border: 1px solid var(--border);
}
.slider:before {
  position: absolute; content: ""; height: 16px; width: 16px; left: 3px; bottom: 3px;
  background-color: white;
  transition: .3s;
  border-radius: 50%;
}
input:checked + .slider { background-color: #10b981; border-color: #10b981; }
input:checked + .slider:before { transform: translateX(20px); }

/* Tables */
.table-wrap {
  overflow-x: auto;
}
table {
  width: 100%;
  border-collapse: collapse;
  font-size: 13px;
}
th, td {
  text-align: left;
  padding: 10px 12px;
  border-bottom: 1px solid var(--border);
}
th {
  background: rgba(15, 27, 47, 0.7);
  color: var(--text-muted);
  font-weight: 600;
  font-size: 12px;
}
tr:hover td {
  background: rgba(255, 255, 255, 0.02);
}

/* Toast */
#toast {
  position: fixed;
  bottom: 24px;
  right: 24px;
  padding: 12px 20px;
  background: #1e293b;
  color: #fff;
  border-radius: 8px;
  border: 1px solid var(--border);
  box-shadow: 0 10px 25px rgba(0, 0, 0, 0.5);
  font-size: 13px;
  font-weight: 600;
  display: none;
  z-index: 999;
  align-items: center;
  gap: 10px;
}

/* Modal */
.modal-overlay {
  position: fixed;
  top: 0; left: 0; right: 0; bottom: 0;
  background: rgba(0, 0, 0, 0.75);
  backdrop-filter: blur(4px);
  display: none;
  align-items: center;
  justify-content: center;
  z-index: 500;
}
.modal {
  background: var(--bg-surface);
  border: 1px solid var(--border);
  border-radius: var(--radius);
  max-width: 600px;
  width: 90%;
  max-height: 85vh;
  display: flex;
  flex-direction: column;
}
.modal-head {
  padding: 16px 20px;
  border-bottom: 1px solid var(--border);
  display: flex;
  justify-content: space-between;
  align-items: center;
}
.modal-body {
  padding: 20px;
  overflow-y: auto;
}
.modal-foot {
  padding: 14px 20px;
  border-top: 1px solid var(--border);
  display: flex;
  justify-content: flex-end;
  gap: 10px;
}

/* Heatmap */
.hm-cell { width: 18px; height: 18px; border-radius: 2px; background: #162438; }
.hm-1 { background: #3b82f6; }
.hm-2 { background: #f59e0b; }
.hm-3 { background: #ef4444; }

/* Sticky save bar */
.save-banner {
  background: #1e3a8a;
  border-top: 1px solid #3b82f6;
  padding: 10px 28px;
  display: none;
  justify-content: space-between;
  align-items: center;
  position: sticky;
  bottom: 0;
  z-index: 90;
}
</style>
</head>
<body>

<header>
  <div class="brand">
    <div class="brand-logo">S</div>
    <div class="brand-titles">
      <h1>SENTINEL FOCUS CONSOLE</h1>
      <p>Interactive Desktop Analysis & Profile Suite</p>
    </div>
  </div>
  <div class="header-actions">
    <div class="status-pill">
      <div class="pulse-dot"></div>
      <span id="header_status">ENGINE CONNECTED</span>
    </div>
    <div class="profile-pill" onclick="switchTab('profiles')">
      <span>Profile:</span>
      <b id="header_profile_name">Deep Work</b>
      <span>▼</span>
    </div>
    <button class="btn btn-primary btn-sm" onclick="saveAllConfig()">💾 Save Changes</button>
  </div>
</header>

<nav class="tabs">
  <button class="tab-btn active" onclick="switchTab('desktop')">🖥️ Desktop Analysis & Rules</button>
  <button class="tab-btn" onclick="switchTab('profiles')">🎛️ Profiles & Presets</button>
  <button class="tab-btn" onclick="switchTab('severity')">⚖️ Severity & Scoring</button>
  <button class="tab-btn" onclick="switchTab('punishments')">⚡ Serious Punishments</button>
  <button class="tab-btn" onclick="switchTab('logs')">📜 Historical Logs & Time Travel</button>
  <button class="tab-btn" onclick="switchTab('plugins')">🧩 Plugins Activation</button>
  <button class="tab-btn" onclick="switchTab('overview')">📊 Live Monitor & Stats</button>
  <button class="tab-btn" onclick="switchTab('diagnostics')">🩺 Diagnostics</button>
</nav>

<main>
  <!-- TAB 1: DESKTOP ANALYSIS & RULES -->
  <div id="tab_desktop" class="tab-pane active">
    <div class="grid-2">
      <!-- Live Window Inspector -->
      <div class="card">
        <div class="card-header">
          <div>
            <div class="card-title">🔍 Live Active Window Inspector</div>
            <div class="card-desc">Query the foreground desktop window and test classification in real-time.</div>
          </div>
          <button class="btn btn-primary btn-sm" onclick="inspectActiveWindow()">⚡ Inspect Now</button>
        </div>
        <div id="inspect_result" style="background:#0a1424; border:1px solid var(--border); border-radius:6px; padding:14px; min-height:120px;">
          <p style="color:var(--text-muted); font-size:13px;">Click <b>Inspect Now</b> to capture active window title, process, domain, and classification.</p>
        </div>
        <div style="margin-top:14px; display:flex; gap:8px;" id="inspect_actions">
          <button class="btn btn-success btn-sm" onclick="trainActive('STUDY')" id="btn_train_study" disabled>✓ Mark as Work (Study)</button>
          <button class="btn btn-danger btn-sm" onclick="trainActive('DISTRACTION')" id="btn_train_distract" disabled>✕ Mark as Distraction</button>
        </div>
      </div>

      <!-- Regex & Rule Sandbox -->
      <div class="card">
        <div class="card-header">
          <div>
            <div class="card-title">🧪 Live Rule Sandbox</div>
            <div class="card-desc">Simulate arbitrary window titles, processes, or URLs against your active rule chain.</div>
          </div>
          <button class="btn btn-sm" onclick="runSandboxTest()">Run Test</button>
        </div>
        <div style="display:grid; grid-template-columns:1fr 1fr; gap:10px;">
          <div class="form-group">
            <label class="form-label">Window Title</label>
            <input type="text" id="sb_title" class="form-input" placeholder="e.g. Research Paper - arXiv" value="Python Documentation">
          </div>
          <div class="form-group">
            <label class="form-label">Process Name</label>
            <input type="text" id="sb_proc" class="form-input" placeholder="e.g. chrome.exe" value="chrome.exe">
          </div>
        </div>
        <div class="form-group">
          <label class="form-label">Browser Domain (optional)</label>
          <input type="text" id="sb_domain" class="form-input" placeholder="e.g. docs.python.org" value="docs.python.org">
        </div>
        <div id="sb_verdict" style="margin-top:8px; padding:10px 14px; border-radius:6px; background:#0a1424; border:1px solid var(--border); font-size:13px;">
          Enter sample values above and test matches.
        </div>
      </div>
    </div>

    <!-- Engine Tuning Parameters -->
    <div class="card">
      <div class="card-header">
        <div>
          <div class="card-title">⚙️ Desktop Sampling Engine Settings</div>
          <div class="card-desc">Tune polling frequency, jitter, monitor capture, and vision intelligence.</div>
        </div>
      </div>
      <div class="grid-3">
        <div class="form-group">
          <label class="form-label">Check Interval (seconds)</label>
          <div class="range-wrap">
            <input type="range" id="desktop_interval_s" min="3" max="60" value="10" oninput="markDirty(); document.getElementById('val_desktop_interval_s').innerText = this.value + 's'">
            <span class="range-val" id="val_desktop_interval_s">10s</span>
          </div>
        </div>
        <div class="form-group">
          <label class="form-label">Random Jitter (seconds)</label>
          <div class="range-wrap">
            <input type="range" id="desktop_jitter_s" min="0" max="15" value="2" oninput="markDirty(); document.getElementById('val_desktop_jitter_s').innerText = this.value + 's'">
            <span class="range-val" id="val_desktop_jitter_s">2s</span>
          </div>
        </div>
        <div class="form-group">
          <label class="form-label">Monitor Index</label>
          <select id="desktop_monitor_index" class="form-select" onchange="markDirty()">
            <option value="1">Monitor 1 (Primary)</option>
            <option value="2">Monitor 2</option>
            <option value="0">All Monitors Combined</option>
          </select>
        </div>
        <div class="form-group">
          <label class="form-label">OCR Mode</label>
          <select id="desktop_ocr" class="form-select" onchange="markDirty()">
            <option value="auto">Auto (Detect Tesseract)</option>
            <option value="on">Always On</option>
            <option value="off">Off</option>
          </select>
        </div>
        <div class="form-group">
          <label class="form-label">Localhost Vision Endpoint (multimodal privacy safe)</label>
          <input type="text" id="desktop_vision_endpoint" class="form-input" placeholder="e.g. http://localhost:11434" onchange="markDirty()">
        </div>
        <div class="form-group">
          <label class="form-label">Vision Model Name</label>
          <input type="text" id="desktop_vision_model" class="form-input" placeholder="e.g. llava" value="llava" onchange="markDirty()">
        </div>
      </div>
    </div>

    <!-- Patterns & Whitelist / Blacklist Manager -->
    <div class="grid-2">
      <!-- Whitelist & Study -->
      <div class="card">
        <div class="card-header">
          <div class="card-title">📖 Study & Whitelist Patterns</div>
        </div>
        <div class="form-group">
          <label class="form-label">Whitelist Regexes (High Priority Force-Work)</label>
          <div class="chips-box" id="chips_whitelist"></div>
          <div class="chip-add-form">
            <input type="text" id="add_whitelist_input" class="form-input" placeholder="Regex pattern...">
            <button class="btn btn-sm btn-primary" onclick="addChip('whitelist')">+ Add</button>
          </div>
        </div>
        <div class="form-group">
          <label class="form-label">Study Patterns (Matches app title / process)</label>
          <div class="chips-box" id="chips_study_patterns"></div>
          <div class="chip-add-form">
            <input type="text" id="add_study_input" class="form-input" placeholder="Regex pattern...">
            <button class="btn btn-sm btn-primary" onclick="addChip('study_patterns')">+ Add</button>
          </div>
        </div>
        <div class="form-group">
          <label class="form-label">Browser Website Whitelist (Domain regex)</label>
          <div class="chips-box" id="chips_website_whitelist"></div>
          <div class="chip-add-form">
            <input type="text" id="add_web_wl_input" class="form-input" placeholder="Domain regex...">
            <button class="btn btn-sm btn-primary" onclick="addChip('website_whitelist')">+ Add</button>
          </div>
        </div>
      </div>

      <!-- Blacklist & Distraction -->
      <div class="card">
        <div class="card-header">
          <div class="card-title">⚠️ Distraction & Blacklist Patterns</div>
        </div>
        <div class="form-group">
          <label class="form-label">Blacklist Regexes (High Priority Force-Distraction)</label>
          <div class="chips-box" id="chips_blacklist"></div>
          <div class="chip-add-form">
            <input type="text" id="add_blacklist_input" class="form-input" placeholder="Regex pattern...">
            <button class="btn btn-sm btn-danger" onclick="addChip('blacklist')">+ Add</button>
          </div>
        </div>
        <div class="form-group">
          <label class="form-label">Distraction Patterns (Matches app title / process)</label>
          <div class="chips-box" id="chips_distraction_patterns"></div>
          <div class="chip-add-form">
            <input type="text" id="add_distract_input" class="form-input" placeholder="Regex pattern...">
            <button class="btn btn-sm btn-danger" onclick="addChip('distraction_patterns')">+ Add</button>
          </div>
        </div>
        <div class="form-group">
          <label class="form-label">Browser Website Blacklist (Domain regex)</label>
          <div class="chips-box" id="chips_website_blacklist"></div>
          <div class="chip-add-form">
            <input type="text" id="add_web_bl_input" class="form-input" placeholder="Domain regex...">
            <button class="btn btn-sm btn-danger" onclick="addChip('website_blacklist')">+ Add</button>
          </div>
        </div>
      </div>
    </div>

    <!-- Running Applications & Distraction Chooser -->
    <div class="card">
      <div class="card-header">
        <div>
          <div class="card-title">🏃 Running Applications & Distraction Chooser</div>
          <div class="card-desc">All processes currently running on your PC. Choose which ones are Work, Distractions, or Neutral with 1 click without needing to switch active windows!</div>
        </div>
        <div style="display:flex; gap:8px;">
          <button class="btn btn-primary btn-sm" onclick="loadRunningProcesses()">⚡ Refresh Processes</button>
        </div>
      </div>
      <!-- Filter Bar for Processes -->
      <div style="display:grid; grid-template-columns: 2fr 1fr 1fr; gap:10px; margin-bottom:14px;">
        <input type="text" id="proc_search" class="form-input" placeholder="🔍 Search running process (e.g. discord, spotify, chrome, code)..." oninput="filterRunningProcesses()">
        <select id="proc_filter_scope" class="form-select" onchange="filterRunningProcesses()">
          <option value="user" selected>User Apps Only (Hide System Daemons)</option>
          <option value="all">All Running Processes</option>
          <option value="window">Apps with Open Windows Only</option>
        </select>
        <select id="proc_filter_label" class="form-select" onchange="filterRunningProcesses()">
          <option value="all">All Classification States</option>
          <option value="DISTRACTION">Distractions Only</option>
          <option value="STUDY">Work / Study Only</option>
          <option value="NEUTRAL">Neutral Only</option>
        </select>
      </div>
      <div class="table-wrap" style="max-height:420px; overflow-y:auto;">
        <table id="table_processes">
          <thead>
            <tr>
              <th style="width:190px;">Process Name</th>
              <th>Window Title / App Details</th>
              <th style="width:90px;">Memory</th>
              <th style="width:140px;">Current Verdict</th>
              <th style="width:240px;">Choose Category</th>
            </tr>
          </thead>
          <tbody id="processes_tbody">
            <tr><td colspan="5" style="text-align:center; color:var(--text-muted);">Loading running applications...</td></tr>
          </tbody>
        </table>
      </div>
      <div style="margin-top:10px; font-size:12px; color:var(--text-muted); display:flex; justify-content:space-between;">
        <span id="proc_count_info">Showing 0 processes</span>
        <span style="color:var(--primary);">💡 Marking an app instantly trains Sentinel rules for this and all future sessions.</span>
      </div>
    </div>

    <!-- Trained App Signatures Table -->
    <div class="card">
      <div class="card-header">
        <div>
          <div class="card-title">🧠 Learned App Signatures (SQLite Trained)</div>
          <div class="card-desc">Persistent classifications trained during your focus sessions.</div>
        </div>
      </div>
      <div class="table-wrap">
        <table id="table_trained">
          <thead>
            <tr>
              <th>Signature</th>
              <th>Process / Window</th>
              <th>Label</th>
              <th>Updated</th>
              <th>Action</th>
            </tr>
          </thead>
          <tbody>
            <tr><td colspan="5" style="text-align:center; color:var(--text-muted);">Loading trained signatures...</td></tr>
          </tbody>
        </table>
      </div>
    </div>
  </div>

  <!-- TAB 2: PROFILES & PRESETS -->
  <div id="tab_profiles" class="tab-pane">
    <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:20px;">
      <div>
        <h2 style="font-size:18px;">Profiles & Operational Modes</h2>
        <p style="font-size:12px; color:var(--text-muted);">Switch between customized presets with instant hot-reload of penalties, alert timings, and rules.</p>
      </div>
      <button class="btn btn-primary" onclick="openNewProfileModal()">+ Create Custom Profile</button>
    </div>
    <div class="grid-4" id="profiles_grid">
      <!-- Generated via JS -->
    </div>
  </div>

  <!-- TAB 3: SEVERITY & SCORING TWEAKER -->
  <div id="tab_severity" class="tab-pane">
    <div class="card">
      <div class="card-header">
        <div>
          <div class="card-title">⚡ Quick Severity Presets</div>
          <div class="card-desc">Adjust the global enforcement intensity with one click.</div>
        </div>
      </div>
      <div style="display:flex; gap:12px; flex-wrap:wrap;">
        <button class="btn btn-sm" onclick="applySeverityPreset('lenient')">🌱 Gentle / Lenient</button>
        <button class="btn btn-sm btn-primary" onclick="applySeverityPreset('balanced')">⚖️ Balanced (Standard)</button>
        <button class="btn btn-sm btn-danger" onclick="applySeverityPreset('strict')">🔥 Strict Proctored</button>
        <button class="btn btn-sm btn-danger" onclick="applySeverityPreset('lockdown')">🚨 Extreme Lockdown</button>
      </div>
    </div>

    <div class="grid-2">
      <!-- Tier Thresholds & Scoring -->
      <div class="card">
        <div class="card-header">
          <div class="card-title">🏆 Tier Thresholds & Score Bounds</div>
        </div>
        <div class="form-group">
          <label class="form-label">Starting Score</label>
          <div class="range-wrap">
            <input type="range" id="sc_start_score" min="50" max="100" value="100" oninput="markDirty(); document.getElementById('val_sc_start_score').innerText = this.value">
            <span class="range-val" id="val_sc_start_score">100</span>
          </div>
        </div>
        <div class="form-group">
          <label class="form-label">Tier: Excellent (Green)</label>
          <div class="range-wrap">
            <input type="range" id="tier_excellent" min="65" max="95" value="85" oninput="markDirty(); document.getElementById('val_tier_excellent').innerText = '≥ ' + this.value">
            <span class="range-val" id="val_tier_excellent">≥ 85</span>
          </div>
        </div>
        <div class="form-group">
          <label class="form-label">Tier: Okay (Yellow)</label>
          <div class="range-wrap">
            <input type="range" id="tier_okay" min="45" max="80" value="60" oninput="markDirty(); document.getElementById('val_tier_okay').innerText = '≥ ' + this.value">
            <span class="range-val" id="val_tier_okay">≥ 60</span>
          </div>
        </div>
        <div class="form-group">
          <label class="form-label">Tier: Warning (Orange)</label>
          <div class="range-wrap">
            <input type="range" id="tier_warning" min="25" max="60" value="40" oninput="markDirty(); document.getElementById('val_tier_warning').innerText = '≥ ' + this.value">
            <span class="range-val" id="val_tier_warning">≥ 40</span>
          </div>
        </div>
        <div class="form-group">
          <label class="form-label">Tier: Critical (Red)</label>
          <div class="range-wrap">
            <input type="range" id="tier_critical" min="5" max="40" value="20" oninput="markDirty(); document.getElementById('val_tier_critical').innerText = '≥ ' + this.value">
            <span class="range-val" id="val_tier_critical">≥ 20</span>
          </div>
        </div>
      </div>

      <!-- Per-Minute Rates -->
      <div class="card">
        <div class="card-header">
          <div class="card-title">⏱️ Per-Minute Scoring Rates</div>
        </div>
        <div class="form-group">
          <label class="form-label">Studying Paper (+points/min)</label>
          <div class="range-wrap">
            <input type="range" id="rate_paper" min="1" max="25" value="10" oninput="markDirty(); document.getElementById('val_rate_paper').innerText = '+' + this.value + '/m'">
            <span class="range-val" id="val_rate_paper">+10/m</span>
          </div>
        </div>
        <div class="form-group">
          <label class="form-label">Studying Screen (+points/min)</label>
          <div class="range-wrap">
            <input type="range" id="rate_screen" min="1" max="25" value="8" oninput="markDirty(); document.getElementById('val_rate_screen').innerText = '+' + this.value + '/m'">
            <span class="range-val" id="val_rate_screen">+8/m</span>
          </div>
        </div>
        <div class="form-group">
          <label class="form-label">Distracted Screen Penalty (-points/min)</label>
          <div class="range-wrap">
            <input type="range" id="rate_distract" min="-50" max="-5" value="-20" oninput="markDirty(); document.getElementById('val_rate_distract').innerText = this.value + '/m'">
            <span class="range-val" id="val_rate_distract">-20/m</span>
          </div>
        </div>
        <div class="form-group">
          <label class="form-label">Sustained Phone Penalty (-points/min)</label>
          <div class="range-wrap">
            <input type="range" id="rate_phone" min="-50" max="-5" value="-15" oninput="markDirty(); document.getElementById('val_rate_phone').innerText = this.value + '/m'">
            <span class="range-val" id="val_rate_phone">-15/m</span>
          </div>
        </div>
      </div>
    </div>

    <!-- Event Penalties & Alert Timing -->
    <div class="grid-2">
      <!-- Per-Event Penalties -->
      <div class="card">
        <div class="card-header">
          <div class="card-title">💥 Per-Event Violation Penalties</div>
        </div>
        <div class="grid-2">
          <div class="form-group">
            <label class="form-label">Phone Glance (&lt;5s)</label>
            <input type="number" id="ev_phone_glance" class="form-input" value="-5" onchange="markDirty()">
          </div>
          <div class="form-group">
            <label class="form-label">Phone Sustained (&gt;10s)</label>
            <input type="number" id="ev_phone_sustained" class="form-input" value="-25" onchange="markDirty()">
          </div>
          <div class="form-group">
            <label class="form-label">Left Frame / Absent</label>
            <input type="number" id="ev_left_frame" class="form-input" value="-30" onchange="markDirty()">
          </div>
          <div class="form-group">
            <label class="form-label">Repeat Promise Breach</label>
            <input type="number" id="ev_repeat_breach" class="form-input" value="-40" onchange="markDirty()">
          </div>
          <div class="form-group">
            <label class="form-label">Camera Tampered / Blocked</label>
            <input type="number" id="ev_camera_blocked" class="form-input" value="-10" onchange="markDirty()">
          </div>
          <div class="form-group">
            <label class="form-label">Slouching Sustained</label>
            <input type="number" id="ev_slouch" class="form-input" value="-5" onchange="markDirty()">
          </div>
        </div>
      </div>

      <!-- Alert Escalation Timings -->
      <div class="card">
        <div class="card-header">
          <div class="card-title">🚨 Alert Escalation & Audio</div>
        </div>
        <div class="grid-2">
          <div class="form-group">
            <label class="form-label">Full-Screen Countdown (seconds)</label>
            <input type="number" id="alert_countdown_s" class="form-input" value="5" min="1" max="30" onchange="markDirty()">
          </div>
          <div class="form-group">
            <label class="form-label">Action Sustained Trigger (seconds)</label>
            <input type="number" id="alert_sustained_s" class="form-input" value="30" min="5" max="180" onchange="markDirty()">
          </div>
          <div class="form-group">
            <label class="form-label">Repeat Violation Threshold</label>
            <input type="number" id="alert_repeat_thr" class="form-input" value="3" min="1" max="10" onchange="markDirty()">
          </div>
          <div class="form-group">
            <label class="form-label">Ack Snooze Grace Period (s)</label>
            <input type="number" id="alert_ack_snooze" class="form-input" value="90" min="10" max="600" onchange="markDirty()">
          </div>
          <div class="form-group">
            <label class="form-label">Mute Audio Alarms</label>
            <select id="alert_mute" class="form-select" onchange="markDirty()">
              <option value="false">Audio Enabled (Speaking & Chimes)</option>
              <option value="true">Muted (Visual Alerts Only)</option>
            </select>
          </div>
          <div class="form-group">
            <label class="form-label">TTS Speech Rate (WPM)</label>
            <input type="number" id="audio_tts_rate" class="form-input" value="165" min="100" max="250" onchange="markDirty()">
          </div>
        </div>
      </div>
    </div>
  </div>

  <!-- TAB: PUNISHMENTS & ENFORCEMENT MATRIX -->
  <div id="tab_punishments" class="tab-pane">
    <div class="card">
      <div class="card-header">
        <div>
          <div class="card-title">⚡ Tiered Serious Punishments & Enforcement Matrix</div>
          <div class="card-desc">Equip Sentinel with tangible, creative accountability consequences. All toggles persist per session and profile.</div>
        </div>
        <div style="display:flex; gap:10px; align-items:center;">
          <label style="display:flex; align-items:center; gap:8px; font-size:13px; font-weight:600; color:var(--text); cursor:pointer;">
            <span>Enforce Punishments:</span>
            <label class="switch">
              <input type="checkbox" id="punish_master_enabled" onchange="markDirty()" checked>
              <span class="slider"></span>
            </label>
          </label>
          <button class="btn btn-sm btn-primary" onclick="testBrowserChallenge()">🧪 Test in Browser</button>
          <button class="btn btn-sm" onclick="testDesktopChallenge()">🖥️ Test on Desktop</button>
        </div>
      </div>
    </div>

    <!-- Tier Matrix Grid -->
    <div class="grid-3">
      <!-- Tier 2: Warning -->
      <div class="card" style="border-top: 3px solid #f59e0b;">
        <div class="card-header">
          <div>
            <div class="card-title" style="color:#fbbf24;">⚠️ Tier 2: Warning</div>
            <div class="card-desc">Initial distraction trigger</div>
          </div>
          <span class="badge" style="background:rgba(245,158,11,0.2); color:#fbbf24; border:1px solid rgba(245,158,11,0.4);">EARLY WARNING</span>
        </div>
        <div style="display:flex; flex-direction:column; gap:12px;">
          <label style="display:flex; align-items:center; justify-content:space-between; font-size:13px;">
            <span>🔔 Toast Warning Notification</span>
            <input type="checkbox" id="punish_t2_toast" onchange="markDirty()" checked>
          </label>
          <label style="display:flex; align-items:center; justify-content:space-between; font-size:13px;">
            <span>🎵 Audio Chime Reminder</span>
            <input type="checkbox" id="punish_t2_chime" onchange="markDirty()" checked>
          </label>
          <label style="display:flex; align-items:center; justify-content:space-between; font-size:13px;">
            <span>🪟 Auto-Minimize Offending App</span>
            <input type="checkbox" id="punish_t2_minimize" onchange="markDirty()">
          </label>
          <div class="form-group" style="margin-top:4px;">
            <label class="form-label">Instant Focus Score Tax (pts)</label>
            <input type="number" id="punish_t2_tax" class="form-input" min="0" max="15" value="0" onchange="markDirty()">
          </div>
        </div>
      </div>

      <!-- Tier 3: Critical Countdown -->
      <div class="card" style="border-top: 3px solid #f97316;">
        <div class="card-header">
          <div>
            <div class="card-title" style="color:#fb923c;">⏱️ Tier 3: Critical Countdown</div>
            <div class="card-desc">Persistent breach escalation</div>
          </div>
          <span class="badge" style="background:rgba(249,115,22,0.2); color:#fb923c; border:1px solid rgba(249,115,22,0.4);">COUNTDOWN MODAL</span>
        </div>
        <div style="display:flex; flex-direction:column; gap:12px;">
          <label style="display:flex; align-items:center; justify-content:space-between; font-size:13px;">
            <span>🛑 Full-Screen Countdown Modal</span>
            <input type="checkbox" id="punish_t3_modal" onchange="markDirty()" checked>
          </label>
          <div class="form-group" style="margin:0;">
            <label class="form-label">🗡️ Distraction App Action</label>
            <select id="punish_t3_app_action" class="form-select" onchange="markDirty()">
              <option value="none">None (Modal only)</option>
              <option value="minimize" selected>Minimize Distracting Window</option>
              <option value="close_window">Close Window (Graceful WM_CLOSE)</option>
              <option value="terminate">Terminate Process (App Slayer)</option>
            </select>
          </div>
          <label style="display:flex; align-items:center; justify-content:space-between; font-size:13px;">
            <span>✍️ Typing Focus Commitment Pledge</span>
            <input type="checkbox" id="punish_t3_typing" onchange="markDirty()" checked>
          </label>
          <label style="display:flex; align-items:center; justify-content:space-between; font-size:13px;">
            <span>🧠 Mental Math Reboot Challenge</span>
            <input type="checkbox" id="punish_t3_math" onchange="markDirty()">
          </label>
          <label style="display:flex; align-items:center; justify-content:space-between; font-size:13px;">
            <span>🧘 Physical Reset Mandate</span>
            <input type="checkbox" id="punish_t3_physical" onchange="markDirty()">
          </label>
          <div class="grid-2" style="gap:8px;">
            <div class="form-group" style="margin:0;">
              <label class="form-label">🔒 Cooldown Lock (s)</label>
              <input type="number" id="punish_t3_lock_s" class="form-input" min="0" max="30" value="5" onchange="markDirty()">
            </div>
            <div class="form-group" style="margin:0;">
              <label class="form-label">💸 Score Tax (pts)</label>
              <input type="number" id="punish_t3_tax" class="form-input" min="0" max="30" value="10" onchange="markDirty()">
            </div>
          </div>
        </div>
      </div>

      <!-- Tier 4: Alarm & Lockdown -->
      <div class="card" style="border-top: 3px solid #ef4444;">
        <div class="card-header">
          <div>
            <div class="card-title" style="color:#f87171;">🚨 Tier 4: Lockdown & Alarm</div>
            <div class="card-desc">Critical threshold or expired grace</div>
          </div>
          <span class="badge" style="background:rgba(239,68,68,0.2); color:#f87171; border:1px solid rgba(239,68,68,0.4);">FULL ENFORCEMENT</span>
        </div>
        <div style="display:flex; flex-direction:column; gap:12px;">
          <label style="display:flex; align-items:center; justify-content:space-between; font-size:13px;">
            <span>🔊 Siren Drill Audio</span>
            <input type="checkbox" id="punish_t4_alarm" onchange="markDirty()" checked>
          </label>
          <label style="display:flex; align-items:center; justify-content:space-between; font-size:13px;">
            <span>🗣️ Proctor-9 Voice Command</span>
            <input type="checkbox" id="punish_t4_proctor" onchange="markDirty()" checked>
          </label>
          <div class="form-group" style="margin:0;">
            <label class="form-label">🗡️ Distraction App Action</label>
            <select id="punish_t4_app_action" class="form-select" onchange="markDirty()">
              <option value="none">None</option>
              <option value="minimize">Minimize Window</option>
              <option value="close_window">Close Window (WM_CLOSE)</option>
              <option value="terminate" selected>Terminate Process (Force Kill)</option>
            </select>
          </div>
          <label style="display:flex; align-items:center; justify-content:space-between; font-size:13px;">
            <span>✍️ Typing Focus Commitment Pledge</span>
            <input type="checkbox" id="punish_t4_typing" onchange="markDirty()" checked>
          </label>
          <label style="display:flex; align-items:center; justify-content:space-between; font-size:13px;">
            <span>🧠 Mental Math Reboot Challenge</span>
            <input type="checkbox" id="punish_t4_math" onchange="markDirty()" checked>
          </label>
          <label style="display:flex; align-items:center; justify-content:space-between; font-size:13px;">
            <span>🧘 Physical Reset Mandate</span>
            <input type="checkbox" id="punish_t4_physical" onchange="markDirty()" checked>
          </label>
          <div class="grid-2" style="gap:8px;">
            <div class="form-group" style="margin:0;">
              <label class="form-label">🔒 Cooldown Lock (s)</label>
              <input type="number" id="punish_t4_lock_s" class="form-input" min="0" max="60" value="12" onchange="markDirty()">
            </div>
            <div class="form-group" style="margin:0;">
              <label class="form-label">💸 Score Tax (pts)</label>
              <input type="number" id="punish_t4_tax" class="form-input" min="0" max="50" value="25" onchange="markDirty()">
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- Challenge Customization Studio -->
    <div class="grid-2">
      <!-- Card 1: Focus Commitment Pledge Studio -->
      <div class="card">
        <div class="card-header">
          <div>
            <div class="card-title">✍️ Focus Commitment Pledge Studio</div>
            <div class="card-desc">The verbatim vow the user must type character-for-character to unlock acknowledgement. Clipboard pasting is blocked.</div>
          </div>
        </div>
        <div class="form-group">
          <label class="form-label">Active Commitment Pledge Sentence</label>
          <textarea id="punish_typing_pledge" rows="3" class="form-input" oninput="onPledgeInput()" style="font-size:13px; font-weight:500; line-height:1.4;"></textarea>
          <div style="display:flex; justify-content:space-between; font-size:11px; color:var(--text-muted); margin-top:4px;">
            <span id="pledge_char_count">74 characters</span>
            <span>🛡️ Anti-paste protected & character validation active</span>
          </div>
        </div>
        <div class="form-group" style="margin-bottom:0;">
          <label class="form-label" style="margin-bottom:6px;">Quick Presets Library:</label>
          <div style="display:flex; flex-wrap:wrap; gap:6px;">
            <button class="btn btn-sm" onclick="setPledgePreset('I will not trade my long-term goals for short-term digital distractions.')">Balanced Discipline</button>
            <button class="btn btn-sm" onclick="setPledgePreset('Deep focus is my competitive advantage. I choose discipline over instant gratification.')">Deep Work</button>
            <button class="btn btn-sm" onclick="setPledgePreset('Exam integrity is absolute. I will not seek external distractions.')">Exam Lockdown</button>
            <button class="btn btn-sm" onclick="setPledgePreset('I stay locked into the codebase until this feature is shipped.')">Software Engineer</button>
            <button class="btn btn-sm" onclick="setPledgePreset('My time and attention are non-negotiable. I return to my work right now.')">High Stakes</button>
          </div>
        </div>
      </div>

      <!-- Card 2: Mental Math & App Slayer Safeguards -->
      <div class="card">
        <div class="card-header">
          <div>
            <div class="card-title">🧠 Cognitive Reboot & App Slayer Settings</div>
            <div class="card-desc">Tune arithmetic difficulty and view process protection whitelist.</div>
          </div>
        </div>
        <div class="grid-2">
          <div class="form-group">
            <label class="form-label">Mental Math Difficulty</label>
            <select id="punish_math_difficulty" class="form-select" onchange="markDirty()">
              <option value="easy">Easy (Single-step arithmetic)</option>
              <option value="medium" selected>Medium (Two-step arithmetic & brackets)</option>
              <option value="hard">Hard (Multi-term mental arithmetic)</option>
            </select>
          </div>
          <div class="form-group">
            <label class="form-label">Default App Kill Action Mode</label>
            <select id="punish_kill_mode" class="form-select" onchange="markDirty()">
              <option value="terminate" selected>Terminate Process (psutil terminate)</option>
              <option value="close_window">Close Window (Graceful WM_CLOSE)</option>
              <option value="minimize">Minimize Window (SW_MINIMIZE)</option>
            </select>
          </div>
        </div>
        <div class="form-group">
          <label class="form-label">Physical Reset Mandate Prompt</label>
          <input type="text" id="punish_physical_text" class="form-input" value="Stand up, stretch your arms overhead, and take 3 slow diaphragmatic breaths." onchange="markDirty()">
        </div>
        <div style="background:#0a1424; border:1px solid var(--border); border-radius:6px; padding:10px 14px; font-size:12px; color:var(--text-muted);">
          <b style="color:#38bdf8;">🛡️ System Safeguard Whitelist:</b> Sentinel will never kill or minimize Windows critical processes: <code>explorer.exe</code>, <code>python.exe</code>, <code>dwm.exe</code>, <code>cmd.exe</code>, <code>powershell.exe</code>, <code>taskmgr.exe</code>, <code>conhost.exe</code>.
        </div>
      </div>
    </div>
  </div>

  <!-- TAB 4: HISTORICAL LOGS & TIME TRAVEL -->
  <div id="tab_logs" class="tab-pane">
    <div class="card">
      <div class="card-header">
        <div>
          <div class="card-title">🕒 Time-Travel Log Explorer</div>
          <div class="card-desc">Query and inspect historical logs across sessions and specific time windows.</div>
        </div>
        <div style="display:flex; gap:8px;">
          <button class="btn btn-sm" onclick="exportLogs('csv')">📥 Export CSV</button>
          <button class="btn btn-sm" onclick="exportLogs('json')">📥 Export JSON</button>
        </div>
      </div>
      <!-- Filter Bar -->
      <div style="display:grid; grid-template-columns: 2fr 1fr 1fr 1fr 2fr; gap:10px; margin-bottom:14px;">
        <div class="form-group" style="margin:0;">
          <label class="form-label">Session</label>
          <select id="log_session_select" class="form-select" onchange="onLogFilterChange()">
            <option value="all">All Sessions</option>
          </select>
        </div>
        <div class="form-group" style="margin:0;">
          <label class="form-label">Time Window</label>
          <select id="log_time_window" class="form-select" onchange="onTimeWindowChange()">
            <option value="all">All Time</option>
            <option value="today">Today</option>
            <option value="24h">Last 24 Hours</option>
            <option value="7d">Last 7 Days</option>
            <option value="custom">Custom Range</option>
          </select>
        </div>
        <div class="form-group" style="margin:0;">
          <label class="form-label">Event Category</label>
          <select id="log_type_filter" class="form-select" onchange="onLogFilterChange()">
            <option value="all">All Event Types</option>
            <option value="violations">Violations (Penalties & Alerts)</option>
            <option value="desktop.activity">Desktop Activity</option>
            <option value="penalty">Penalties</option>
            <option value="phone">Phone Events</option>
            <option value="presence">Presence Events</option>
            <option value="alert">Alerts</option>
            <option value="plugins">Plugins</option>
          </select>
        </div>
        <div class="form-group" style="margin:0;">
          <label class="form-label">Max Items</label>
          <select id="log_limit" class="form-select" onchange="onLogFilterChange()">
            <option value="50">50</option>
            <option value="100" selected>100</option>
            <option value="250">250</option>
            <option value="500">500</option>
          </select>
        </div>
        <div class="form-group" style="margin:0;">
          <label class="form-label">Search Keyword</label>
          <input type="text" id="log_search" class="form-input" placeholder="Search app title, error, reason..." oninput="onLogSearchInput()">
        </div>
      </div>

      <!-- Custom Date Row (Hidden by default) -->
      <div id="custom_time_row" style="display:none; grid-template-columns: 1fr 1fr; gap:10px; margin-bottom:14px;">
        <div>
          <label class="form-label">From Timestamp (ISO / Date)</label>
          <input type="datetime-local" id="custom_start_time" class="form-input" onchange="onLogFilterChange()">
        </div>
        <div>
          <label class="form-label">To Timestamp (ISO / Date)</label>
          <input type="datetime-local" id="custom_end_time" class="form-input" onchange="onLogFilterChange()">
        </div>
      </div>

      <!-- Historical Score Curve Graph -->
      <div id="session_curve_wrap" style="display:none; margin-bottom:18px; padding:14px; background:#0a1424; border-radius:6px; border:1px solid var(--border);">
        <div style="font-size:12px; font-weight:700; color:var(--text-muted); margin-bottom:8px;">SESSION SCORE TRAJECTORY</div>
        <svg id="session_curve" width="100%" height="100" viewBox="0 0 700 100" preserveAspectRatio="none"></svg>
      </div>

      <!-- Results Table -->
      <div class="table-wrap">
        <table>
          <thead>
            <tr>
              <th style="width:140px;">Timestamp</th>
              <th style="width:60px;">Sid</th>
              <th style="width:160px;">Event Type</th>
              <th style="width:100px;">Source</th>
              <th>Details / Reason</th>
              <th style="width:80px;">Action</th>
            </tr>
          </thead>
          <tbody id="logs_tbody">
            <tr><td colspan="6" style="text-align:center; color:var(--text-muted);">Select filters to load historical events.</td></tr>
          </tbody>
        </table>
      </div>
      <div style="display:flex; justify-content:space-between; align-items:center; margin-top:14px; font-size:12px; color:var(--text-muted);">
        <span id="logs_count_info">Showing 0 events</span>
        <div style="display:flex; gap:8px;">
          <button class="btn btn-sm" id="btn_prev_page" onclick="changePage(-1)">← Prev</button>
          <button class="btn btn-sm" id="btn_next_page" onclick="changePage(1)">Next →</button>
        </div>
      </div>
    </div>
  </div>

  <!-- TAB 5: PLUGINS ACTIVATION -->
  <div id="tab_plugins" class="tab-pane">
    <div style="margin-bottom:20px;">
      <h2 style="font-size:18px;">Plugins & Focus Extenders</h2>
      <p style="font-size:12px; color:var(--text-muted);">Activate or deactivate Sentinel extension plugins and customize per-plugin parameters.</p>
    </div>
    <div class="grid-3" id="plugins_grid">
      <!-- Generated via JS -->
    </div>
  </div>

  <!-- TAB 6: LIVE MONITOR & STATS -->
  <div id="tab_overview" class="tab-pane">
    <div class="grid-2">
      <div class="card">
        <div class="card-header">
          <div class="card-title">🎯 Live Session State</div>
        </div>
        <div style="display:flex; align-items:center; gap:24px; padding:10px 0;">
          <div style="font-size:56px; font-weight:800; color:#22c55e;" id="ov_score">100</div>
          <div>
            <div style="font-size:13px; color:var(--text-muted);">FOCUS SCORE</div>
            <div style="font-size:18px; font-weight:700;" id="ov_state">STUDYING</div>
            <div style="font-size:13px; color:var(--primary);" id="ov_tier">TIER: EXCELLENT</div>
          </div>
        </div>
        <div style="margin-top:14px;">
          <svg id="live_curve" width="100%" height="90" viewBox="0 0 700 90" preserveAspectRatio="none" style="background:#0a1424; border-radius:6px;"></svg>
        </div>
      </div>
      <div class="card">
        <div class="card-header">
          <div class="card-title">📈 Lifetime Metrics</div>
        </div>
        <div id="ov_life" style="font-size:14px; line-height:2;">Loading stats...</div>
        <div id="ov_analysis" style="margin-top:14px; font-size:13px; color:var(--text-muted);"></div>
      </div>
    </div>
    <div class="card">
      <div class="card-header">
        <div class="card-title">🔥 14-Day Distraction Heatmap</div>
      </div>
      <div class="table-wrap" id="ov_heatmap"></div>
    </div>
  </div>

  <!-- TAB 7: DIAGNOSTICS -->
  <div id="tab_diagnostics" class="tab-pane">
    <div class="card">
      <div class="card-header">
        <div class="card-title">🩺 System Recon & Environment Status</div>
        <button class="btn btn-sm btn-primary" onclick="loadDiagnostics()">Refresh Recon</button>
      </div>
      <div id="diag_content" style="font-size:13px; line-height:1.8;">
        Loading diagnostic information...
      </div>
    </div>
  </div>
</main>

<!-- Save Banner (Floating) -->
<div class="save-banner" id="save_banner">
  <div style="display:flex; align-items:center; gap:12px;">
    <span>⚠️ You have unsaved configuration changes!</span>
  </div>
  <div style="display:flex; gap:10px;">
    <button class="btn btn-sm" onclick="discardChanges()">Discard</button>
    <button class="btn btn-sm btn-success" onclick="saveAllConfig()">Save All Changes</button>
  </div>
</div>

<!-- Modal: Event JSON Inspector -->
<div class="modal-overlay" id="event_modal" onclick="closeModal(event, 'event_modal')">
  <div class="modal">
    <div class="modal-head">
      <h3 style="font-size:15px;" id="modal_event_title">Event Details</h3>
      <button class="btn btn-sm" onclick="document.getElementById('event_modal').style.display='none'">✕</button>
    </div>
    <div class="modal-body">
      <pre id="modal_event_json" style="background:#060d19; padding:14px; border-radius:6px; font-size:12px; overflow-x:auto; color:#a5f3fc; font-family:monospace;"></pre>
    </div>
    <div class="modal-foot">
      <button class="btn btn-sm btn-primary" onclick="copyEventJson()">Copy JSON</button>
      <button class="btn btn-sm" onclick="document.getElementById('event_modal').style.display='none'">Close</button>
    </div>
  </div>
</div>

<!-- Modal: Create New Profile -->
<div class="modal-overlay" id="profile_modal" onclick="closeModal(event, 'profile_modal')">
  <div class="modal">
    <div class="modal-head">
      <h3 style="font-size:15px;">Create Custom Focus Profile</h3>
      <button class="btn btn-sm" onclick="document.getElementById('profile_modal').style.display='none'">✕</button>
    </div>
    <div class="modal-body">
      <div class="form-group">
        <label class="form-label">Profile ID (lowercase alphanumeric)</label>
        <input type="text" id="np_id" class="form-input" placeholder="e.g. math_olympiad">
      </div>
      <div class="form-group">
        <label class="form-label">Display Name</label>
        <input type="text" id="np_name" class="form-input" placeholder="e.g. Mathematics Olympiad">
      </div>
      <div class="form-group">
        <label class="form-label">Badge Label</label>
        <input type="text" id="np_badge" class="form-input" placeholder="e.g. Problem Solving">
      </div>
      <div class="form-group">
        <label class="form-label">Description</label>
        <textarea id="np_desc" rows="3" class="form-input" placeholder="Purpose and enforcement guidelines..."></textarea>
      </div>
      <div class="form-group">
        <label class="form-label">Clone Base Settings From</label>
        <select id="np_base" class="form-select">
          <option value="current">Current Configuration</option>
          <option value="deep_work">Deep Work</option>
          <option value="exam_strict">Exam Lockdown</option>
          <option value="coding_dev">Software Engineering</option>
          <option value="casual_reading">Casual Reading</option>
        </select>
      </div>
    </div>
    <div class="modal-foot">
      <button class="btn btn-sm" onclick="document.getElementById('profile_modal').style.display='none'">Cancel</button>
      <button class="btn btn-sm btn-primary" onclick="createProfile()">Create & Activate</button>
    </div>
  </div>
</div>

<!-- Modal: Browser Punishment Challenge Simulator -->
<div class="modal-overlay" id="browser_challenge_modal" onclick="closeModal(event, 'browser_challenge_modal')">
  <div class="modal" style="max-width: 680px; border-color: #ff5d73;">
    <div class="modal-head" style="background:#111c30; border-bottom: 1px solid #334155;">
      <div style="display:flex; align-items:center; gap:8px;">
        <span style="font-size:18px;">⚡</span>
        <h3 style="font-size:15px; color:#ff7689;">ENFORCEMENT CHALLENGE SIMULATOR</h3>
      </div>
      <button class="btn btn-sm" onclick="closeBrowserChallenge()">✕</button>
    </div>
    <div class="modal-body" style="background:#091220; display:flex; flex-direction:column; gap:16px;">
      <div style="text-align:center;">
        <div style="font-size:36px; font-weight:800; color:#fff;" id="sim_countdown">10</div>
        <div style="color:var(--text-muted); font-size:12px;">Simulated critical countdown with cognitive unlock tasks</div>
      </div>

      <div id="sim_badge_box" style="background:#2a121d; border:1px solid #ef4444; border-radius:6px; padding:8px 12px; font-size:12px; color:#fca5a5;">
        ⚡ <b>SIMULATED ACTION:</b> Minimized Offending Window · -10 Pts Focus Score Tax Applied
      </div>

      <div id="sim_physical_box" style="background:#1f2937; border:1px solid #eab308; border-radius:6px; padding:8px 12px; font-size:12px; color:#fde047;">
        🧘 <b>PHYSICAL RESET MANDATE:</b> <span id="sim_physical_text">Stand up, stretch overhead, and take 3 deep diaphragmatic breaths.</span>
      </div>

      <!-- Math Challenge -->
      <div id="sim_math_card" style="background:#0d182b; border:1px solid #3b82f6; border-radius:6px; padding:12px;">
        <div style="font-size:12px; font-weight:700; color:#93c5fd; margin-bottom:6px;">🧠 MENTAL REBOOT: Solve arithmetic to unlock</div>
        <div style="display:flex; align-items:center; gap:10px;">
          <span style="font-size:15px; font-weight:700; color:#fff;" id="sim_math_q">(14 × 6) - 29 =</span>
          <input type="text" id="sim_math_ans" class="form-input" style="width:100px; text-align:center; font-weight:bold; font-size:15px;" placeholder="?" oninput="checkSimMath()">
          <span id="sim_math_status" style="font-size:12px; color:var(--text-muted);">Required</span>
        </div>
      </div>

      <!-- Typing Challenge -->
      <div id="sim_typing_card" style="background:#0d182b; border:1px solid #8b5cf6; border-radius:6px; padding:12px;">
        <div style="font-size:12px; font-weight:700; color:#c4b5fd; margin-bottom:4px;">✍️ FOCUS COMMITMENT (Type verbatim below · pasting blocked):</div>
        <div style="font-size:13px; font-style:italic; color:#e2e8f0; background:#070d18; padding:8px 10px; border-radius:4px; margin-bottom:8px;" id="sim_typing_target">I will not trade my long-term goals for short-term digital distractions.</div>
        <input type="text" id="sim_typing_input" class="form-input" placeholder="Type the exact sentence above..." oninput="checkSimTyping()" onpaste="return false;" style="font-size:13px;">
        <div style="display:flex; justify-content:space-between; font-size:11px; margin-top:4px;">
          <span id="sim_typing_status" style="color:var(--text-muted);">0 / 74 characters</span>
          <span style="color:#a78bfa;">Paste disabled</span>
        </div>
      </div>
    </div>
    <div class="modal-foot" style="background:#111c30;">
      <button class="btn btn-sm" onclick="closeBrowserChallenge()">Cancel</button>
      <button class="btn btn-sm" id="sim_btn_ack" disabled style="background:#1e293b; color:#64748b;" onclick="onSimAck()">🔒 Cooldown Active</button>
    </div>
  </div>
</div>

<div id="toast">Saved successfully</div>

<script>
let currentConfig = {};
let activeProfileId = 'deep_work';
let isDirty = false;
let logPageOffset = 0;
let lastInspected = null;

function showToast(msg, bg) {
  const t = document.getElementById('toast');
  t.innerText = msg;
  t.style.background = bg || '#1e293b';
  t.style.display = 'flex';
  setTimeout(() => { t.style.display = 'none'; }, 3000);
}

function markDirty() {
  isDirty = true;
  document.getElementById('save_banner').style.display = 'flex';
}

function clearDirty() {
  isDirty = false;
  document.getElementById('save_banner').style.display = 'none';
}

function switchTab(name) {
  document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
  document.querySelectorAll('.tab-pane').forEach(p => p.classList.remove('active'));
  const btn = Array.from(document.querySelectorAll('.tab-btn')).find(b => b.getAttribute('onclick').includes(name));
  if (btn) btn.classList.add('active');
  const pane = document.getElementById('tab_' + name);
  if (pane) pane.classList.add('active');
  if (name === 'desktop') loadRunningProcesses();
  if (name === 'logs') loadHistoricalLogs();
  if (name === 'diagnostics') loadDiagnostics();
}

// ---------------- CONFIG & PROFILES ----------------
async function loadConfig() {
  try {
    const res = await fetch('/api/config');
    currentConfig = await res.json();
    activeProfileId = currentConfig.active_profile || 'deep_work';
    populateFormWithConfig(currentConfig);
    loadProfiles();
    loadPlugins();
    clearDirty();
  } catch (e) {
    console.error("Config load error", e);
  }
}

function populateFormWithConfig(cfg) {
  const desk = cfg.desktop || {};
  document.getElementById('desktop_interval_s').value = desk.interval_s || 10;
  document.getElementById('val_desktop_interval_s').innerText = (desk.interval_s || 10) + 's';
  document.getElementById('desktop_jitter_s').value = desk.jitter_s || 2;
  document.getElementById('val_desktop_jitter_s').innerText = (desk.jitter_s || 2) + 's';
  document.getElementById('desktop_monitor_index').value = desk.monitor_index !== undefined ? desk.monitor_index : 1;
  document.getElementById('desktop_ocr').value = desk.ocr || 'auto';
  document.getElementById('desktop_vision_endpoint').value = desk.vision_endpoint || '';
  document.getElementById('desktop_vision_model').value = desk.vision_model || 'llava';

  // Scoring
  const sc = cfg.scoring || {};
  document.getElementById('sc_start_score').value = sc.start_score || 100;
  document.getElementById('val_sc_start_score').innerText = sc.start_score || 100;
  const tiers = sc.tiers || { critical: 20, warning: 40, okay: 60, excellent: 85 };
  document.getElementById('tier_excellent').value = tiers.excellent || 85;
  document.getElementById('val_tier_excellent').innerText = '≥ ' + (tiers.excellent || 85);
  document.getElementById('tier_okay').value = tiers.okay || 60;
  document.getElementById('val_tier_okay').innerText = '≥ ' + (tiers.okay || 60);
  document.getElementById('tier_warning').value = tiers.warning || 40;
  document.getElementById('val_tier_warning').innerText = '≥ ' + (tiers.warning || 40);
  document.getElementById('tier_critical').value = tiers.critical || 20;
  document.getElementById('val_tier_critical').innerText = '≥ ' + (tiers.critical || 20);

  // Per Minute
  const pm = sc.per_minute || {};
  document.getElementById('rate_paper').value = pm.studying_paper || 10;
  document.getElementById('val_rate_paper').innerText = '+' + (pm.studying_paper || 10) + '/m';
  document.getElementById('rate_screen').value = pm.studying_screen || 8;
  document.getElementById('val_rate_screen').innerText = '+' + (pm.studying_screen || 8) + '/m';
  document.getElementById('rate_distract').value = pm.distracted_screen || -20;
  document.getElementById('val_rate_distract').innerText = (pm.distracted_screen || -20) + '/m';
  document.getElementById('rate_phone').value = pm.sustained_phone || -15;
  document.getElementById('val_rate_phone').innerText = (pm.sustained_phone || -15) + '/m';

  // Per Event
  const pe = sc.per_event || {};
  document.getElementById('ev_phone_glance').value = pe.phone_glance_under_5s || -5;
  document.getElementById('ev_phone_sustained').value = pe.phone_sustained_over_10s || -25;
  document.getElementById('ev_left_frame').value = pe.left_frame || -30;
  document.getElementById('ev_repeat_breach').value = pe.promise_repeat_breach || -40;
  document.getElementById('ev_camera_blocked').value = pe.camera_blocked || -10;
  document.getElementById('ev_slouch').value = pe.slouch_sustained || -5;

  // Alerts
  const al = cfg.alerts || {};
  document.getElementById('alert_countdown_s').value = al.countdown_s || 5;
  document.getElementById('alert_sustained_s').value = al.action_sustained_s || 30;
  document.getElementById('alert_repeat_thr').value = al.repeat_threshold || 3;
  document.getElementById('alert_ack_snooze').value = al.ack_snooze_s || 90;
  document.getElementById('alert_mute').value = al.mute ? 'true' : 'false';

  // Audio
  const au = cfg.audio || {};
  document.getElementById('audio_tts_rate').value = au.tts_rate || 165;

  // Render Chip lists
  renderChips('whitelist', desk.whitelist || []);
  renderChips('study_patterns', desk.study_patterns || []);
  renderChips('distraction_patterns', desk.distraction_patterns || []);
  renderChips('blacklist', desk.blacklist || []);
  const br = cfg.browser || {};
  renderChips('website_whitelist', br.website_whitelist || []);
  renderChips('website_blacklist', br.website_blacklist || []);

  // Punishments
  const pu = cfg.punishments || {};
  if (document.getElementById('punish_master_enabled')) {
    document.getElementById('punish_master_enabled').checked = pu.enabled !== false;
    document.getElementById('punish_typing_pledge').value = pu.typing_pledge || 'I will not trade my long-term goals for short-term digital distractions.';
    onPledgeInput();
    document.getElementById('punish_math_difficulty').value = pu.math_difficulty || 'medium';
    document.getElementById('punish_kill_mode').value = pu.kill_mode || 'terminate';
    document.getElementById('punish_physical_text').value = pu.physical_action_text || 'Stand up, stretch your arms overhead, and take 3 slow diaphragmatic breaths.';

    // Tier 2
    const t2 = pu.tier2 || {};
    document.getElementById('punish_t2_toast').checked = t2.toast_warning !== false;
    document.getElementById('punish_t2_chime').checked = t2.chime !== false;
    document.getElementById('punish_t2_minimize').checked = !!t2.minimize_app;
    document.getElementById('punish_t2_tax').value = t2.score_tax || 0;

    // Tier 3
    const t3 = pu.tier3 || {};
    document.getElementById('punish_t3_modal').checked = t3.countdown_modal !== false;
    if (t3.kill_app) {
      document.getElementById('punish_t3_app_action').value = 'terminate';
    } else if (t3.minimize_app) {
      document.getElementById('punish_t3_app_action').value = 'minimize';
    } else {
      document.getElementById('punish_t3_app_action').value = t3.app_action || 'minimize';
    }
    document.getElementById('punish_t3_typing').checked = t3.typing_challenge !== false;
    document.getElementById('punish_t3_math').checked = !!t3.math_challenge;
    document.getElementById('punish_t3_lock_s').value = t3.lock_seconds !== undefined ? t3.lock_seconds : 5;
    document.getElementById('punish_t3_tax').value = t3.score_tax !== undefined ? t3.score_tax : 10;
    document.getElementById('punish_t3_physical').checked = !!t3.physical_action;

    // Tier 4
    const t4 = pu.tier4 || {};
    document.getElementById('punish_t4_alarm').checked = t4.alarm_sound !== false;
    document.getElementById('punish_t4_proctor').checked = t4.proctor_drill !== false;
    if (t4.kill_app) {
      document.getElementById('punish_t4_app_action').value = 'terminate';
    } else if (t4.minimize_app) {
      document.getElementById('punish_t4_app_action').value = 'minimize';
    } else {
      document.getElementById('punish_t4_app_action').value = t4.app_action || 'terminate';
    }
    document.getElementById('punish_t4_typing').checked = t4.typing_challenge !== false;
    document.getElementById('punish_t4_math').checked = t4.math_challenge !== false;
    document.getElementById('punish_t4_lock_s').value = t4.lock_seconds !== undefined ? t4.lock_seconds : 12;
    document.getElementById('punish_t4_tax').value = t4.score_tax !== undefined ? t4.score_tax : 25;
    document.getElementById('punish_t4_physical').checked = t4.physical_action !== false;
  }

}

function gatherConfigFromForm() {
  const cfg = JSON.parse(JSON.stringify(currentConfig));
  cfg.desktop = cfg.desktop || {};
  cfg.desktop.interval_s = parseInt(document.getElementById('desktop_interval_s').value, 10);
  cfg.desktop.jitter_s = parseInt(document.getElementById('desktop_jitter_s').value, 10);
  cfg.desktop.monitor_index = parseInt(document.getElementById('desktop_monitor_index').value, 10);
  cfg.desktop.ocr = document.getElementById('desktop_ocr').value;
  cfg.desktop.vision_endpoint = document.getElementById('desktop_vision_endpoint').value.trim();
  cfg.desktop.vision_model = document.getElementById('desktop_vision_model').value.trim();

  cfg.scoring = cfg.scoring || {};
  cfg.scoring.start_score = parseInt(document.getElementById('sc_start_score').value, 10);
  cfg.scoring.clamp = [0, 100];
  cfg.scoring.tiers = {
    critical: parseInt(document.getElementById('tier_critical').value, 10),
    warning: parseInt(document.getElementById('tier_warning').value, 10),
    okay: parseInt(document.getElementById('tier_okay').value, 10),
    excellent: parseInt(document.getElementById('tier_excellent').value, 10)
  };
  cfg.scoring.per_minute = {
    studying_paper: parseInt(document.getElementById('rate_paper').value, 10),
    studying_screen: parseInt(document.getElementById('rate_screen').value, 10),
    neutral_idle: 0,
    distracted_screen: parseInt(document.getElementById('rate_distract').value, 10),
    sustained_phone: parseInt(document.getElementById('rate_phone').value, 10)
  };
  cfg.scoring.per_event = {
    phone_glance_under_5s: parseInt(document.getElementById('ev_phone_glance').value, 10),
    phone_sustained_over_10s: parseInt(document.getElementById('ev_phone_sustained').value, 10),
    left_frame: parseInt(document.getElementById('ev_left_frame').value, 10),
    promise_repeat_breach: parseInt(document.getElementById('ev_repeat_breach').value, 10),
    camera_blocked: parseInt(document.getElementById('ev_camera_blocked').value, 10),
    slouch_sustained: parseInt(document.getElementById('ev_slouch').value, 10)
  };

  cfg.alerts = cfg.alerts || {};
  cfg.alerts.countdown_s = parseInt(document.getElementById('alert_countdown_s').value, 10);
  cfg.alerts.action_sustained_s = parseInt(document.getElementById('alert_sustained_s').value, 10);
  cfg.alerts.repeat_threshold = parseInt(document.getElementById('alert_repeat_thr').value, 10);
  cfg.alerts.ack_snooze_s = parseInt(document.getElementById('alert_ack_snooze').value, 10);
  cfg.alerts.mute = document.getElementById('alert_mute').value === 'true';

  cfg.audio = cfg.audio || {};
  cfg.audio.tts_rate = parseInt(document.getElementById('audio_tts_rate').value, 10);

  if (document.getElementById('punish_master_enabled')) {
    const t3Action = document.getElementById('punish_t3_app_action').value;
    const t4Action = document.getElementById('punish_t4_app_action').value;
    cfg.punishments = {
      enabled: document.getElementById('punish_master_enabled').checked,
      typing_pledge: document.getElementById('punish_typing_pledge').value.trim(),
      math_difficulty: document.getElementById('punish_math_difficulty').value,
      kill_mode: document.getElementById('punish_kill_mode').value,
      physical_action_text: document.getElementById('punish_physical_text').value.trim(),
      tier2: {
        toast_warning: document.getElementById('punish_t2_toast').checked,
        chime: document.getElementById('punish_t2_chime').checked,
        minimize_app: document.getElementById('punish_t2_minimize').checked,
        score_tax: parseInt(document.getElementById('punish_t2_tax').value, 10) || 0
      },
      tier3: {
        countdown_modal: document.getElementById('punish_t3_modal').checked,
        app_action: t3Action,
        minimize_app: t3Action === 'minimize',
        kill_app: t3Action === 'terminate' || t3Action === 'close_window',
        typing_challenge: document.getElementById('punish_t3_typing').checked,
        math_challenge: document.getElementById('punish_t3_math').checked,
        lock_seconds: parseInt(document.getElementById('punish_t3_lock_s').value, 10) || 0,
        score_tax: parseInt(document.getElementById('punish_t3_tax').value, 10) || 0,
        physical_action: document.getElementById('punish_t3_physical').checked
      },
      tier4: {
        alarm_sound: document.getElementById('punish_t4_alarm').checked,
        proctor_drill: document.getElementById('punish_t4_proctor').checked,
        app_action: t4Action,
        minimize_app: t4Action === 'minimize',
        kill_app: t4Action === 'terminate' || t4Action === 'close_window',
        typing_challenge: document.getElementById('punish_t4_typing').checked,
        math_challenge: document.getElementById('punish_t4_math').checked,
        lock_seconds: parseInt(document.getElementById('punish_t4_lock_s').value, 10) || 0,
        score_tax: parseInt(document.getElementById('punish_t4_tax').value, 10) || 0,
        physical_action: document.getElementById('punish_t4_physical').checked
      }
    };
  }

  return cfg;
}

async function saveAllConfig() {
  const updated = gatherConfigFromForm();
  try {
    const res = await fetch('/api/config', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(updated)
    });
    const d = await res.json();
    if (d.ok) {
      currentConfig = updated;
      clearDirty();
      showToast('Configuration applied and saved to config.yaml!', '#10b981');
    } else {
      showToast('Save failed: ' + (d.error || 'Unknown error'), '#ef4444');
    }
  } catch (e) {
    showToast('Failed to save config: ' + e.message, '#ef4444');
  }
}

function discardChanges() {
  populateFormWithConfig(currentConfig);
  clearDirty();
  showToast('Changes reverted.', '#64748b');
}

// ---------------- CHIP MANAGERS ----------------
function renderChips(key, items) {
  const box = document.getElementById('chips_' + key);
  if (!box) return;
  const isDistract = key.includes('distract') || key.includes('black');
  const isNeutral = key.includes('neutral');
  const cls = isDistract ? 'distract' : (isNeutral ? 'neutral' : '');
  box.innerHTML = items.map((val, idx) => `
    <span class="chip ${cls}">
      ${escapeHtml(val)}
      <span class="chip-del" onclick="deleteChip('${key}', ${idx})">✕</span>
    </span>
  `).join('');
}

function addChip(key) {
  const inputMap = {
    'whitelist': 'add_whitelist_input',
    'study_patterns': 'add_study_input',
    'website_whitelist': 'add_web_wl_input',
    'blacklist': 'add_blacklist_input',
    'distraction_patterns': 'add_distract_input',
    'website_blacklist': 'add_web_bl_input'
  };
  const input = document.getElementById(inputMap[key]);
  if (!input || !input.value.trim()) return;
  const val = input.value.trim();
  const target = key.startsWith('website') ? (currentConfig.browser = currentConfig.browser || {}) : (currentConfig.desktop = currentConfig.desktop || {});
  target[key] = target[key] || [];
  target[key].push(val);
  input.value = '';
  renderChips(key, target[key]);
  markDirty();
}

function deleteChip(key, idx) {
  const target = key.startsWith('website') ? (currentConfig.browser = currentConfig.browser || {}) : (currentConfig.desktop = currentConfig.desktop || {});
  if (target[key]) {
    target[key].splice(idx, 1);
    renderChips(key, target[key]);
    markDirty();
  }
}

// ---------------- PROFILES ----------------
async function loadProfiles() {
  try {
    const res = await fetch('/api/profiles');
    const profiles = await res.json();
    const grid = document.getElementById('profiles_grid');
    grid.innerHTML = profiles.map(p => `
      <div class="profile-card ${p.is_active ? 'active' : ''}">
        <div>
          <div style="display:flex; justify-content:space-between; align-items:flex-start; margin-bottom:8px;">
            <span class="badge" style="background:${p.color || '#38bdf8'}22; color:${p.color || '#38bdf8'}; border:1px solid ${p.color || '#38bdf8'}44;">
              ${escapeHtml(p.badge || 'Profile')}
            </span>
            ${p.is_active ? '<span style="color:#10b981; font-size:11px; font-weight:700;">● ACTIVE</span>' : ''}
          </div>
          <h3 style="font-size:16px; margin-bottom:6px;">${escapeHtml(p.name)}</h3>
          <p style="font-size:12px; color:var(--text-muted); margin-bottom:12px;">${escapeHtml(p.description || '')}</p>
        </div>
        <div style="display:flex; justify-content:space-between; align-items:center; margin-top:14px; border-top:1px solid rgba(255,255,255,0.06); padding-top:12px;">
          ${!p.is_active ? `<button class="btn btn-sm btn-primary" onclick="switchProfile('${p.id}')">Activate</button>` : '<span style="font-size:12px; color:var(--text-muted);">Current</span>'}
          ${!p.builtin ? `<button class="btn btn-sm btn-danger" onclick="deleteProfile('${p.id}')">Delete</button>` : ''}
        </div>
      </div>
    `).join('');

    const active = profiles.find(p => p.is_active);
    if (active) {
      document.getElementById('header_profile_name').innerText = active.name;
    }
  } catch (e) {
    console.error("Profiles error", e);
  }
}

async function switchProfile(id) {
  try {
    const res = await fetch('/api/profiles/switch', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ profile_id: id })
    });
    const d = await res.json();
    if (d.ok) {
      showToast(`Switched to profile: ${d.profile.name}`, '#38bdf8');
      loadConfig();
    } else {
      showToast('Switch error: ' + d.error, '#ef4444');
    }
  } catch (e) {
    showToast('Failed to switch profile: ' + e.message, '#ef4444');
  }
}

function openNewProfileModal() {
  document.getElementById('profile_modal').style.display = 'flex';
}

async function createProfile() {
  const id = document.getElementById('np_id').value.trim();
  const name = document.getElementById('np_name').value.trim();
  const badge = document.getElementById('np_badge').value.trim();
  const desc = document.getElementById('np_desc').value.trim();
  if (!id || !name) {
    alert("Please provide both ID and Name.");
    return;
  }
  const payload = {
    id: id,
    name: name,
    badge: badge || 'Custom',
    description: desc,
    config: gatherConfigFromForm()
  };
  try {
    const res = await fetch('/api/profiles/save', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload)
    });
    const d = await res.json();
    if (d.ok) {
      document.getElementById('profile_modal').style.display = 'none';
      showToast(`Created profile '${name}'`, '#10b981');
      switchProfile(id);
    } else {
      alert("Error: " + d.error);
    }
  } catch (e) {
    alert("Error: " + e.message);
  }
}

async function deleteProfile(id) {
  if (!confirm(`Are you sure you want to delete profile '${id}'?`)) return;
  try {
    const res = await fetch('/api/profiles', {
      method: 'DELETE',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ profile_id: id })
    });
    const d = await res.json();
    if (d.ok) {
      showToast('Profile deleted', '#64748b');
      loadProfiles();
    } else {
      alert("Error: " + d.error);
    }
  } catch (e) {
    alert("Error: " + e.message);
  }
}

// ---------------- SEVERITY PRESETS ----------------
function applySeverityPreset(level) {
  if (level === 'lenient') {
    document.getElementById('rate_paper').value = 12;
    document.getElementById('rate_screen').value = 10;
    document.getElementById('rate_distract').value = -10;
    document.getElementById('rate_phone').value = -10;
    document.getElementById('ev_phone_glance').value = -2;
    document.getElementById('ev_phone_sustained').value = -12;
    document.getElementById('ev_left_frame').value = -15;
    document.getElementById('alert_countdown_s').value = 10;
    document.getElementById('alert_sustained_s').value = 60;
  } else if (level === 'balanced') {
    document.getElementById('rate_paper').value = 10;
    document.getElementById('rate_screen').value = 8;
    document.getElementById('rate_distract').value = -20;
    document.getElementById('rate_phone').value = -15;
    document.getElementById('ev_phone_glance').value = -5;
    document.getElementById('ev_phone_sustained').value = -25;
    document.getElementById('ev_left_frame').value = -30;
    document.getElementById('alert_countdown_s').value = 5;
    document.getElementById('alert_sustained_s').value = 30;
  } else if (level === 'strict') {
    document.getElementById('rate_paper').value = 8;
    document.getElementById('rate_screen').value = 6;
    document.getElementById('rate_distract').value = -30;
    document.getElementById('rate_phone').value = -25;
    document.getElementById('ev_phone_glance').value = -10;
    document.getElementById('ev_phone_sustained').value = -35;
    document.getElementById('ev_left_frame').value = -40;
    document.getElementById('alert_countdown_s').value = 3;
    document.getElementById('alert_sustained_s').value = 15;
  } else if (level === 'lockdown') {
    document.getElementById('rate_paper').value = 5;
    document.getElementById('rate_screen').value = 4;
    document.getElementById('rate_distract').value = -45;
    document.getElementById('rate_phone').value = -40;
    document.getElementById('ev_phone_glance').value = -20;
    document.getElementById('ev_phone_sustained').value = -50;
    document.getElementById('ev_left_frame').value = -50;
    document.getElementById('alert_countdown_s').value = 2;
    document.getElementById('alert_sustained_s').value = 10;
  }
  // Refresh labels
  document.getElementById('val_rate_paper').innerText = '+' + document.getElementById('rate_paper').value + '/m';
  document.getElementById('val_rate_screen').innerText = '+' + document.getElementById('rate_screen').value + '/m';
  document.getElementById('val_rate_distract').innerText = document.getElementById('rate_distract').value + '/m';
  document.getElementById('val_rate_phone').innerText = document.getElementById('rate_phone').value + '/m';
  markDirty();
  showToast(`Applied ${level.toUpperCase()} severity preset!`, '#f59e0b');
}

// ---------------- DESKTOP INSPECT & SANDBOX ----------------
async function inspectActiveWindow() {
  const box = document.getElementById('inspect_result');
  box.innerHTML = '<p style="color:var(--text-muted)">Sampling active foreground window...</p>';
  try {
    const res = await fetch('/api/desktop/inspect');
    const d = await res.json();
    lastInspected = d;
    const isStudy = d.label === 'STUDY';
    const isDistract = d.label === 'DISTRACTION';
    const badgeCls = isStudy ? 'badge-study' : (isDistract ? 'badge-distract' : 'badge-neutral');
    box.innerHTML = `
      <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:8px;">
        <span class="badge ${badgeCls}" style="font-size:13px;">VERDICT: ${d.label}</span>
        <span style="font-size:11px; color:var(--text-muted);">Classifier: ${escapeHtml(d.classifier)}</span>
      </div>
      <div style="font-size:13px; font-weight:700; margin-bottom:4px;">Window: <span style="color:#fff;">${escapeHtml(d.title || '(untitled)')}</span></div>
      <div style="font-size:12px; color:var(--text-muted);">Process: <b>${escapeHtml(d.process || 'unknown')}</b> ${d.domain ? '· Domain: <b>' + escapeHtml(d.domain) + '</b>' : ''}</div>
      <div style="margin-top:6px; font-size:12px; color:var(--primary);">Evidence: <code>${escapeHtml(d.evidence || 'none')}</code></div>
    `;
    document.getElementById('btn_train_study').disabled = false;
    document.getElementById('btn_train_distract').disabled = false;
  } catch (e) {
    box.innerHTML = `<p style="color:var(--danger)">Error querying window: ${escapeHtml(e.message)}</p>`;
  }
}

async function trainActive(label) {
  if (!lastInspected) return;
  try {
    const res = await fetch('/api/desktop/train', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        title: lastInspected.title,
        process: lastInspected.process,
        label: label
      })
    });
    const d = await res.json();
    if (d.ok) {
      showToast(`Trained signature as ${label}!`, label === 'STUDY' ? '#10b981' : '#ef4444');
      loadTrainedRules();
      inspectActiveWindow();
    }
  } catch (e) {
    alert("Train failed: " + e.message);
  }
}

async function runSandboxTest() {
  const title = document.getElementById('sb_title').value;
  const proc = document.getElementById('sb_proc').value;
  const domain = document.getElementById('sb_domain').value;
  const box = document.getElementById('sb_verdict');
  try {
    const res = await fetch('/api/desktop/test-pattern', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ title, process: proc, domain })
    });
    const d = await res.json();
    const isStudy = d.label === 'STUDY';
    const isDistract = d.label === 'DISTRACTION';
    const badgeCls = isStudy ? 'badge-study' : (isDistract ? 'badge-distract' : 'badge-neutral');
    box.innerHTML = `
      <div style="display:flex; justify-content:space-between; align-items:center;">
        <span class="badge ${badgeCls}">RESULT: ${d.label}</span>
        <span style="font-size:11px; color:var(--text-muted);">Rule: <code>${escapeHtml(d.evidence)}</code></span>
      </div>
    `;
  } catch (e) {
    box.innerHTML = `<span style="color:var(--danger)">Test error: ${e.message}</span>`;
  }
}

async function loadTrainedRules() {
  try {
    const res = await fetch('/api/desktop/rules');
    const d = await res.json();
    const tbody = document.querySelector('#table_trained tbody');
    if (!d.trained || d.trained.length === 0) {
      tbody.innerHTML = '<tr><td colspan="5" style="text-align:center; color:var(--text-muted);">No custom trained application signatures yet.</td></tr>';
      return;
    }
    tbody.innerHTML = d.trained.map(r => `
      <tr>
        <td><code>${escapeHtml(r.signature)}</code></td>
        <td>${escapeHtml(r.title || r.process || '–')}</td>
        <td><span class="badge ${r.label === 'STUDY' ? 'badge-study' : (r.label === 'DISTRACTION' ? 'badge-distract' : 'badge-neutral')}">${r.label}</span></td>
        <td style="font-size:11px; color:var(--text-muted);">${escapeHtml(r.updated_at || '–')}</td>
        <td><button class="btn btn-sm btn-danger" onclick="deleteTrainedRule('${escapeHtml(r.signature)}')">Delete</button></td>
      </tr>
    `).join('');
  } catch (e) {
    console.error("Trained rules error", e);
  }
}

async function deleteTrainedRule(signature) {
  if (!confirm(`Delete learned signature '${signature}'?`)) return;
  try {
    const res = await fetch('/api/desktop/train', {
      method: 'DELETE',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ signature })
    });
    const d = await res.json();
    if (d.ok) {
      showToast('Deleted trained rule', '#64748b');
      loadTrainedRules();
    }
  } catch (e) {
    alert("Delete error: " + e.message);
  }
}

// ---------------- RUNNING APPLICATIONS & PROCESSES ----------------
let allRunningProcesses = [];

async function loadRunningProcesses() {
  const tbody = document.getElementById('processes_tbody');
  tbody.innerHTML = '<tr><td colspan="5" style="text-align:center; color:var(--text-muted);">Scanning running processes across system...</td></tr>';
  try {
    const res = await fetch('/api/desktop/processes');
    const d = await res.json();
    allRunningProcesses = d.processes || [];
    filterRunningProcesses();
  } catch (e) {
    tbody.innerHTML = `<tr><td colspan="5" style="text-align:center; color:var(--danger);">Error scanning processes: ${escapeHtml(e.message)}</td></tr>`;
  }
}

function filterRunningProcesses() {
  const kw = (document.getElementById('proc_search').value || '').toLowerCase().trim();
  const scope = document.getElementById('proc_filter_scope').value;
  const labelFilter = document.getElementById('proc_filter_label').value;

  const filtered = allRunningProcesses.filter(p => {
    if (scope === 'user' && p.is_system) return false;
    if (scope === 'window' && !p.has_window) return false;
    if (labelFilter !== 'all' && p.label !== labelFilter) return false;
    if (kw) {
      const matchName = (p.name || '').toLowerCase().includes(kw);
      const matchTitle = (p.title || '').toLowerCase().includes(kw);
      if (!matchName && !matchTitle) return false;
    }
    return true;
  });

  const tbody = document.getElementById('processes_tbody');
  document.getElementById('proc_count_info').innerText = `Showing ${filtered.length} of ${allRunningProcesses.length} processes`;
  if (filtered.length === 0) {
    tbody.innerHTML = '<tr><td colspan="5" style="text-align:center; color:var(--text-muted);">No matching processes found.</td></tr>';
    return;
  }

  tbody.innerHTML = filtered.map(p => {
    const isStudy = p.label === 'STUDY';
    const isDistract = p.label === 'DISTRACTION';
    const badgeCls = isStudy ? 'badge-study' : (isDistract ? 'badge-distract' : 'badge-neutral');
    return `
      <tr>
        <td><b>${escapeHtml(p.name)}</b> <span style="font-size:11px; color:var(--text-dim);">(PID ${p.pid})</span></td>
        <td style="max-width:280px; overflow:hidden; text-overflow:ellipsis; white-space:nowrap;" title="${escapeHtml(p.title)}">
          ${p.title ? `<span style="color:#fff;">${escapeHtml(p.title)}</span>` : '<span style="color:var(--text-dim); font-size:11px;">(Background Process)</span>'}
        </td>
        <td style="font-size:12px; color:var(--text-muted);">${p.memory_mb ? p.memory_mb + ' MB' : '–'}</td>
        <td>
          <span class="badge ${badgeCls}">${p.label}</span>
          <div style="font-size:10px; color:var(--text-dim); margin-top:2px; max-width:140px; overflow:hidden; text-overflow:ellipsis; white-space:nowrap;" title="${escapeHtml(p.evidence || '')}">${escapeHtml(p.evidence || '')}</div>
        </td>
        <td>
          <div style="display:flex; gap:6px;">
            <button class="btn btn-sm btn-success" style="padding:3px 8px; font-size:11px;" onclick="chooseProcessLabel('${escapeHtml(p.name)}', '${escapeHtml(p.title || '')}', 'STUDY')">✓ Work</button>
            <button class="btn btn-sm btn-danger" style="padding:3px 8px; font-size:11px;" onclick="chooseProcessLabel('${escapeHtml(p.name)}', '${escapeHtml(p.title || '')}', 'DISTRACTION')">✕ Distraction</button>
            <button class="btn btn-sm" style="padding:3px 8px; font-size:11px;" onclick="chooseProcessLabel('${escapeHtml(p.name)}', '${escapeHtml(p.title || '')}', 'NEUTRAL')">⏸ Neutral</button>
          </div>
        </td>
      </tr>
    `;
  }).join('');
}

async function chooseProcessLabel(name, title, label) {
  try {
    const res = await fetch('/api/desktop/train', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        title: title || name,
        process: name,
        label: label
      })
    });
    const d = await res.json();
    if (d.ok) {
      showToast(`${name} marked as ${label}!`, label === 'STUDY' ? '#10b981' : (label === 'DISTRACTION' ? '#ef4444' : '#64748b'));
      allRunningProcesses.forEach(p => {
        if (p.name.toLowerCase() === name.toLowerCase()) {
          p.label = label;
          p.evidence = `trained:${name.toLowerCase()}`;
        }
      });
      filterRunningProcesses();
      loadTrainedRules();
    }
  } catch (e) {
    alert("Error: " + e.message);
  }
}

// ---------------- HISTORICAL LOGS & TIME TRAVEL ----------------
async function loadSessionsList() {
  try {
    const res = await fetch('/api/logs/sessions');
    const sessions = await res.json();
    const sel = document.getElementById('log_session_select');
    sel.innerHTML = '<option value="all">All Sessions Combined</option>' + sessions.map(s => `
      <option value="${s.id}">Session #${s.id} · ${s.started_at ? s.started_at.replace('T', ' ') : ''} (${s.duration}, ${s.violations} violations)</option>
    `).join('');
  } catch (e) {
    console.error("Sessions error", e);
  }
}

function onTimeWindowChange() {
  const win = document.getElementById('log_time_window').value;
  document.getElementById('custom_time_row').style.display = (win === 'custom') ? 'grid' : 'none';
  logPageOffset = 0;
  loadHistoricalLogs();
}

function onLogFilterChange() {
  logPageOffset = 0;
  loadHistoricalLogs();
}

let searchTimer = null;
function onLogSearchInput() {
  clearTimeout(searchTimer);
  searchTimer = setTimeout(() => { logPageOffset = 0; loadHistoricalLogs(); }, 300);
}

function changePage(delta) {
  const limit = parseInt(document.getElementById('log_limit').value, 10);
  logPageOffset = Math.max(0, logPageOffset + (delta * limit));
  loadHistoricalLogs();
}

async function loadHistoricalLogs() {
  const sid = document.getElementById('log_session_select').value;
  const win = document.getElementById('log_time_window').value;
  const type = document.getElementById('log_type_filter').value;
  const limit = parseInt(document.getElementById('log_limit').value, 10);
  const kw = document.getElementById('log_search').value.trim();

  let start_time = '', end_time = '';
  const now = new Date();
  if (win === 'today') {
    start_time = now.toISOString().split('T')[0] + 'T00:00:00';
  } else if (win === '24h') {
    start_time = new Date(now.getTime() - 24 * 3600 * 1000).toISOString().slice(0, 19);
  } else if (win === '7d') {
    start_time = new Date(now.getTime() - 7 * 24 * 3600 * 1000).toISOString().slice(0, 19);
  } else if (win === 'custom') {
    start_time = document.getElementById('custom_start_time').value;
    end_time = document.getElementById('custom_end_time').value;
  }

  // Load session curve if specific session selected
  const curveWrap = document.getElementById('session_curve_wrap');
  if (sid !== 'all' && sid) {
    loadSessionCurve(sid);
    curveWrap.style.display = 'block';
  } else {
    curveWrap.style.display = 'none';
  }

  const params = new URLSearchParams({
    session_id: sid,
    start_time: start_time,
    end_time: end_time,
    type: type,
    keyword: kw,
    limit: limit,
    offset: logPageOffset
  });

  try {
    const res = await fetch('/api/logs?' + params.toString());
    const data = await res.json();
    const tbody = document.getElementById('logs_tbody');
    if (!data.events || data.events.length === 0) {
      tbody.innerHTML = '<tr><td colspan="6" style="text-align:center; color:var(--text-muted);">No events found matching your filter criteria.</td></tr>';
      document.getElementById('logs_count_info').innerText = 'Showing 0 events';
      return;
    }

    tbody.innerHTML = data.events.map(e => {
      const isPenalty = e.type === 'penalty' || e.type.includes('sustained') || e.type.includes('absent');
      const isDistract = (e.data && e.data.label === 'DISTRACTION');
      const isStudy = (e.data && e.data.label === 'STUDY');
      const badgeCls = isPenalty || isDistract ? 'badge-distract' : (isStudy ? 'badge-study' : 'badge-neutral');
      const displayData = typeof e.data === 'object' ? (e.data.title || e.data.detail || e.data.error || e.data.reason || JSON.stringify(e.data).slice(0, 70)) : e.data;
      return `
        <tr>
          <td style="font-size:12px; font-family:monospace; color:var(--text-muted);">${escapeHtml(e.ts.replace('T', ' '))}</td>
          <td><span style="color:var(--text-dim); font-size:12px;">#${e.session_id}</span></td>
          <td><span class="badge ${badgeCls}">${escapeHtml(e.type)}</span></td>
          <td style="font-size:12px; color:var(--text-muted);">${escapeHtml(e.source || '–')}</td>
          <td style="max-width:380px; overflow:hidden; text-overflow:ellipsis; white-space:nowrap;" title="${escapeHtml(JSON.stringify(e.data))}">
            ${escapeHtml(String(displayData))}
          </td>
          <td>
            <button class="btn btn-sm" onclick="inspectEvent(${e.id}, ${escapeHtml(JSON.stringify(JSON.stringify(e)))})">Inspect</button>
          </td>
        </tr>
      `;
    }).join('');

    const fromNum = logPageOffset + 1;
    const toNum = Math.min(logPageOffset + data.events.length, data.total);
    document.getElementById('logs_count_info').innerText = `Showing ${fromNum}–${toNum} of ${data.total} events`;
    document.getElementById('btn_prev_page').disabled = logPageOffset === 0;
    document.getElementById('btn_next_page').disabled = toNum >= data.total;
  } catch (e) {
    console.error("Logs fetch error", e);
  }
}

async function loadSessionCurve(sid) {
  try {
    const res = await fetch('/api/logs/curve?session_id=' + sid);
    const pts = await res.json();
    const svg = document.getElementById('session_curve');
    if (!pts || pts.length === 0) {
      svg.innerHTML = '<text x="10" y="50" fill="#64748b" font-size="12">No score points recorded for this session.</text>';
      return;
    }
    const n = pts.length || 1;
    let p = '';
    pts.forEach((v, i) => {
      const x = 10 + i * (680 / n);
      const y = 90 - (v.score * 0.8);
      p += (i ? 'L' : 'M') + x.toFixed(1) + ' ' + y.toFixed(1) + ' ';
    });
    svg.innerHTML = `<path d="${p}" stroke="#38bdf8" fill="none" stroke-width="2.5"/>`;
  } catch (e) {}
}

function inspectEvent(id, fullJsonStr) {
  try {
    const eventObj = JSON.parse(fullJsonStr);
    document.getElementById('modal_event_title').innerText = `Event #${eventObj.id} · ${eventObj.type}`;
    document.getElementById('modal_event_json').innerText = JSON.stringify(eventObj, null, 2);
    document.getElementById('event_modal').style.display = 'flex';
  } catch (e) {
    alert("Error parsing event: " + e.message);
  }
}

function copyEventJson() {
  const text = document.getElementById('modal_event_json').innerText;
  navigator.clipboard.writeText(text);
  showToast('Copied JSON to clipboard!', '#10b981');
}

function exportLogs(format) {
  const sid = document.getElementById('log_session_select').value;
  const win = document.getElementById('log_time_window').value;
  const type = document.getElementById('log_type_filter').value;
  const kw = document.getElementById('log_search').value.trim();

  let start_time = '', end_time = '';
  const now = new Date();
  if (win === 'today') start_time = now.toISOString().split('T')[0] + 'T00:00:00';
  else if (win === '24h') start_time = new Date(now.getTime() - 24 * 3600 * 1000).toISOString().slice(0, 19);
  else if (win === '7d') start_time = new Date(now.getTime() - 7 * 24 * 3600 * 1000).toISOString().slice(0, 19);

  const url = `/api/logs/export?format=${format}&session_id=${sid}&start_time=${start_time}&end_time=${end_time}&type=${type}&keyword=${kw}`;
  window.open(url, '_blank');
}

// ---------------- PLUGINS ----------------
async function loadPlugins() {
  try {
    const res = await fetch('/api/plugins');
    const plugins = await res.json();
    const grid = document.getElementById('plugins_grid');
    grid.innerHTML = plugins.map(p => `
      <div class="plugin-card">
        <div>
          <div class="plugin-header">
            <div style="display:flex; align-items:center; gap:8px;">
              <span style="font-size:22px;">${p.icon || '🧩'}</span>
              <h3 style="font-size:15px;">${escapeHtml(p.name)}</h3>
            </div>
            <label class="switch">
              <input type="checkbox" ${p.enabled ? 'checked' : ''} onchange="togglePlugin('${p.id}', this.checked)">
              <span class="slider"></span>
            </label>
          </div>
          <p style="font-size:12px; color:var(--text-muted); margin-bottom:14px;">${escapeHtml(p.description)}</p>
        </div>
        <div style="background:#0a1424; border:1px solid var(--border); border-radius:6px; padding:10px; font-size:12px;">
          ${Object.entries(p.config || {}).map(([k, v]) => `
            <div style="display:flex; justify-content:space-between; margin-bottom:4px;">
              <span style="color:var(--text-muted);">${escapeHtml(k)}:</span>
              <b>${escapeHtml(String(v))}</b>
            </div>
          `).join('')}
        </div>
      </div>
    `).join('');
  } catch (e) {
    console.error("Plugins error", e);
  }
}

async function togglePlugin(id, enabled) {
  try {
    const res = await fetch('/api/plugins/toggle', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ plugin: id, enabled: enabled })
    });
    const d = await res.json();
    if (d.ok) {
      showToast(`Plugin '${id}' ${enabled ? 'activated' : 'deactivated'}`, enabled ? '#10b981' : '#64748b');
      loadConfig();
    }
  } catch (e) {
    alert("Plugin toggle error: " + e.message);
  }
}

// ---------------- LIVE MONITOR & STATS ----------------
async function tickLiveStats() {
  try {
    const res = await fetch('/api/stats');
    const s = await res.json();
    document.getElementById('ov_score').innerText = s.now.score !== undefined ? s.now.score : '–';
    document.getElementById('ov_state').innerText = s.now.state || '–';
    document.getElementById('ov_tier').innerText = 'TIER: ' + (s.now.tier || '–').toUpperCase();

    // Score curve
    const c = document.getElementById('live_curve');
    let p = '';
    const n = s.scores.length || 1;
    s.scores.forEach((v, i) => {
      const x = 10 + i * (680 / n);
      const y = 80 - 0.7 * v[1];
      p += (i ? 'L' : 'M') + x.toFixed(1) + ' ' + y.toFixed(1) + ' ';
    });
    c.innerHTML = '<path d="' + p + '" stroke="#22c55e" fill="none" stroke-width="2.5"/>';

    // Lifetime
    document.getElementById('ov_life').innerHTML = Object.entries(s.life).map(([k, v]) => `
      <div style="display:inline-block; margin-right:18px;">${escapeHtml(k.replace('_', ' '))}: <b>${v}</b></div>
    `).join('');

    // Top distractions
    document.getElementById('ov_analysis').innerHTML = `
      <b>Top Distraction Sources:</b><br>
      ${Object.entries(s.analysis.sources || {}).map(([k, v]) => `· ${escapeHtml(k)}: <b>${v} checks</b>`).join('<br>')}
    `;

    // Heatmap table
    let h = '<table><tr><th>Day \\ Hour</th>';
    for (let i = 0; i < 24; i++) h += `<th>${i}</th>`;
    h += '</tr>';
    for (const d of s.days || []) {
      h += `<tr><td style="font-size:11px; font-weight:600;">${d}</td>`;
      for (let i = 0; i < 24; i++) {
        const v = s.heat[d + '|' + i] || 0;
        const cls = v > 5 ? 'hm-3' : (v > 2 ? 'hm-2' : (v > 0 ? 'hm-1' : ''));
        h += `<td><div class="hm-cell ${cls}" title="${d} ${i}:00 - ${v} distractions"></div></td>`;
      }
      h += '</tr>';
    }
    h += '</table>';
    document.getElementById('ov_heatmap').innerHTML = h;
  } catch (e) {}
}

// ---------------- DIAGNOSTICS ----------------
async function loadDiagnostics() {
  const box = document.getElementById('diag_content');
  box.innerHTML = 'Sampling environment and hardware...';
  try {
    const res = await fetch('/api/diagnostics');
    const d = await res.json();
    box.innerHTML = `
      <div class="grid-2">
        <div>
          <b>Operating System:</b> ${escapeHtml(d.os)}<br>
          <b>Python Version:</b> ${escapeHtml(d.python)}<br>
          <b>Monitors Detected:</b> ${d.monitors}<br>
          <b>Webcam (Index 0):</b> <span style="color:${d.camera_ok ? '#10b981' : '#ef4444'}">${d.camera_ok ? 'Available & Accessible' : 'Unavailable'}</span>
        </div>
        <div>
          <b>OCR Status:</b> ${d.ocr_ok ? 'Tesseract OCR Available' : 'OCR Disabled / Not Installed'}<br>
          <b>Active Sentinel Port:</b> ${d.port}<br>
          <b>MediaPipe / Vision Status:</b> ${escapeHtml(d.mediapipe || 'OK')}<br>
          <b>Database Events Logged:</b> ${d.db_events}
        </div>
      </div>
    `;
  } catch (e) {
    box.innerHTML = '<span style="color:var(--danger)">Error fetching diagnostics: ' + e.message + '</span>';
  }
}

function escapeHtml(str) {
  if (str === null || str === undefined) return '';
  return String(str).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
}

function closeModal(e, id) {
  if (e.target.id === id) {
    document.getElementById(id).style.display = 'none';
  }
}

// Initialization
loadConfig();
loadSessionsList();
loadTrainedRules();
loadRunningProcesses();
setInterval(tickLiveStats, 3000);
tickLiveStats();

// ---------------- PUNISHMENTS & CHALLENGES ----------------
function onPledgeInput() {
  const el = document.getElementById('punish_typing_pledge');
  if (!el) return;
  const count = el.value.length;
  const lbl = document.getElementById('pledge_char_count');
  if (lbl) lbl.innerText = count + ' characters';
  markDirty();
}

function setPledgePreset(text) {
  const el = document.getElementById('punish_typing_pledge');
  if (el) {
    el.value = text;
    onPledgeInput();
  }
}

let simLockRemaining = 0;
let simInterval = null;
let simMathAnswer = 0;
let simMathSolved = false;
let simTypingSolved = false;

function testBrowserChallenge() {
  const modal = document.getElementById('browser_challenge_modal');
  modal.style.display = 'flex';
  
  // Random mental math
  const a = Math.floor(Math.random() * 10) + 6;
  const b = Math.floor(Math.random() * 8) + 7;
  const c = Math.floor(Math.random() * 20) + 10;
  simMathAnswer = (a * b) - c;
  document.getElementById('sim_math_q').innerText = `(${a} × ${b}) - ${c} =`;
  document.getElementById('sim_math_ans').value = '';
  document.getElementById('sim_math_status').innerText = 'Required to unlock';
  document.getElementById('sim_math_status').style.color = 'var(--text-muted)';
  simMathSolved = false;

  // Pledge
  const activePledge = document.getElementById('punish_typing_pledge').value.trim() || 'I will not trade my long-term goals for short-term digital distractions.';
  document.getElementById('sim_typing_target').innerText = activePledge;
  document.getElementById('sim_typing_input').value = '';
  document.getElementById('sim_typing_status').innerText = '0 / ' + activePledge.length + ' characters';
  document.getElementById('sim_typing_status').style.color = 'var(--text-muted)';
  simTypingSolved = false;

  // Physical text
  const phys = document.getElementById('punish_physical_text').value.trim();
  document.getElementById('sim_physical_text').innerText = phys;

  // Lock timer
  simLockRemaining = parseInt(document.getElementById('punish_t3_lock_s').value, 10) || 6;
  if (simInterval) clearInterval(simInterval);
  
  updateSimAckState();
  simInterval = setInterval(() => {
    if (simLockRemaining > 0) {
      simLockRemaining--;
      document.getElementById('sim_countdown').innerText = simLockRemaining > 0 ? simLockRemaining : '0';
      updateSimAckState();
    } else {
      clearInterval(simInterval);
      simInterval = null;
      updateSimAckState();
    }
  }, 1000);
}

function checkSimMath() {
  const user = document.getElementById('sim_math_ans').value.trim();
  const status = document.getElementById('sim_math_status');
  if (user === String(simMathAnswer)) {
    simMathSolved = true;
    status.innerText = '✓ Solved!';
    status.style.color = '#34d399';
  } else {
    simMathSolved = false;
    status.innerText = user ? 'Incorrect' : 'Required to unlock';
    status.style.color = user ? '#f87171' : 'var(--text-muted)';
  }
  updateSimAckState();
}

function checkSimTyping() {
  const target = document.getElementById('sim_typing_target').innerText.trim();
  const user = document.getElementById('sim_typing_input').value;
  const status = document.getElementById('sim_typing_status');
  if (user === target) {
    simTypingSolved = true;
    status.innerText = '✓ Commitment Pledge Verified Verbatim!';
    status.style.color = '#34d399';
  } else if (target.startsWith(user)) {
    simTypingSolved = false;
    status.innerText = `Matching: ${user.length} / ${target.length} characters`;
    status.style.color = '#93c5fd';
  } else {
    simTypingSolved = false;
    status.innerText = 'Typo detected! Check spelling & casing.';
    status.style.color = '#f87171';
  }
  updateSimAckState();
}

function updateSimAckState() {
  const btn = document.getElementById('sim_btn_ack');
  if (simLockRemaining > 0) {
    btn.disabled = true;
    btn.innerText = `🔒 Cooldown Lock (${simLockRemaining}s remaining)`;
    btn.style.background = '#1e293b';
    btn.style.color = '#64748b';
  } else if (!simMathSolved) {
    btn.disabled = true;
    btn.innerText = '🧠 Solve Mental Math Problem To Unlock';
    btn.style.background = '#1e293b';
    btn.style.color = '#60a5fa';
  } else if (!simTypingSolved) {
    btn.disabled = true;
    btn.innerText = '✍️ Type Commitment Pledge Above To Unlock';
    btn.style.background = '#1e293b';
    btn.style.color = '#c4b5fd';
  } else {
    btn.disabled = false;
    btn.innerText = '✓ I AM BACK IN FOCUS — DISMISS';
    btn.style.background = '#10b981';
    btn.style.color = '#ffffff';
  }
}

function onSimAck() {
  closeBrowserChallenge();
  showToast('Challenge completed! Focus commitment acknowledged.', '#10b981');
}

function closeBrowserChallenge() {
  if (simInterval) clearInterval(simInterval);
  simInterval = null;
  document.getElementById('browser_challenge_modal').style.display = 'none';
}

async function testDesktopChallenge() {
  try {
    const res = await fetch('/api/punishments/test-modal', { method: 'POST' });
    const d = await res.json();
    if (d.ok) {
      showToast('Desktop alert triggered on your display screen!', '#38bdf8');
    } else {
      showToast('Failed to trigger desktop alert: ' + (d.error || 'Desktop UI not active'), '#ef4444');
    }
  } catch (e) {
    showToast('Failed to contact engine: ' + e.message, '#ef4444');
  }
}

</script>
</body>
</html>
"""


class QuietTCPServer(socketserver.TCPServer):
    allow_reuse_address = True
    daemon_threads = True

    def handle_error(self, request, client_address):
        import sys
        exc_type, exc_value, _ = sys.exc_info()
        if exc_type in (ConnectionAbortedError, ConnectionResetError, BrokenPipeError, TimeoutError):
            return
        if isinstance(exc_value, OSError) and getattr(exc_value, "winerror", None) in (10053, 10054):
            return


class DashboardServer:
    """Production-grade Dashboard & Interactive Settings Server for Sentinel."""

    def __init__(self, db, arbiter, cfg):
        self.db = db
        self.arbiter = arbiter
        self.cfg = cfg
        port = int(cfg.get("ui.dashboard_port", 8765))
        db2 = self.db
        arb2 = self.arbiter
        cfg2 = self.cfg

        class H(http.server.BaseHTTPRequestHandler):
            def log_message(self, *a):
                pass  # Suppress default noisy console logs

            def handle(self):
                try:
                    super().handle()
                except (ConnectionAbortedError, ConnectionResetError, BrokenPipeError, TimeoutError, OSError):
                    pass

            def finish(self):
                try:
                    if hasattr(self, "wfile") and not self.wfile.closed:
                        self.wfile.flush()
                    super().finish()
                except (ConnectionAbortedError, ConnectionResetError, BrokenPipeError, TimeoutError, OSError):
                    pass

            def _send_bytes(self, payload: bytes, content_type: str, status=200, headers=None):
                try:
                    self.send_response(status)
                    self.send_header("Content-Type", content_type)
                    self.send_header("Access-Control-Allow-Origin", "*")
                    self.send_header("Content-Length", str(len(payload)))
                    if headers:
                        for k, v in headers.items():
                            self.send_header(k, v)
                    self.end_headers()
                    self.wfile.write(payload)
                except (ConnectionAbortedError, ConnectionResetError, BrokenPipeError, TimeoutError, OSError):
                    pass

            def _send_json(self, data, status=200):
                payload = json.dumps(data, default=str).encode("utf-8")
                self._send_bytes(payload, "application/json; charset=utf-8", status=status)

            def _read_json(self):
                length = int(self.headers.get("Content-Length", 0))
                if length == 0:
                    return {}
                raw = self.rfile.read(length).decode("utf-8")
                return json.loads(raw)

            def do_OPTIONS(self):
                self.send_response(200)
                self.send_header("Access-Control-Allow-Origin", "*")
                self.send_header("Access-Control-Allow-Methods", "GET, POST, DELETE, OPTIONS")
                self.send_header("Access-Control-Allow-Headers", "Content-Type")
                self.end_headers()

            def do_GET(self):
                parsed = urllib.parse.urlparse(self.path)
                path = parsed.path
                query = urllib.parse.parse_qs(parsed.query)

                if path == "/api/stats":
                    now = getattr(arb2, "latest", None) or {"score": 100, "tier": "excellent", "state": "studying", "level": 0}
                    sid = getattr(db2, "session_id", None) or db2.latest_session_id()
                    scores = db2.scores_for(sid) if sid else []
                    events = db2.events_for(sid) if sid else []
                    heat = db2.heatmap(14)
                    days = sorted({k.split("|")[0] for k in heat}, reverse=True)[:14]
                    sources = collections.Counter()
                    violations = 0
                    for _, kind, raw in events:
                        try:
                            data = json.loads(raw or "{}")
                        except Exception:
                            data = {}
                        if kind == "desktop.activity" and data.get("label") == "DISTRACTION":
                            sources[data.get("domain") or data.get("title") or "unknown"] += 1
                        if kind in ("penalty", "phone.sustained", "presence.absent"):
                            violations += 1
                    try:
                        phone_samples = db2._exec("SELECT COUNT(*) FROM phone_training").fetchone()[0]
                    except Exception:
                        phone_samples = 0
                    self._send_json({
                        "now": now,
                        "scores": [[i, s[1]] for i, s in enumerate(scores[-200:])],
                        "events": [[e[0], e[1], (e[2] or "")[:60]] for e in events[-60:]],
                        "life": db2.lifetime_stats(),
                        "heat": heat,
                        "days": days,
                        "analysis": {
                            "violations": violations,
                            "evidence_queued": len(db2.queued_evidence()),
                            "trained_apps": len(db2.activity_labels()),
                            "phone_samples": phone_samples,
                            "sources": dict(sources.most_common(8)),
                        },
                    })

                elif path == "/api/config":
                    self._send_json(cfg2.to_dict())

                elif path == "/api/profiles":
                    active_id = cfg2.get("active_profile", "deep_work")
                    profiles = list_profiles(active_id=active_id)
                    self._send_json(profiles)

                elif path == "/api/desktop/inspect":
                    from sentinel.utils import platform
                    from sentinel.utils.browser import active_chrome_domain
                    from sentinel.vision.classifiers import RuleBasedClassifier

                    title, proc = platform.active_window()
                    domain = active_chrome_domain(title, proc, cfg2)
                    clf = RuleBasedClassifier(cfg2, db2.activity_labels())
                    label, evidence = clf.classify(title, proc, "", None, browser_domain=domain)
                    self._send_json({
                        "title": title,
                        "process": proc,
                        "domain": domain,
                        "label": label,
                        "evidence": evidence,
                        "classifier": type(clf).__name__,
                    })

                elif path == "/api/desktop/processes":
                    from sentinel.utils.platform import list_running_applications
                    from sentinel.vision.classifiers import RuleBasedClassifier

                    apps = list_running_applications()
                    clf = RuleBasedClassifier(cfg2, db2.activity_labels())
                    enriched = []
                    for a in apps:
                        label, evidence = clf.classify(a.get("title", ""), a.get("name", ""), "", None)
                        enriched.append({
                            "name": a.get("name", ""),
                            "title": a.get("title", ""),
                            "pid": a.get("pid", 0),
                            "has_window": a.get("has_window", False),
                            "memory_mb": a.get("memory_mb", 0.0),
                            "is_system": a.get("is_system", False),
                            "label": label,
                            "evidence": evidence,
                        })
                    self._send_json({"processes": enriched})

                elif path == "/api/desktop/rules":
                    trained_rows = db2.activity_labels_full()
                    trained = [
                        {"signature": r[0], "label": r[1], "title": r[2], "process": r[3], "updated_at": r[4]}
                        for r in trained_rows
                    ]
                    self._send_json({
                        "study_patterns": cfg2.get("desktop.study_patterns", []),
                        "distraction_patterns": cfg2.get("desktop.distraction_patterns", []),
                        "neutral_patterns": cfg2.get("desktop.neutral_patterns", []),
                        "whitelist": cfg2.get("desktop.whitelist", []),
                        "blacklist": cfg2.get("desktop.blacklist", []),
                        "website_whitelist": cfg2.get("browser.website_whitelist", []),
                        "website_blacklist": cfg2.get("browser.website_blacklist", []),
                        "trained": trained,
                    })

                elif path == "/api/logs/sessions":
                    sessions = db2.list_sessions(limit=100)
                    self._send_json(sessions)

                elif path == "/api/logs":
                    sid = query.get("session_id", [None])[0]
                    start_time = query.get("start_time", [None])[0]
                    end_time = query.get("end_time", [None])[0]
                    etype = query.get("type", [None])[0]
                    kw = query.get("keyword", [None])[0]
                    limit = int(query.get("limit", [100])[0])
                    offset = int(query.get("offset", [0])[0])
                    res = db2.query_logs(
                        session_id=sid,
                        start_time=start_time,
                        end_time=end_time,
                        event_type=etype,
                        keyword=kw,
                        limit=limit,
                        offset=offset,
                    )
                    self._send_json(res)

                elif path == "/api/logs/curve":
                    sid = query.get("session_id", [None])[0]
                    if sid:
                        points = db2.session_score_curve(sid)
                        self._send_json(points)
                    else:
                        self._send_json([])

                elif path == "/api/logs/export":
                    fmt = query.get("format", ["json"])[0]
                    sid = query.get("session_id", [None])[0]
                    start_time = query.get("start_time", [None])[0]
                    end_time = query.get("end_time", [None])[0]
                    etype = query.get("type", [None])[0]
                    kw = query.get("keyword", [None])[0]
                    events = db2.export_logs_data(
                        session_id=sid,
                        start_time=start_time,
                        end_time=end_time,
                        event_type=etype,
                        keyword=kw,
                    )
                    if fmt == "csv":
                        output = io.StringIO()
                        writer = csv.writer(output)
                        writer.writerow(["id", "ts", "session_id", "type", "source", "data"])
                        for e in events:
                            writer.writerow([e["id"], e["ts"], e["session_id"], e["type"], e["source"], json.dumps(e["data"])])
                        csv_bytes = output.getvalue().encode("utf-8")
                        self._send_bytes(csv_bytes, "text/csv; charset=utf-8", headers={"Content-Disposition": 'attachment; filename="sentinel_logs.csv"'})
                    else:
                        payload = json.dumps(events, indent=2, default=str).encode("utf-8")
                        self._send_bytes(payload, "application/json; charset=utf-8", headers={"Content-Disposition": 'attachment; filename="sentinel_logs.json"'})

                elif path == "/api/punishments":
                    from sentinel.alerts.punishments import PunishmentManager, DEFAULT_PLEDGES
                    pm = PunishmentManager(cfg2, db2)
                    self._send_json({
                        "config": cfg2.get("punishments", {}),
                        "presets": DEFAULT_PLEDGES,
                        "sample_math": pm.generate_math_challenge("medium"),
                    })

                elif path == "/api/plugins":
                    plugins = list_available_plugins(cfg2)
                    self._send_json(plugins)

                elif path == "/api/diagnostics":
                    import platform as pf
                    from sentinel.utils import platform as s_plat
                    cam_ok = False
                    try:
                        import cv2
                        cap = cv2.VideoCapture(0)
                        cam_ok = cap.isOpened()
                        cap.release()
                    except Exception:
                        pass
                    ocr_ok = False
                    try:
                        import pytesseract
                        pytesseract.get_tesseract_version()
                        ocr_ok = True
                    except Exception:
                        pass
                    mon_count = 1
                    try:
                        import mss
                        mss_cls = getattr(mss, "MSS", None) or mss.mss
                        with mss_cls() as sct:
                            mon_count = len(sct.monitors) - 1
                    except Exception:
                        pass
                    total_events = db2._exec("SELECT COUNT(*) FROM events").fetchone()[0]
                    self._send_json({
                        "os": f"{s_plat.OS_NAME} {pf.release()}",
                        "python": pf.python_version(),
                        "camera_ok": cam_ok,
                        "ocr_ok": ocr_ok,
                        "monitors": mon_count,
                        "port": port,
                        "db_events": total_events,
                    })

                else:
                    # Serve SPA HTML
                    payload = _HTML_PAGE.encode("utf-8")
                    self._send_bytes(payload, "text/html; charset=utf-8")

            def do_POST(self):
                parsed = urllib.parse.urlparse(self.path)
                path = parsed.path

                if path == "/api/config":
                    data = self._read_json()
                    try:
                        deep_merge(cfg2.data, data)
                        cfg2.save("config.yaml")
                        # Hot reload arbiter runtime score clamp
                        if arb2 and hasattr(arb2, "lock"):
                            scoring = cfg2.get("scoring")
                            if scoring:
                                with arb2.lock:
                                    arb2.clamp = tuple(scoring.get("clamp", [0, 100]))
                        # Hot reload desktop sentinel rules if active
                        if arb2 and getattr(arb2, "sentinels", None):
                            for s in arb2.sentinels:
                                if s.name == "desktop" and hasattr(s, "reload_rules"):
                                    s.reload_rules()
                        self._send_json({"ok": True})
                    except Exception as e:
                        self._send_json({"ok": False, "error": str(e)}, status=400)

                elif path == "/api/profiles/switch":
                    data = self._read_json()
                    pid = data.get("profile_id")
                    try:
                        prof = apply_profile(pid, cfg2, arbiter=arb2, db=db2)
                        self._send_json({"ok": True, "profile": prof})
                    except Exception as e:
                        self._send_json({"ok": False, "error": str(e)}, status=400)

                elif path == "/api/profiles/save":
                    data = self._read_json()
                    try:
                        saved = save_custom_profile(data)
                        self._send_json({"ok": True, "profile": saved})
                    except Exception as e:
                        self._send_json({"ok": False, "error": str(e)}, status=400)

                elif path == "/api/desktop/test-pattern":
                    from sentinel.vision.classifiers import RuleBasedClassifier

                    data = self._read_json()
                    title = data.get("title", "")
                    proc = data.get("process", "")
                    domain = data.get("domain", "")
                    clf = RuleBasedClassifier(cfg2, db2.activity_labels())
                    label, evidence = clf.classify(title, proc, "", None, browser_domain=domain)
                    self._send_json({"label": label, "evidence": evidence})

                elif path == "/api/desktop/train":
                    data = self._read_json()
                    title = data.get("title", "")
                    proc = data.get("process", "")
                    label = data.get("label", "STUDY")
                    try:
                        sig = db2.train_activity(title, proc, label)
                        if arb2 and getattr(arb2, "sentinels", None):
                            for s in arb2.sentinels:
                                if s.name == "desktop" and hasattr(s, "reload_rules"):
                                    s.reload_rules()
                        self._send_json({"ok": True, "signature": sig})
                    except Exception as e:
                        self._send_json({"ok": False, "error": str(e)}, status=400)

                elif path == "/api/punishments/test-modal":
                    from sentinel.alerts.punishments import PunishmentManager
                    pm = PunishmentManager(cfg2, db2, arbiter=arb2)
                    sample_math = pm.generate_math_challenge(cfg2.get("punishments.math_difficulty", "medium"))
                    challenge_payload = {
                        "summary_badge": "SIMULATED ENFORCEMENT TEST",
                        "typing_challenge": True,
                        "typing_pledge": pm.get_typing_pledge(),
                        "math_challenge": True,
                        "math_data": sample_math,
                        "lock_seconds": 6,
                        "physical_action": True,
                        "physical_action_text": pm.get_physical_action_text(),
                    }
                    if arb2 and getattr(arb2, "ui", None):
                        try:
                            arb2.ui.start_countdown(
                                "TEST ENFORCEMENT CHALLENGE",
                                "Simulated tier punishment preview. Test typing and math challenge.",
                                allow_ack=True,
                                challenge_opts=challenge_payload
                            )
                        except Exception:
                            pass
                    self._send_json({"ok": True, "challenge": challenge_payload})

                elif path == "/api/plugins/toggle":
                    data = self._read_json()
                    pname = data.get("plugin")
                    enabled = bool(data.get("enabled"))
                    try:
                        ok = toggle_plugin(pname, enabled, arbiter=arb2, cfg=cfg2)
                        self._send_json({"ok": ok})
                    except Exception as e:
                        self._send_json({"ok": False, "error": str(e)}, status=400)

                else:
                    self._send_json({"error": "Endpoint not found"}, status=404)

            def do_DELETE(self):
                parsed = urllib.parse.urlparse(self.path)
                path = parsed.path

                if path == "/api/profiles":
                    data = self._read_json()
                    pid = data.get("profile_id")
                    try:
                        ok = delete_custom_profile(pid)
                        self._send_json({"ok": ok})
                    except Exception as e:
                        self._send_json({"ok": False, "error": str(e)}, status=400)

                elif path == "/api/desktop/train":
                    data = self._read_json()
                    sig = data.get("signature")
                    try:
                        ok = db2.delete_activity_label(sig)
                        if arb2 and getattr(arb2, "sentinels", None):
                            for s in arb2.sentinels:
                                if s.name == "desktop" and hasattr(s, "reload_rules"):
                                    s.reload_rules()
                        self._send_json({"ok": ok})
                    except Exception as e:
                        self._send_json({"ok": False, "error": str(e)}, status=400)

                else:
                    self._send_json({"error": "Endpoint not found"}, status=404)

        self.srv = QuietTCPServer(("127.0.0.1", port), H)
        self.srv.daemon_threads = True
        self.thread = threading.Thread(target=self.srv.serve_forever, daemon=True)

    @property
    def url(self):
        return f"http://127.0.0.1:{self.srv.server_address[1]}"

    def start(self):
        self.thread.start()

    def stop(self):
        if self.thread.is_alive():
            self.srv.shutdown()
        self.srv.server_close()
