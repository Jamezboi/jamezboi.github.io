import queue
import time
import threading
import tkinter as tk
from tkinter import ttk

TIER_COLORS = {
    "excellent": "#48d597",
    "okay": "#f6c85f",
    "warning": "#ff9f43",
    "critical": "#ff5d73",
    "collapse": "#ff5d73",
}
BG, SURFACE, BORDER, TEXT, MUTED = "#07101f", "#101d31", "#263957", "#f6f8fc", "#a9b8d0"
STATE_ICONS = {
    "studying_paper": "📖",
    "studying_screen": "💻",
    "neutral_idle": "⏸️",
    "distracted_screen": "⚠️",
    "sustained_phone": "📱",
    "absent": "🚪",
    "break": "🍅",
    "UNKNOWN": "❓",
    "UNCALIBRATED": "⚙️",
}


class NullUI:
    """Headless stand-in for simulation/CI. Every method is a no-op."""

    def start_countdown(self, head="", sub="", allow_ack=True, promise_text="I promise to return to my work.", challenge_opts=None):
        pass

    def stop_countdown(self):
        pass

    def update_countdown(self, n, total):
        pass

    def show_fullscreen_warning(self, title="", subtitle="", detail="", badge="", duration_s=6):
        pass

    def stop_fullscreen_warning(self):
        pass

    def start_lockdown_flash(self, title="", subtitle="", challenge_opts=None):
        pass

    def stop_lockdown_flash(self):
        pass

    def alarm_flash(self, on):
        pass

    def __getattr__(self, _):
        return lambda *a, **k: None


class SentinelUI:
    """Production-grade Cyber-Tactical Desktop Focus Console.
    
    Equipped with real-time focus rings, session telemetry, quick profile switcher,
    audible fullscreen warning HUD, and full-screen flashing red lockdown screen.
    """

    def __init__(self, cfg):
        self.cfg = cfg
        self.root = tk.Tk()
        self.root.withdraw()
        self.q = queue.Queue()
        self._tkimg = None
        self._flash = False
        self._flash_job = None
        self._lockdown_flash_step = False
        self._session_start_t = time.time()
        self._active_window_text = "Tracking active app..."
        self._active_window_status = "WORK"

        self.on_ack = None
        self.on_recalibrate = None
        self.on_train_activity = None
        self.on_goal = None
        self.on_check_desktop = None
        self.on_train_phone = None
        self.arbiter = None

        self._build_widget()
        self.root.after(30, self._drain)
        self.root.after(1000, self._update_session_clock)

    # ---------- thread bridge ----------
    def schedule(self, fn):
        self.q.put(fn)

    def _drain(self):
        while True:
            try:
                fn = self.q.get_nowait()
            except queue.Empty:
                break
            try:
                fn()
            except Exception:
                pass
        self.root.after(30, self._drain)

    # ---------- widget construction ----------
    def _build_widget(self):
        w = self.root
        w.title("Sentinel | Focus Console v2.4 (Production)")
        w.configure(bg=BG)
        width, height = 1040, 710
        x = max(0, (w.winfo_screenwidth() - width) // 2)
        y = max(0, (w.winfo_screenheight() - height) // 2)
        w.geometry(f"{width}x{height}+{x}+{y}")
        w.minsize(920, 640)

        # 1. TOP HEADER BAR
        header = tk.Frame(w, bg="#0d1930", padx=28, pady=16)
        header.pack(fill="x")

        # Shield Logo
        emblem = tk.Canvas(header, width=48, height=48, bg="#0d1930", highlightthickness=0)
        emblem.create_oval(3, 3, 45, 45, fill="#2e63f3", outline="#83a5ff", width=2)
        emblem.create_text(24, 24, text="S", fill="#fff", font=("Segoe UI", 20, "bold"))
        emblem.pack(side="left", padx=(0, 14))

        titles = tk.Frame(header, bg="#0d1930")
        titles.pack(side="left", fill="x", expand=True)
        title_row = tk.Frame(titles, bg="#0d1930")
        title_row.pack(anchor="w")
        tk.Label(title_row, text="SENTINEL 2.0", bg="#0d1930", fg=TEXT, font=("Segoe UI", 20, "bold")).pack(side="left")
        if bool(self.cfg.get("pro.unlocked", False)):
            tk.Label(title_row, text="👑 PRO EDITION", bg="#2a1b05", fg="#fbbf24", font=("Segoe UI", 9, "bold"), padx=8, pady=2, highlightbackground="#f59e0b", highlightthickness=1).pack(side="left", padx=(10, 0))
        tk.Label(titles, text="Autonomous Focus & Discipline Enforcement · Private Local Processing", bg="#0d1930", fg="#9fb7ff", font=("Segoe UI", 9)).pack(anchor="w", pady=(1, 0))

        # Header Right Actions
        h_right = tk.Frame(header, bg="#0d1930")
        h_right.pack(side="right")

        # Session Timer Pill
        self.lbl_clock = tk.Label(h_right, text="⏱️ 00:00:00", bg="#162744", fg="#38bdf8", font=("Segoe UI", 10, "bold"), padx=12, pady=6)
        self.lbl_clock.pack(side="left", padx=(0, 10))

        # Mute Toggle
        is_muted = bool(self.cfg.get("alerts.mute", False))
        self.btn_mute = tk.Button(
            h_right,
            text="🔇 Muted" if is_muted else "🔊 Audio: ON",
            command=self._toggle_audio_mute,
            bg="#20314d", activebackground="#304869", activeforeground="#fff",
            fg="#e4ebf8", relief="flat", cursor="hand2", padx=12, pady=6, font=("Segoe UI", 9, "bold")
        )
        self.btn_mute.pack(side="left", padx=(0, 8))

        # Settings
        tk.Button(
            h_right, text="⚙  Settings", command=self._open_settings,
            bg="#20314d", activebackground="#304869", activeforeground="#fff",
            fg="#e4ebf8", relief="flat", cursor="hand2", padx=12, pady=6, font=("Segoe UI", 9, "bold")
        ).pack(side="left", padx=(0, 8))

        # End Session
        tk.Button(
            h_right, text="✕ End Session", command=self.close_app,
            bg="#8f2433", activebackground="#b83043", activeforeground="#fff",
            fg="#fff", relief="flat", cursor="hand2", padx=14, pady=6, font=("Segoe UI", 9, "bold")
        ).pack(side="left")

        # 2. SUBHEADER: QUICK CONTROLS & ACTIVE APP BAR
        sub = tk.Frame(w, bg="#091322", padx=28, pady=10, highlightbackground="#172844", highlightthickness=1)
        sub.pack(fill="x")

        # Profile Switcher Pills
        p_frame = tk.Frame(sub, bg="#091322")
        p_frame.pack(side="left")
        tk.Label(p_frame, text="Active Profile:", bg="#091322", fg=MUTED, font=("Segoe UI", 9, "bold")).pack(side="left", padx=(0, 8))

        self.prof_btns = {}
        for pid, label in [("deep_work", "🛡️ Deep Work"), ("exam_strict", "🚨 Exam Lockdown"), ("coding_dev", "💻 Dev Mode"), ("casual_reading", "📖 Casual")]:
            b = tk.Button(
                p_frame, text=label, command=lambda p=pid: self._switch_profile(p),
                bg="#132036", fg="#94a3b8", activebackground="#2563eb", activeforeground="#fff",
                relief="flat", cursor="hand2", padx=10, pady=3, font=("Segoe UI", 8, "bold")
            )
            b.pack(side="left", padx=(0, 5))
            self.prof_btns[pid] = b

        active_p = self.cfg.get("active_profile", "deep_work")
        if active_p in self.prof_btns:
            self.prof_btns[active_p].config(bg="#2563eb", fg="#ffffff")

        # Quick Test Hub (Right side of subheader)
        t_frame = tk.Frame(sub, bg="#091322")
        t_frame.pack(side="right")
        tk.Label(t_frame, text="Test Alerts:", bg="#091322", fg=MUTED, font=("Segoe UI", 8, "bold")).pack(side="left", padx=(0, 6))

        tk.Button(
            t_frame, text="⚠️ Warning HUD", command=self._test_warning_hud,
            bg="#362208", fg="#f59e0b", activebackground="#d97706", activeforeground="#fff",
            relief="flat", cursor="hand2", padx=8, pady=3, font=("Segoe UI", 8, "bold")
        ).pack(side="left", padx=(0, 5))

        tk.Button(
            t_frame, text="🚨 Red Alarm", command=self._test_red_alarm,
            bg="#3b1117", fg="#ef4444", activebackground="#dc2626", activeforeground="#fff",
            relief="flat", cursor="hand2", padx=8, pady=3, font=("Segoe UI", 8, "bold")
        ).pack(side="left")

        # 3. MAIN BODY SPLIT
        body = tk.Frame(w, bg=BG, padx=28, pady=20)
        body.pack(fill="both", expand=True)
        body.grid_columnconfigure(0, weight=5)
        body.grid_columnconfigure(1, weight=6)
        body.grid_rowconfigure(0, weight=1)

        # LEFT COLUMN: FOCUS STATUS & TELEMETRY
        left = tk.Frame(body, bg=SURFACE, padx=24, pady=20, highlightbackground=BORDER, highlightthickness=1)
        left.grid(row=0, column=0, sticky="nsew", padx=(0, 10))

        tk.Label(left, text="FOCUS TELEMETRY", bg=SURFACE, fg=MUTED, font=("Segoe UI", 10, "bold")).pack(anchor="w")

        # Ring Canvas
        self.ring = tk.Canvas(left, width=200, height=200, bg=SURFACE, highlightthickness=0)
        self.ring.pack(pady=(16, 4))
        self.ring.create_oval(16, 16, 184, 184, fill="#0a1629", outline="#263b5d", width=2)
        self._arc = self.ring.create_arc(
            16, 16, 184, 184, start=90, extent=-359.9, style="arc", width=12, outline="#22c55e"
        )
        self._score_txt = self.ring.create_text(
            100, 92, text="100", fill=TEXT, font=("Segoe UI", 38, "bold")
        )
        self.ring.create_text(100, 122, text="FOCUS SCORE", fill=MUTED, font=("Segoe UI", 8, "bold"))

        self.icon = tk.Label(left, text="●", bg=SURFACE, fg="#48d597", font=("Segoe UI", 15, "bold"))
        self.icon.pack()

        self.state = tk.Label(left, text="Safeguards Active", bg=SURFACE, fg="#48d597", font=("Segoe UI", 12, "bold"))
        self.state.pack(pady=(1, 10))

        # Active App Pill
        self.active_app_frame = tk.Frame(left, bg="#0a1629", padx=12, pady=8, highlightbackground="#223654", highlightthickness=1)
        self.active_app_frame.pack(fill="x", pady=(0, 12))
        tk.Label(self.active_app_frame, text="CURRENT DESKTOP FOREGROUND:", bg="#0a1629", fg="#64748b", font=("Segoe UI", 8, "bold")).pack(anchor="w")
        self.lbl_active_window = tk.Label(
            self.active_app_frame, text=self._active_window_text, bg="#0a1629", fg="#e2e8f0",
            font=("Segoe UI", 9, "bold"), anchor="w", wraplength=340, justify="left"
        )
        self.lbl_active_window.pack(fill="x", pady=(2, 0))

        # Status Line / Safeguards description
        self.line1 = tk.Label(
            left, text="Desk mode active · zero cloud telemetry · 100% local processing",
            bg="#091424", fg=MUTED, font=("Segoe UI", 9), justify="left", anchor="w", padx=12, pady=10, wraplength=340
        )
        self.line1.pack(fill="x")

        # RIGHT COLUMN: SESSION PLAN & MACHINE LEARNING TRAINING
        right = tk.Frame(body, bg=SURFACE, padx=26, pady=20, highlightbackground=BORDER, highlightthickness=1)
        right.grid(row=0, column=1, sticky="nsew", padx=(10, 0))

        tk.Label(right, text="SESSION OUTCOME GOAL", bg=SURFACE, fg=MUTED, font=("Segoe UI", 10, "bold")).pack(anchor="w")
        tk.Label(right, text="What are you working on?", bg=SURFACE, fg=TEXT, font=("Segoe UI", 16, "bold")).pack(anchor="w", pady=(6, 2))

        self.goal_var = tk.StringVar(value=self.cfg.get("session.label", ""))
        goal_box = tk.Frame(right, bg=SURFACE)
        goal_box.pack(fill="x", pady=(4, 6))

        goal_entry = tk.Entry(
            goal_box, textvariable=self.goal_var, bg="#091629", fg=TEXT, insertbackground=TEXT,
            relief="flat", highlightthickness=1, highlightbackground="#314763", highlightcolor="#5b82ff",
            font=("Segoe UI", 11)
        )
        goal_entry.pack(side="left", fill="x", expand=True, ipady=7)

        tk.Button(
            goal_box, text="Save Goal", command=self._save_goal,
            bg="#3465f4", activebackground="#5480ff", activeforeground="#fff", fg="#fff",
            relief="flat", cursor="hand2", padx=14, pady=7, font=("Segoe UI", 9, "bold")
        ).pack(side="left", padx=(8, 0))

        # Goal preset chips
        preset_frame = tk.Frame(right, bg=SURFACE)
        preset_frame.pack(anchor="w", pady=(0, 16))
        for p_text in ["Problem Set", "Research Paper", "Coding Feature", "Exam Review"]:
            tk.Button(
                preset_frame, text=p_text, command=lambda t=p_text: self._set_goal_preset(t),
                bg="#16253d", fg="#94a3b8", activebackground="#2563eb", activeforeground="#fff",
                relief="flat", cursor="hand2", padx=8, pady=2, font=("Segoe UI", 8)
            ).pack(side="left", padx=(0, 6))

        # TEACH SENTINEL
        tk.Label(right, text="TEACH SENTINEL RULES", bg=SURFACE, fg=MUTED, font=("Segoe UI", 10, "bold")).pack(anchor="w")
        tk.Label(
            right, text="Classify foreground applications in real time. Choices persist for future sessions.",
            bg=SURFACE, fg=MUTED, font=("Segoe UI", 9), wraplength=440, justify="left"
        ).pack(anchor="w", pady=(4, 8))

        train = tk.Frame(right, bg=SURFACE)
        train.pack(fill="x", pady=(0, 10))
        tk.Button(
            train, text="✓  Mark as Work", command=lambda: self._train("STUDY"),
            bg="#197a59", activebackground="#249b70", activeforeground="#fff", fg="#fff",
            relief="flat", cursor="hand2", padx=14, pady=8, font=("Segoe UI", 9, "bold")
        ).pack(side="left", padx=(0, 8))

        tk.Button(
            train, text="✕  Mark as Distraction", command=lambda: self._train("DISTRACTION"),
            bg="#a44a22", activebackground="#ca6030", activeforeground="#fff", fg="#fff",
            relief="flat", cursor="hand2", padx=14, pady=8, font=("Segoe UI", 9, "bold")
        ).pack(side="left", padx=(0, 8))

        tk.Button(
            train, text="⚡ Inspect Now", command=lambda: self.on_check_desktop and self.on_check_desktop(),
            bg="#20314d", activebackground="#304869", activeforeground="#fff", fg="#e4ebf8",
            relief="flat", cursor="hand2", padx=12, pady=8, font=("Segoe UI", 9, "bold")
        ).pack(side="left")

        # PHONE CALIBRATION
        tk.Label(right, text="PHONE DETECTION CALIBRATION", bg=SURFACE, fg=MUTED, font=("Segoe UI", 10, "bold")).pack(anchor="w", pady=(8, 0))
        tk.Label(
            right, text="Label desk view to train the YOLO neural detector.",
            bg=SURFACE, fg=MUTED, font=("Segoe UI", 9), wraplength=440, justify="left"
        ).pack(anchor="w", pady=(4, 8))

        phone_train = tk.Frame(right, bg=SURFACE)
        phone_train.pack(fill="x")
        tk.Button(
            phone_train, text="📱 Phone Visible on Desk", command=lambda: self._train_phone(True),
            bg="#6747b9", activebackground="#8062d5", activeforeground="#fff", fg="#fff",
            relief="flat", cursor="hand2", padx=12, pady=7, font=("Segoe UI", 9)
        ).pack(side="left", padx=(0, 8))

        tk.Button(
            phone_train, text="🖥️ Desk is Clear", command=lambda: self._train_phone(False),
            bg="#20314d", activebackground="#304869", activeforeground="#fff", fg="#e4ebf8",
            relief="flat", cursor="hand2", padx=12, pady=7, font=("Segoe UI", 9)
        ).pack(side="left")

        self.thumb = None
        w.deiconify()

    def _update_session_clock(self):
        elapsed = int(time.time() - self._session_start_t)
        hrs = elapsed // 3600
        mins = (elapsed % 3600) // 60
        secs = elapsed % 60
        if hasattr(self, "lbl_clock"):
            self.lbl_clock.config(text=f"⏱️ {hrs:02d}:{mins:02d}:{secs:02d}")
        self.root.after(1000, self._update_session_clock)

    def _toggle_audio_mute(self):
        curr = bool(self.cfg.get("alerts.mute", False))
        new_val = not curr
        self.cfg.data.setdefault("alerts", {})["mute"] = new_val
        if hasattr(self, "btn_mute"):
            self.btn_mute.config(text="🔇 Muted" if new_val else "🔊 Audio: ON")
        self.toast("Audio muted" if new_val else "Audio alert sound enabled", "#38bdf8" if not new_val else "#64748b")

    def _switch_profile(self, pid):
        try:
            from sentinel.core.profiles import apply_profile
            apply_profile(pid, self.cfg, arbiter=self.arbiter)
            for k, b in self.prof_btns.items():
                if k == pid:
                    b.config(bg="#2563eb", fg="#ffffff")
                else:
                    b.config(bg="#132036", fg="#94a3b8")
            self.toast(f"Switched profile to {pid.replace('_', ' ').title()}", "#10b981")
        except Exception as exc:
            self.toast(f"Error switching profile: {exc}", "#ef4444")

    def _set_goal_preset(self, text):
        self.goal_var.set(text)
        self._save_goal()

    def _save_goal(self):
        if self.on_goal:
            self.on_goal(self.goal_var.get())
        self.toast("Session outcome goal saved.", "#22c55e")

    def _train(self, label):
        if self.on_train_activity:
            self.on_train_activity(label)

    def _train_phone(self, is_phone):
        if self.on_train_phone:
            self.on_train_phone(is_phone)

    def _open_settings(self):
        import webbrowser
        port = int(self.cfg.get("ui.dashboard_port", 8765))
        url = f"http://127.0.0.1:{port}"
        webbrowser.open(url)
        self.toast("Opening Settings & Analytics in browser…", "#38bdf8")

    def bind_arbiter(self, arbiter):
        self.arbiter = arbiter

        def poll():
            snap = arbiter.latest
            if snap:
                self.set_snapshot(snap)
            self.root.after(300, poll)

        self.root.after(300, poll)

    def set_snapshot(self, s):
        def f():
            col = TIER_COLORS.get(s["tier"], "#eab308")
            self.ring.itemconfig(self._arc, extent=-(s["score"] * 3.6), outline=col)
            self.ring.itemconfig(self._score_txt, text=str(int(s["score"])))
            self.icon.config(text=STATE_ICONS.get(s["state"], "❓"))
            self.state.config(
                text=f"{s['tier'].upper()}{' · ' + s['gaze'] if s['gaze'] not in ('UNKNOWN',) else ''}"
                + (" · MUTED" if s.get("stand_down") else ""),
                fg=col,
            )
            # Update detected app line if desktop state is present
            if s.get("desktop"):
                st = s.get("desktop")
                self.lbl_active_window.config(
                    text=f"Detected: {s.get('state', '').replace('_', ' ').upper()} · Classification: {st}",
                    fg="#48d597" if st == "STUDY" else ("#ff5d73" if st == "DISTRACTION" else "#a9b8d0")
                )

        self.schedule(f)

    def set_thumbnail(self, bgr):
        pass

    def set_status_line(self, slot, text):
        def f():
            self.line1.config(text=text)

        self.schedule(f)

    # ---------- toasts ----------
    def toast(self, msg, color="#f97316", ms=3500):
        def f():
            t = tk.Toplevel(self.root)
            t.overrideredirect(True)
            t.attributes("-topmost", True)
            try:
                t.attributes("-alpha", 0.94)
            except Exception:
                pass
            t.configure(bg="#17233a")
            frame = tk.Frame(t, bg="#17233a", highlightbackground=color, highlightthickness=2, padx=16, pady=12)
            frame.pack()
            tk.Label(frame, text="SENTINEL NOTIFICATION", bg="#17233a", fg=color, font=("Segoe UI", 9, "bold")).pack(anchor="w")
            tk.Label(frame, text=msg, bg="#17233a", fg=TEXT, font=("Segoe UI", 11, "bold"), wraplength=380, justify="left").pack(anchor="w", pady=(3, 0))
            t.geometry(f"+{self.root.winfo_x() + 24}+{self.root.winfo_y() + 102}")
            t.after(ms, t.destroy)

        self.schedule(f)

    # ---------- AUDIBLE & FULLSCREEN WARNING (TIER 2) ----------
    def show_fullscreen_warning(self, title="DISTRACTION DETECTED", subtitle="", detail="", badge="", duration_s=6):
        def f():
            if hasattr(self, "_warn_win") and self._warn_win and self._warn_win.winfo_exists():
                return
            self._warn_win = tk.Toplevel(self.root)
            self._warn_win.overrideredirect(True)
            self._warn_win.attributes("-topmost", True)
            self._warn_win.configure(bg="#070b14")

            # Border glow
            outer = tk.Frame(self._warn_win, bg="#070b14", highlightbackground="#f59e0b", highlightthickness=3)
            outer.place(relx=0, rely=0, relwidth=1, relheight=1)

            # Center Card
            card = tk.Frame(outer, bg="#0e1726", highlightbackground="#fbbf24", highlightthickness=2, padx=40, pady=32)
            card.place(relx=0.5, rely=0.5, anchor="center", width=720, height=440)

            tk.Label(card, text="⚠️", bg="#0e1726", fg="#fbbf24", font=("Segoe UI", 48)).pack(pady=(0, 6))
            tk.Label(card, text=title, bg="#0e1726", fg="#fbbf24", font=("Segoe UI", 22, "bold")).pack(pady=(0, 4))
            tk.Label(card, text=subtitle, bg="#0e1726", fg=TEXT, font=("Segoe UI", 13, "bold"), wraplength=640, justify="center").pack(pady=(0, 8))

            if badge:
                b_frame = tk.Frame(card, bg="#27160c", highlightbackground="#d97706", highlightthickness=1, padx=12, pady=4)
                b_frame.pack(fill="x", pady=(0, 10))
                tk.Label(b_frame, text=f"⚡ ACTION: {badge}", bg="#27160c", fg="#fcd34d", font=("Segoe UI", 9, "bold")).pack()

            tk.Label(
                card,
                text="Non-study activity detected. Please return to your focus material immediately to prevent countdown escalation and score penalties.",
                bg="#0e1726", fg=MUTED, font=("Segoe UI", 11), wraplength=620, justify="center"
            ).pack(pady=(0, 20))

            tk.Button(
                card, text="✓  I Understand — Refocus Now", command=self.stop_fullscreen_warning,
                bg="#f59e0b", activebackground="#fbbf24", activeforeground="#000", fg="#000",
                relief="flat", cursor="hand2", padx=24, pady=10, font=("Segoe UI", 11, "bold")
            ).pack()

            self._warn_win.geometry(f"{self.root.winfo_screenwidth()}x{self.root.winfo_screenheight()}+0+0")
            self._warn_win.deiconify()
            self._warn_win.lift()

            # Auto dismiss after duration_s
            self._warn_timer_id = self.root.after(int(duration_s * 1000), self.stop_fullscreen_warning)

        self.schedule(f)

    def stop_fullscreen_warning(self):
        def f():
            if hasattr(self, "_warn_timer_id") and self._warn_timer_id:
                try:
                    self.root.after_cancel(self._warn_timer_id)
                except Exception:
                    pass
                self._warn_timer_id = None
            if hasattr(self, "_warn_win") and self._warn_win:
                try:
                    self._warn_win.destroy()
                except Exception:
                    pass
                self._warn_win = None

        self.schedule(f)

    def _test_warning_hud(self):
        self.show_fullscreen_warning(
            title="TEST DISTRACTION WARNING",
            subtitle="Chrome / Discord Foreground Activity Detected",
            badge="Audible warning chime + voice drill",
            duration_s=6
        )

    # ---------- FINAL SCREEN FLASHING RED LOCKDOWN (TIER 4) ----------
    def start_lockdown_flash(self, title="CRITICAL FOCUS LOCKDOWN", subtitle="", challenge_opts=None):
        def f():
            if not hasattr(self, "_lockdown_win") or not self._lockdown_win or not self._lockdown_win.winfo_exists():
                self._lockdown_win = tk.Toplevel(self.root)
                self._lockdown_win.overrideredirect(True)
                self._lockdown_win.attributes("-topmost", True)

            opts = challenge_opts or {}
            self._lockdown_flash_step = True

            # Clear children
            for c in self._lockdown_win.winfo_children():
                try:
                    c.destroy()
                except Exception:
                    pass

            self._lockdown_card = tk.Frame(
                self._lockdown_win, bg="#0e0a12", highlightbackground="#ff1e42", highlightthickness=3,
                padx=48, pady=36
            )
            self._lockdown_card.place(relx=0.5, rely=0.5, anchor="center", width=760, height=480)

            tk.Label(self._lockdown_card, text="🚨🚨🚨", bg="#0e0a12", font=("Segoe UI", 36)).pack(pady=(0, 6))
            tk.Label(self._lockdown_card, text=title, bg="#0e0a12", fg="#ff4d6d", font=("Segoe UI", 24, "bold")).pack(pady=(0, 4))
            tk.Label(self._lockdown_card, text=subtitle or "FULL LOCKDOWN DRILL ACTIVE", bg="#0e0a12", fg=TEXT, font=("Segoe UI", 12, "bold")).pack(pady=(0, 14))

            # Punishments Summary
            info_frame = tk.Frame(self._lockdown_card, bg="#1a0b12", highlightbackground="#ff1e42", highlightthickness=1, padx=16, pady=10)
            info_frame.pack(fill="x", pady=(0, 18))

            badge_text = opts.get("summary_badge") or "Distracting background app terminated · -25 pts score tax applied"
            tk.Label(info_frame, text=f"⚡ ENFORCEMENT ACTIVE: {badge_text}", bg="#1a0b12", fg="#ff8097", font=("Segoe UI", 10, "bold")).pack()
            tk.Label(info_frame, text="Proctor-9 vocal reprimand sounding · Relentless siren active", bg="#1a0b12", fg="#a0aec0", font=("Segoe UI", 9)).pack(pady=(2, 0))

            tk.Label(
                self._lockdown_card,
                text="You have deviated past the final compliance threshold. Silence this alarm and return to focused deep work immediately.",
                bg="#0e0a12", fg="#e2e8f0", font=("Segoe UI", 11), wraplength=660, justify="center"
            ).pack(pady=(0, 24))

            # Big Acknowledge Button
            tk.Button(
                self._lockdown_card, text="🛑  SILENCE ALARM & RESUME DEEP WORK",
                command=self._ack_clicked,
                bg="#dc2626", activebackground="#ef4444", activeforeground="#fff", fg="#fff",
                relief="flat", cursor="hand2", padx=28, pady=12, font=("Segoe UI", 12, "bold")
            ).pack()

            self._lockdown_win.geometry(f"{self.root.winfo_screenwidth()}x{self.root.winfo_screenheight()}+0+0")
            self._lockdown_win.deiconify()
            self._lockdown_win.lift()

            self._step_lockdown_flash()

        self.schedule(f)

    def _step_lockdown_flash(self):
        if not hasattr(self, "_lockdown_win") or not self._lockdown_win or not self._lockdown_win.winfo_exists():
            return
        # Alternate between blood red and pitch black-red
        bg_color = "#dc2626" if self._lockdown_flash_step else "#100306"
        self._lockdown_flash_step = not self._lockdown_flash_step
        try:
            self._lockdown_win.configure(bg=bg_color)
        except Exception:
            pass
        self._lockdown_timer_id = self.root.after(260, self._step_lockdown_flash)

    def stop_lockdown_flash(self):
        def f():
            if hasattr(self, "_lockdown_timer_id") and self._lockdown_timer_id:
                try:
                    self.root.after_cancel(self._lockdown_timer_id)
                except Exception:
                    pass
                self._lockdown_timer_id = None
            if hasattr(self, "_lockdown_win") and self._lockdown_win:
                try:
                    self._lockdown_win.destroy()
                except Exception:
                    pass
                self._lockdown_win = None

        self.schedule(f)

    def _test_red_alarm(self):
        self.start_lockdown_flash(
            title="TEST CRITICAL RED LOCKDOWN",
            subtitle="Simulated Tier 4 Alarm Drill and Red Screen Strobe",
            challenge_opts={"summary_badge": "Test Alarm Triggered · Strobe Flashing Screen Active"}
        )

    def alarm_flash(self, on):
        self._flash = on
        if on:
            self.start_lockdown_flash()
        else:
            self.stop_lockdown_flash()

    # ---------- COUNTDOWN MODAL (TIER 3) ----------
    def start_countdown(self, head, sub, allow_ack=True, promise_text="I promise to return to my work.", challenge_opts=None):
        def f():
            opts = challenge_opts or {}
            self._cd_typing_verified = False
            self._cd_math_verified = False
            self._cd_lock_remaining = int(opts.get("lock_seconds", 0))
            if hasattr(self, "_lock_timer_id") and self._lock_timer_id:
                try:
                    self.root.after_cancel(self._lock_timer_id)
                except Exception:
                    pass
                self._lock_timer_id = None

            has_typing = bool(opts.get("typing_challenge") and opts.get("typing_pledge"))
            has_math = bool(opts.get("math_challenge") and opts.get("math_data"))
            has_lock = self._cd_lock_remaining > 0
            has_physical = bool(opts.get("physical_action") and opts.get("physical_action_text"))
            has_badge = bool(opts.get("summary_badge"))

            if not hasattr(self, "cd"):
                self.cd = tk.Toplevel(self.root)
                self.cd.overrideredirect(True)
                self.cd.attributes("-topmost", True)
                self.cd.configure(bg="#080d18")

            # Clear previous children from cd window
            for child in self.cd.winfo_children():
                try:
                    child.destroy()
                except Exception:
                    pass

            panel_w = 720 if (has_typing or has_math or has_physical) else 650
            panel_h = 600 if (has_typing and has_math) else (540 if (has_typing or has_math or has_physical) else 440)
            panel = tk.Frame(self.cd, bg="#111c30", highlightbackground="#ff5d73", highlightthickness=2, padx=36, pady=24)
            panel.place(relx=.5, rely=.5, anchor="center", width=panel_w, height=panel_h)

            self.cd_head = tk.Label(panel, text=head, bg="#111c30", fg="#ff7689", font=("Segoe UI", 13, "bold"))
            self.cd_head.pack(pady=(0, 4))

            self.cd_n = tk.Label(panel, text="5", bg="#111c30", fg=TEXT, font=("Segoe UI", 44, "bold"))
            self.cd_n.pack(pady=(0, 2))

            self.cd_m = tk.Label(panel, text=sub, bg="#111c30", fg=MUTED, font=("Segoe UI", 11), wraplength=panel_w - 80, justify="center")
            self.cd_m.pack(pady=(0, 6))

            # Summary badge (App killed / score tax)
            if has_badge:
                b_frame = tk.Frame(panel, bg="#2a121d", highlightbackground="#ef4444", highlightthickness=1, padx=10, pady=4)
                b_frame.pack(fill="x", pady=(0, 6))
                tk.Label(b_frame, text=f"⚡ ENFORCEMENT: {opts.get('summary_badge')}", bg="#2a121d", fg="#fca5a5", font=("Segoe UI", 9, "bold")).pack()

            # Physical action banner
            if has_physical:
                p_frame = tk.Frame(panel, bg="#1f2937", highlightbackground="#eab308", highlightthickness=1, padx=10, pady=5)
                phys_txt = "🧘 PHYSICAL RESET MANDATE:\n" + str(opts.get("physical_action_text", ""))
                tk.Label(p_frame, text=phys_txt, bg="#1f2937", fg="#fde047", font=("Segoe UI", 9, "bold"), justify="center").pack()

            # Mental Math Challenge
            if has_math:
                m_data = opts["math_data"]
                m_expected = str(m_data["answer"]).strip()
                m_frame = tk.Frame(panel, bg="#0d182b", highlightbackground="#3b82f6", highlightthickness=1, padx=12, pady=6)
                m_frame.pack(fill="x", pady=(0, 6))

                m_row = tk.Frame(m_frame, bg="#0d182b")
                m_row.pack(fill="x")
                tk.Label(m_row, text=f"🧠 MENTAL REBOOT: Solve {m_data['question']} = ", bg="#0d182b", fg="#93c5fd", font=("Segoe UI", 10, "bold")).pack(side="left")

                m_val = tk.StringVar()
                m_entry = tk.Entry(m_row, textvariable=m_val, width=8, bg="#091322", fg="#fff", insertbackground="#fff", relief="flat", highlightbackground="#2563eb", highlightthickness=1, font=("Segoe UI", 11, "bold"))
                m_entry.pack(side="left", padx=(6, 10), ipady=2)

                m_status = tk.Label(m_row, text="Required to unlock", bg="#0d182b", fg="#64748b", font=("Segoe UI", 9))
                m_status.pack(side="left")

                def _check_math(*_):
                    val = m_val.get().strip()
                    if val == m_expected:
                        self._cd_math_verified = True
                        m_status.config(text="✓ Solved!", fg="#34d399")
                        m_entry.config(highlightbackground="#10b981")
                    else:
                        self._cd_math_verified = False
                        m_status.config(text="Incorrect" if val else "Required to unlock", fg="#f87171" if val else "#64748b")
                        m_entry.config(highlightbackground="#ef4444" if val else "#2563eb")
                    self._update_cd_ack_state()

                m_val.trace_add("write", _check_math)

            # Typing Commitment Pledge
            if has_typing:
                pledge = str(opts["typing_pledge"]).strip()
                t_frame = tk.Frame(panel, bg="#0d182b", highlightbackground="#8b5cf6", highlightthickness=1, padx=12, pady=6)
                t_frame.pack(fill="x", pady=(0, 6))

                tk.Label(t_frame, text="✍️ FOCUS COMMITMENT (Type verbatim to unlock — paste disabled):", bg="#0d182b", fg="#c4b5fd", font=("Segoe UI", 9, "bold")).pack(anchor="w")
                tk.Label(t_frame, text=f'"{pledge}"', bg="#0d182b", fg="#e2e8f0", font=("Segoe UI", 9, "italic"), wraplength=panel_w - 110, justify="left").pack(anchor="w", pady=(1, 3))

                t_val = tk.StringVar()
                t_entry = tk.Entry(t_frame, textvariable=t_val, bg="#091322", fg="#fff", insertbackground="#fff", relief="flat", highlightbackground="#7c3aed", highlightthickness=1, font=("Segoe UI", 10))
                t_entry.pack(fill="x", ipady=2)

                # Anti-paste enforcement
                t_entry.bind("<Control-v>", lambda e: "break")
                t_entry.bind("<Control-V>", lambda e: "break")
                t_entry.bind("<<Paste>>", lambda e: "break")

                t_status = tk.Label(t_frame, text=f"0 / {len(pledge)} characters", bg="#0d182b", fg="#64748b", font=("Segoe UI", 9))
                t_status.pack(anchor="w", pady=(1, 0))

                def _check_typing(*_):
                    val = t_val.get()
                    if val == pledge:
                        self._cd_typing_verified = True
                        t_status.config(text="✓ Pledge verified verbatim!", fg="#34d399")
                        t_entry.config(highlightbackground="#10b981")
                    elif pledge.startswith(val):
                        self._cd_typing_verified = False
                        t_status.config(text=f"Matching: {len(val)} / {len(pledge)} characters", fg="#93c5fd")
                        t_entry.config(highlightbackground="#7c3aed")
                    else:
                        self._cd_typing_verified = False
                        t_status.config(text="Typo detected! Check spelling & casing.", fg="#f87171")
                        t_entry.config(highlightbackground="#ef4444")
                    self._update_cd_ack_state()

                t_val.trace_add("write", _check_typing)

            # Promise Checkbox
            self.cd_ack_var = tk.IntVar(value=0)
            self.cd_ack = tk.Checkbutton(
                panel,
                text="  " + promise_text + "  ",
                variable=self.cd_ack_var,
                command=self._update_cd_ack_state,
                bg="#111c30", fg=TEXT, selectcolor="#263c61", activebackground="#111c30",
                activeforeground=TEXT, font=("Segoe UI", 10, "bold"), wraplength=panel_w - 100, justify="left",
            )
            if allow_ack:
                self.cd_ack.pack(pady=(3, 4), anchor="w")

            # Main Dismiss Button
            self.cd_ack_btn = tk.Button(
                panel,
                text="✓ I AM BACK IN FOCUS — DISMISS",
                command=self._ack_clicked,
                bg="#1e293b", fg="#64748b",
                activebackground="#10b981", activeforeground="#fff",
                relief="flat", cursor="arrow", font=("Segoe UI", 10, "bold"),
                padx=16, pady=8, state="disabled"
            )
            if allow_ack:
                self.cd_ack_btn.pack(fill="x", pady=(3, 0))

            # Store challenge tracking flags on self
            self._has_typing_req = has_typing
            self._has_math_req = has_math
            self._allow_ack = allow_ack

            # Lockout timer tick
            def _lock_tick():
                if self._cd_lock_remaining > 0:
                    self._cd_lock_remaining -= 1
                    self._update_cd_ack_state()
                    self._lock_timer_id = self.root.after(1000, _lock_tick)
                else:
                    self._lock_timer_id = None
                    self._update_cd_ack_state()

            if has_lock:
                self._lock_timer_id = self.root.after(1000, _lock_tick)

            self._update_cd_ack_state()

            self.cd.geometry(f"{self.root.winfo_screenwidth()}x{self.root.winfo_screenheight()}+0+0")
            self.cd.deiconify()
            self.cd.lift()

        self.schedule(f)

    def _update_cd_ack_state(self):
        if not hasattr(self, "cd_ack_btn") or not hasattr(self, "cd"):
            return
        locked = getattr(self, "_cd_lock_remaining", 0) > 0
        typing_pending = getattr(self, "_has_typing_req", False) and not getattr(self, "_cd_typing_verified", False)
        math_pending = getattr(self, "_has_math_req", False) and not getattr(self, "_cd_math_verified", False)
        check_pending = bool(getattr(self, "_allow_ack", True) and not getattr(self, "_has_typing_req", False) and not getattr(self, "_has_math_req", False) and self.cd_ack_var.get() == 0)

        if locked:
            rem = self._cd_lock_remaining
            self.cd_ack_btn.config(text=f"🔒 Cooldown Lock Active ({rem}s remaining)", state="disabled", bg="#1e293b", fg="#64748b", cursor="arrow")
        elif typing_pending:
            self.cd_ack_btn.config(text="✍️ Complete Focus Pledge Above To Unlock", state="disabled", bg="#1e293b", fg="#818cf8", cursor="arrow")
        elif math_pending:
            self.cd_ack_btn.config(text="🧠 Solve Mental Math Problem Above To Unlock", state="disabled", bg="#1e293b", fg="#60a5fa", cursor="arrow")
        elif check_pending:
            self.cd_ack_btn.config(text="Check Focus Promise Box Above To Unlock", state="disabled", bg="#1e293b", fg="#94a3b8", cursor="arrow")
        else:
            self.cd_ack_btn.config(text="✓ I AM BACK IN FOCUS — DISMISS", state="normal", bg="#10b981", fg="#ffffff", cursor="hand2")

    def _ack_clicked(self):
        self.stop_countdown()
        self.stop_lockdown_flash()
        self.stop_fullscreen_warning()
        if self.on_ack:
            try:
                self.on_ack()
            except Exception:
                pass

    def update_countdown(self, n, total):
        def f():
            if hasattr(self, "cd_n"):
                self.cd_n.config(text=str(n))

        self.schedule(f)

    def stop_countdown(self):
        def f():
            if hasattr(self, "_lock_timer_id") and self._lock_timer_id:
                try:
                    self.root.after_cancel(self._lock_timer_id)
                except Exception:
                    pass
                self._lock_timer_id = None
            if hasattr(self, "cd"):
                self.cd.withdraw()

        self.schedule(f)

    # ---------- lifecycle ----------
    def close_app(self):
        self.root.after(0, self.root.destroy)

    def run(self):
        self.root.mainloop()
