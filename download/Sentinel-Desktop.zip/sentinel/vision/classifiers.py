"""Swappable activity classifiers for the Desktop Sentinel."""
import re, json, urllib.request

STUDY, NEUTRAL, DISTRACTION = "STUDY", "NEUTRAL", "DISTRACTION"

class RuleBasedClassifier:
    """Whitelist/blacklist first, then regex patterns over title+process,
    optionally re-checked with OCR text. Zero network use."""
    def __init__(self, cfg, learned=()):
        def rx(key): return [re.compile(p, re.I) for p in (cfg.get(f"desktop.{key}") or [])]
        self.wl, self.bl = rx("whitelist"), rx("blacklist")
        self.study, self.distract, self.neutral = rx("study_patterns"), rx("distraction_patterns"), rx("neutral_patterns")
        self.domain_wl = [re.compile(p, re.I) for p in (cfg.get("browser.website_whitelist") or [])]
        self.domain_bl = [re.compile(p, re.I) for p in (cfg.get("browser.website_blacklist") or [])]
        self.set_learned(learned)

    def set_learned(self, learned):
        self.learned = []
        for item in learned:
            if not item: continue
            if isinstance(item, (list, tuple)) and len(item) >= 2:
                sig, lbl = item[0], item[1]
                if sig:
                    self.learned.append((str(sig).lower(), str(lbl).upper()))

    def _scan(self, patterns, blob):
        return next((p.pattern for p in patterns if p.search(blob)), None)

    def classify(self, title="", process="", ocr_text="", png=None, browser_domain=""):
        blob = f"{title} {process}".lower()
        domain = (browser_domain or "").lower()
        ev = self._scan(self.domain_bl, domain)
        if ev: return DISTRACTION, f"website_blacklist:{ev}"
        ev = self._scan(self.domain_wl, domain)
        if ev: return STUDY, f"website_whitelist:{ev}"
        ev = self._scan(self.bl, blob)
        if ev: return DISTRACTION, f"blacklist:{ev}"
        ev = self._scan(self.wl, blob)
        if ev: return STUDY, f"whitelist:{ev}"
        for signature, label in self.learned:
            if signature in blob:
                return label, f"trained:{signature[:60]}"
        ev = self._scan(self.distract, blob)
        if ev: return DISTRACTION, f"pattern:{ev}"
        ev = self._scan(self.study, blob)
        if ev: return STUDY, f"pattern:{ev}"
        if ocr_text and not (title.strip() or process.strip()):
            # OCR assist ONLY when the window is unnamed (fullscreen apps).
            # Reading the whole screen otherwise matches distraction words in
            # page text/bookmarks and mislabels legitimate study pages.
            low = ocr_text.lower()[:4000]
            ev = self._scan(self.distract, low)
            if ev: return DISTRACTION, f"ocr:{ev}"
            ev = self._scan(self.study, low)
            if ev: return STUDY, f"ocr:{ev}"
        ev = self._scan(self.neutral, blob)
        if ev: return NEUTRAL, f"pattern:{ev}"
        return NEUTRAL, "no match (default neutral)"

class LocalVisionClassifier:
    """OPTIONAL: classify the screenshot with a multimodal model served on
    LOCALHOST (e.g. Ollama + llava). Privacy gate: config validation rejects
    non-localhost endpoints. Falls back to rules on any error."""
    def __init__(self, cfg, fallback):
        self.endpoint = cfg.get("desktop.vision_endpoint", "").rstrip("/")
        self.model = cfg.get("desktop.vision_model", "llava")
        self.fallback = fallback

    def classify(self, title="", process="", ocr_text="", png=None, browser_domain=""):
        import base64
        try:
            b64 = base64.b64encode(png).decode() if png else ""
            body = json.dumps({"model": self.model, "stream": False,
                "prompt": ("A student is being monitored. Classify this screenshot as exactly one "
                           "word: STUDY, NEUTRAL, or DISTRACTION. Window title hint: '" + title[:80] + "'"),
                "images": [b64]}).encode()
            req = urllib.request.Request(self.endpoint + "/api/generate", data=body,
                                         headers={"Content-Type": "application/json"})
            with urllib.request.urlopen(req, timeout=20) as r:
                ans = json.loads(r.read()).get("response", "").upper()
            # A model sometimes says e.g. "not STUDY; DISTRACTION".  Picking
            # the first label mentioned would classify that as STUDY, so only
            # trust an unambiguous response and otherwise use the rules.
            labels = set(re.findall(r"\b(?:STUDY|NEUTRAL|DISTRACTION)\b", ans))
            if len(labels) == 1:
                return labels.pop(), f"vision:{self.model}"
        except Exception as e:
            return self.fallback.classify(title, process, ocr_text, png, browser_domain=browser_domain) if self.fallback \
                else (NEUTRAL, f"vision_error:{type(e).__name__}")
        return self.fallback.classify(title, process, ocr_text, png, browser_domain=browser_domain)
