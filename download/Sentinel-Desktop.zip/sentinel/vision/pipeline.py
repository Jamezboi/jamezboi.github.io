import time, math, statistics, cv2, numpy as np
from .mp_compat import FaceMeshWrapper, HandsWrapper, VisionUnavailable, probe_mediapipe

# Canonical 3D face model (nose, chin, eye outer corners, mouth corners)
_MODEL = np.array([(0.0, 0.0, 0.0), (0.0, -330.0, -65.0), (-225.0, 170.0, -135.0),
                   (225.0, 170.0, -135.0), (-150.0, -150.0, -125.0), (150.0, -150.0, -125.0)], dtype=np.float64)
_LM = dict(nose=1, chin=152, eye_r=263, eye_l=33, mouth_r=287, mouth_l=57)
_EAR_R = [33, 160, 158, 133, 153, 144]
_EAR_L = [362, 385, 387, 263, 373, 380]

def _ear(lm, idx, w, h):
    def p(i): return np.array([lm[i].x * w, lm[i].y * h])
    a, b = p(idx[1]), p(idx[5]); c, d = p(idx[2]), p(idx[4]); e, f = p(idx[0]), p(idx[3])
    vert = np.linalg.norm(a - b) + np.linalg.norm(c - d)
    horiz = 2.0 * max(np.linalg.norm(e - f), 1e-6)
    return vert / horiz

def _head_pose(lm, w, h):
    pts = np.array([(lm[_LM[k]].x * w, lm[_LM[k]].y * h) for k in
                    ("nose", "chin", "eye_r", "eye_l", "mouth_r", "mouth_l")], dtype=np.float64)
    focal = w
    K = np.array([[focal, 0, w / 2], [0, focal, h / 2], [0, 0, 1]], dtype=np.float64)
    ok, rvec, _ = cv2.solvePnP(_MODEL, pts, K, None, flags=cv2.SOLVEPNP_ITERATIVE)
    if not ok: return None
    R = cv2.Rodrigues(rvec)[0]
    pitch = math.degrees(math.atan2(R[2, 1], R[2, 2]))
    yaw = math.degrees(math.atan2(-R[2, 0], math.sqrt(R[0, 0] ** 2 + R[1, 0] ** 2)))
    return pitch, yaw

class VisionPipeline:
    """Haar (face count / user lock) → FaceMesh on (possibly cropped) ROI → Hands.
    API-agnostic via mp_compat (legacy solutions OR modern Tasks). Emits 'obs'
    dicts; runs the calibration state machine. If no face API is available it
    emits nothing — Presence freezes safely (never a false 'left desk') — and
    Desktop Sentinel, YOLO phone detection and the tamper plugin keep running."""
    def __init__(self, cfg, bus, camera):
        self.cfg, self.bus, self.camera = cfg, bus, camera
        self.baseline = None
        self._cal_phase = None; self._samples = {"screen": [], "paper": []}
        self._haar = cv2.CascadeClassifier(cv2.data.haarcascades + "haarcascade_frontalface_default.xml")
        self._fm = None; self._hands = None
        mode, detail = probe_mediapipe()
        if mode == "none":
            print(f"[vision] UNAVAILABLE — {detail}")
            self.bus.publish("warning.vision_unavailable", {"detail": detail})
        else:
            try:
                self._fm = FaceMeshWrapper()
            except VisionUnavailable as e:
                print(f"[vision] face mesh unavailable — {e}")
                self.bus.publish("warning.vision_unavailable", {"detail": f"face: {e}"})
            try:
                self._hands = HandsWrapper()
            except VisionUnavailable as e:
                print(f"[vision] hand tracking unavailable — {e}")
                self.bus.publish("warning.vision_unavailable", {"detail": f"hands: {e}"})
            if self._fm is not None:
                print(f"[vision] active — {detail}")
        self._lock_center = None; self._frame_no = 0
        self._low_light_since = None; self._low_light_warned = 0; self._mf_warned = 0
        bus.subscribe("calibration.phase", self._on_cal_phase)
        camera.add_subscriber(self.on_frame)

    def close(self):
        for w in (self._fm, self._hands):
            if w is not None:
                w.close()

    def _on_cal_phase(self, d):
        phase = d.get("phase")
        if phase in ("screen", "paper"):
            self._cal_phase = phase; self._samples[phase] = []
        elif phase == "end":
            self._cal_phase = None; self._finish_calibration()

    def _finish_calibration(self):
        try:
            def med(key, i):
                vals = [s[i] for s in self._samples[key] if s[i] is not None]
                return statistics.median(vals) if vals else None
            base = {}
            for ph in ("screen", "paper"):
                base[ph] = {"pitch": med(ph, 0), "yaw": med(ph, 1), "gaze_v": med(ph, 2),
                            "face_cy": med(ph, 3), "face_h": med(ph, 4)}
            sp, pp = base["screen"]["pitch"], base["paper"]["pitch"]
            min_samples = int(self.cfg.get("gaze.calibration_min_samples", 12))
            counts = {ph: len([s for s in self._samples[ph] if s[0] is not None]) for ph in ("screen", "paper")}
            if min(counts.values()) < min_samples:
                self.bus.publish("warning.calibration", {"detail": "calibration incomplete; keep your face visible and try again", "samples": counts})
                return
            if sp is None or pp is None or abs(pp - sp) < 3:
                self.bus.publish("warning.calibration", {"detail": "paper/screen pitch too similar; recalibrate with a clearer head movement"})
                return
            base["paper_axis"] = 1.0 if (pp or 0) >= (sp or 0) else -1.0
            self.baseline = base
            self.bus.publish("calibration.done", base)
        except Exception as e:
            self.bus.publish("warning.calibration", {"error": str(e)})

    def on_frame(self, frame, t, luma):
        if self._fm is None:
            return                      # no face API → emit nothing (Presence freezes safely)
        self._frame_no += 1
        h, w = frame.shape[:2]
        low_light = luma < self.cfg.get("camera.low_light_threshold", 45)
        now = time.time()
        if low_light:
            if self._low_light_since is None: self._low_light_since = now
            elif now - self._low_light_since > 5 and now - self._low_light_warned > 300:
                self._low_light_warned = now
                self.bus.publish("warning.low_light", {"luma": round(luma, 1)})
        else:
            self._low_light_since = None

        # --- Haar every 2nd frame: face count + user lock ROI ---
        roi = (0, 0, w, h); face_count = 1
        if self._frame_no % 2 == 0 or self._lock_center is None:
            gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
            boxes = self._haar.detectMultiScale(gray, 1.1, 5, minSize=(w // 8, w // 8))
            face_count = len(boxes)
            if face_count:
                if self._lock_center is None or face_count == 1:
                    x, y, bw, bh = max(boxes, key=lambda b: b[2] * b[3])
                    self._lock_center = (x + bw / 2, y + bh / 2)
                else:  # multiple faces: lock to the box nearest the calibrated user
                    x, y, bw, bh = min(boxes, key=lambda b: (b[0] + b[2] / 2 - self._lock_center[0]) ** 2
                                                       + (b[1] + b[3] / 2 - self._lock_center[1]) ** 2)
                m = 0.6
                x0, y0 = max(0, int(x - bw * m)), max(0, int(y - bh * m))
                x1, y1 = min(w, int(x + bw * (1 + m))), min(h, int(y + bh * (1 + m)))
                roi = (x0, y0, x1, y1)
            if face_count > 1 and now - self._mf_warned > 10:
                self._mf_warned = now
                self.bus.publish("warning.multi_face", {"count": face_count})

        obs = {"t": t, "face": False, "faces": face_count, "low_light": low_light,
               "pitch": None, "yaw": None, "gaze_v": None, "ear": None, "mar": None,
               "hand_near_face": False, "hands": 0, "bbox": None, "luma": round(luma, 1)}

        crop = frame[roi[1]:roi[3], roi[0]:roi[2]]
        if crop.size == 0: crop = frame; roi = (0, 0, w, h)
        ch, cw = crop.shape[:2]
        rgb = cv2.cvtColor(crop, cv2.COLOR_BGR2RGB)
        res = self._fm.process(rgb)
        if not res.multi_face_landmarks and roi != (0, 0, w, h):
            # FaceMesh lost the face inside the Haar ROI (typical when the
            # head is pitched down at paper): retry ONCE on the full frame
            # before reporting no-face — prevents false "left frame".
            rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
            res = self._fm.process(rgb)
            roi, crop = (0, 0, w, h), frame
            ch, cw = h, w
        if res.multi_face_landmarks:
            lm = res.multi_face_landmarks[0].landmark
            pose = _head_pose(lm, cw, ch)
            if pose: obs["pitch"], obs["yaw"] = pose
            if len(lm) >= 478:
                def gv(iris, top, bot):
                    return (lm[iris].y - (lm[top].y + lm[bot].y) / 2) / max(lm[bot].y - lm[top].y, 1e-6)
                obs["gaze_v"] = round((gv(468, 159, 145) + gv(473, 386, 374)) / 2, 3)
            obs["ear"] = round((_ear(lm, _EAR_R, cw, ch) + _ear(lm, _EAR_L, cw, ch)) / 2, 3)
            try:  # mouth aspect ratio (yawn)
                mw = np.linalg.norm(np.array([lm[61].x - lm[291].x, lm[61].y - lm[291].y]) * [cw, ch])
                mh = np.linalg.norm(np.array([lm[13].x - lm[14].x, lm[13].y - lm[14].y]) * [cw, ch])
                obs["mar"] = round(mh / max(mw, 1e-6), 3)
            except Exception: pass
            xs = [p.x for p in lm]; ys = [p.y for p in lm]
            bx = (min(xs) * cw + roi[0]) / w; by = (min(ys) * ch + roi[1]) / h
            bw_ = (max(xs) - min(xs)) * cw / w; bh_ = (max(ys) - min(ys)) * ch / h
            obs["bbox"] = [round(bx, 3), round(by, 3), round(bw_, 3), round(bh_, 3)]
            obs["face"] = True
            if self._cal_phase and obs["pitch"] is not None:
                self._samples[self._cal_phase].append(
                    (obs["pitch"], obs["yaw"], obs["gaze_v"],
                     (by + bh_ / 2) if obs["bbox"] else None, bh_))

        # --- Hands every 2nd frame: hand-near-face heuristic for Phone Sentinel ---
        if self._hands is not None and self._frame_no % 2 == 0:
            hres = self._hands.process(rgb)
            if hres.multi_hand_landmarks:
                obs["hands"] = len(hres.multi_hand_landmarks)
                if obs["bbox"]:
                    bx, by, bw_, bh_ = obs["bbox"]
                    ex = [bx - 0.2 * bw_, bx + 1.2 * bw_, by - 0.2 * bh_, by + 1.4 * bh_]
                    for hd in hres.multi_hand_landmarks:
                        for i in (0, 4, 8, 12, 16, 20):
                            p = hd.landmark[i]
                            fx, fy = (p.x * cw + roi[0]) / w, (p.y * ch + roi[1]) / h
                            if ex[0] <= fx <= ex[1] and ex[2] <= fy <= ex[3]:
                                obs["hand_near_face"] = True; break
                        if obs["hand_near_face"]: break
        self.bus.publish("obs", obs)
