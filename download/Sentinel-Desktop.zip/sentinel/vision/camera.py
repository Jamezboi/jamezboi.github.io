import threading, time, cv2, traceback

class CameraBus:
    """Single owner of the webcam. One capture thread feeds all subscribers
    (pipeline, phone YOLO, tamper plugin). Survives busy camera / unplug / sleep."""
    def __init__(self, cfg, bus):
        self.cfg, self.bus = cfg, bus
        self.subscribers = []
        self.lock = threading.Lock()
        self.frame = None
        self.status = "starting"      # starting|ok|failed|stopped
        self._stop = threading.Event()
        self._failed_published = False
        idx = cfg.get("camera.index", 0)
        api = (cv2.CAP_DSHOW if CameraBus._win() else
               cv2.CAP_AVFOUNDATION if CameraBus._mac() else cv2.CAP_V4L2)
        self._open_args = (idx, api)
        self.thread = threading.Thread(target=self._run, daemon=True, name="camera")

    @staticmethod
    def _win(): import sys; return sys.platform == "win32"
    @staticmethod
    def _mac(): import sys; return sys.platform == "darwin"

    def add_subscriber(self, fn):
        with self.lock: self.subscribers.append(fn)

    def _open(self):
        w, h = self.cfg.get("camera.width", 640), self.cfg.get("camera.height", 480)
        cap = cv2.VideoCapture(*self._open_args)
        cap.set(cv2.CAP_PROP_FRAME_WIDTH, w); cap.set(cv2.CAP_PROP_FRAME_HEIGHT, h)
        return cap if cap.isOpened() else None

    def _desk_crop(self, frame):
        """Discard the upper camera region before any subscriber sees it.

        Desk mode must be aimed at the desk; this extra guard ensures phone
        detection, UI, plugins, and evidence cannot receive a face in the
        usual upper part of the frame.
        """
        if self.cfg.get("camera.mode", "desk") != "desk":
            return frame
        h, w = frame.shape[:2]
        x0, y0, x1, y1 = self.cfg.get("camera.desk_crop", [0, .35, 1, 1])
        cropped = frame[max(0, int(h * y0)):min(h, int(h * y1)),
                        max(0, int(w * x0)):min(w, int(w * x1))]
        return cropped if cropped.size else frame

    def _run(self):
        cap, failures, backoff = None, 0, 1.0
        retry = self.cfg.get("camera.retry_seconds", 10)
        while not self._stop.is_set():
            if cap is None:
                cap = self._open()
                if cap is None:
                    self.status = "failed"
                    if not self._failed_published:
                        self.bus.publish("camera.failed", {"index": self._open_args[0]})
                        self._failed_published = True
                    time.sleep(min(backoff, retry)); backoff = min(backoff * 1.5, retry)
                    continue
                backoff, failures = 1.0, 0
                if self._failed_published:
                    self._failed_published = False
                    self.bus.publish("camera.recovered", {})
                self.status = "ok"
            ok, frame = cap.read()
            if not ok or frame is None:
                failures += 1
                if failures > 12:      # genuinely stalled (unplug/sleep) → reopen
                    try: cap.release()
                    except Exception: pass
                    cap = None
                time.sleep(0.25); continue
            failures = 0
            frame = self._desk_crop(frame)
            self.frame = frame
            t = time.time()
            luma = float(frame.mean())
            with self.lock: subs = list(self.subscribers)
            for fn in subs:
                try: fn(frame, t, luma)
                except Exception:
                    pass  # subscribers own their error handling; never kill the camera
            time.sleep(max(0.0, 1.0 / 30.0 - (time.time() - t)))
        try:
            if cap: cap.release()
        except Exception: pass
        self.status = "stopped"

    def start(self): self.thread.start()
    def stop(self): self._stop.set()
