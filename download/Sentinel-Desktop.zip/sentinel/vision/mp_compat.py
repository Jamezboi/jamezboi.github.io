"""MediaPipe compatibility layer for Sentinel.

MediaPipe ships two Python APIs:
  - LEGACY  `mp.solutions.*` (FaceMesh, Hands) — mediapipe builds for
    Python <= 3.12 era.
  - TASKS   `mediapipe.tasks.*` (FaceLandmarker, HandLandmarker) — the modern
    API. Builds new enough to have Python 3.13/3.14 wheels REMOVED
    `mp.solutions` entirely, so `mp.solutions.face_mesh` raises
    AttributeError on them.

This module exposes wrappers with the legacy `.process(rgb)` result shape over
whichever API the installed mediapipe provides, so the rest of Sentinel is
API-agnostic. Landmark indices are identical in both APIs (canonical 478-point
face mesh incl. iris; 21-point hand), so all downstream indices are untouched.

Direct smoke test:  python -m sentinel.vision.mp_compat
"""
import ctypes
import os
import sys
import time
import types
import urllib.request

# --- Python 3.14 + MediaPipe Windows Workaround ---
# Python 3.14 changed ctypes DLL symbol resolution on Windows.
# MediaPipe expects 'free' on its C++ library, which fails under 3.14.
if sys.platform == "win32":
    _orig_cdll_getitem = ctypes.CDLL.__getitem__

    def _patched_cdll_getitem(self, name_or_ordinal):
        try:
            return _orig_cdll_getitem(self, name_or_ordinal)
        except AttributeError:
            if name_or_ordinal == "free":
                return ctypes.cdll.msvcrt.free
            raise

    ctypes.CDLL.__getitem__ = _patched_cdll_getitem
# ---------------------------------------------------


class VisionUnavailable(Exception):
    """No usable face/hand API or model available (details in the message)."""


_MODELS = {
    "face_landmarker.task": (
        "https://storage.googleapis.com/mediapipe-models/face_landmarker/"
        "face_landmarker/float16/1/face_landmarker.task", 3_000_000),
    "hand_landmarker.task": (
        "https://storage.googleapis.com/mediapipe-models/hand_landmarker/"
        "hand_landmarker/float16/1/hand_landmarker.task", 6_000_000),
}


def probe_mediapipe():
    """Return (mode, human_detail). mode: 'legacy' | 'tasks' | 'none'."""
    try:
        import mediapipe as mp
    except Exception as e:
        return "none", f"import failed: {e}"
    ver = getattr(mp, "__version__", "unknown version")
    if hasattr(mp, "solutions"):
        return "legacy", f"mediapipe {ver} — legacy solutions API"
    if hasattr(mp, "tasks"):
        return "tasks", f"mediapipe {ver} — modern Tasks API (mp.solutions removed in this build)"
    return "none", f"mediapipe {ver} exposes neither mp.solutions nor mediapipe.tasks (broken install?)"


def ensure_model(filename, directory="models"):
    """Return a local path to the .task model, downloading it once if needed.
    Model WEIGHTS only — no user data ever leaves the machine."""
    url, min_bytes = _MODELS[filename]
    path = os.path.join(directory, filename)
    if os.path.isfile(path) and os.path.getsize(path) >= min_bytes:
        return path
    os.makedirs(directory, exist_ok=True)
    tmp = path + ".part"
    print(f"[vision] one-time model download: {filename} (~{min_bytes // 1000} KB)")
    try:
        with urllib.request.urlopen(url, timeout=60) as r, open(tmp, "wb") as f:
            total = int(r.headers.get("Content-Length") or 0)
            done = 0
            while True:
                chunk = r.read(1 << 16)
                if not chunk:
                    break
                f.write(chunk)
                done += len(chunk)
                if total:
                    sys.stdout.write(f"\r  {done // 1024} / {total // 1024} KB")
                    sys.stdout.flush()
        print()
        if done < min_bytes:
            raise IOError(f"file suspiciously small ({done} bytes)")
        os.replace(tmp, path)
        return path
    except Exception as e:
        try:
            os.remove(tmp)
        except OSError:
            pass
        raise VisionUnavailable(
            f"could not fetch {filename} ({e}).\n"
            f"  Download it manually:\n    {url}\n"
            f"  Save as: {os.path.abspath(path)}\n  Then restart Sentinel.")


def model_status(directory="models"):
    return {name: (os.path.isfile(os.path.join(directory, name))
                   and os.path.getsize(os.path.join(directory, name)) >= minb)
            for name, (_u, minb) in _MODELS.items()}


class _Ts:
    """Strictly increasing millisecond timestamps (required by Tasks VIDEO mode)."""
    def __init__(self):
        self._last = 0

    def next(self):
        t = int(time.monotonic() * 1000)
        if t <= self._last:
            t = self._last + 1
        self._last = t
        return t


class _Landmarks:
    """Legacy shape: a collection exposing .landmark (list of NormalizedLandmark)."""
    __slots__ = ("landmark",)

    def __init__(self, lm):
        self.landmark = lm


class FaceMeshWrapper:
    """`.process(rgb_ndarray)` -> object with `.multi_face_landmarks`
    (list of collections with `.landmark`), matching the legacy FaceMesh shape."""
    def __init__(self, max_faces=1):
        import mediapipe as mp
        if hasattr(mp, "solutions"):
            self._mode = "legacy"
            self._impl = mp.solutions.face_mesh.FaceMesh(
                max_num_faces=max_faces, refine_landmarks=True,
                min_detection_confidence=0.5, min_tracking_confidence=0.5)
            return
        if not hasattr(mp, "tasks"):
            raise VisionUnavailable(probe_mediapipe()[1])
        from mediapipe.tasks import python as mp_tasks
        from mediapipe.tasks.python import vision as mp_vision
        opts = mp_vision.FaceLandmarkerOptions(
            base_options=mp_tasks.BaseOptions(model_asset_path=ensure_model("face_landmarker.task")),
            running_mode=mp_vision.RunningMode.VIDEO,
            num_faces=max_faces)
        self._impl = mp_vision.FaceLandmarker.create_from_options(opts)
        self._ts = _Ts()
        self._mp = mp
        self._mode = "tasks"

    def process(self, rgb):
        if self._mode == "legacy":
            return self._impl.process(rgb)
        image = self._mp.Image(image_format=self._mp.ImageFormat.SRGB, data=rgb)
        result = self._impl.detect_for_video(image, self._ts.next())
        faces = getattr(result, "face_landmarks", None) or []
        return types.SimpleNamespace(multi_face_landmarks=[_Landmarks(f) for f in faces])

    def close(self):
        try:
            self._impl.close()
        except Exception:
            pass


class HandsWrapper:
    """`.process(rgb_ndarray)` -> object with `.multi_hand_landmarks`,
    matching the legacy Hands shape."""
    def __init__(self, max_hands=2):
        import mediapipe as mp
        if hasattr(mp, "solutions"):
            self._mode = "legacy"
            self._impl = mp.solutions.hands.Hands(
                max_num_hands=max_hands, min_detection_confidence=0.5)
            return
        if not hasattr(mp, "tasks"):
            raise VisionUnavailable(probe_mediapipe()[1])
        from mediapipe.tasks import python as mp_tasks
        from mediapipe.tasks.python import vision as mp_vision
        opts = mp_vision.HandLandmarkerOptions(
            base_options=mp_tasks.BaseOptions(model_asset_path=ensure_model("hand_landmarker.task")),
            running_mode=mp_vision.RunningMode.VIDEO,
            num_hands=max_hands)
        self._impl = mp_vision.HandLandmarker.create_from_options(opts)
        self._ts = _Ts()
        self._mp = mp
        self._mode = "tasks"

    def process(self, rgb):
        if self._mode == "legacy":
            return self._impl.process(rgb)
        image = self._mp.Image(image_format=self._mp.ImageFormat.SRGB, data=rgb)
        result = self._impl.detect_for_video(image, self._ts.next())
        hands = getattr(result, "hand_landmarks", None) or []
        return types.SimpleNamespace(multi_hand_landmarks=[_Landmarks(h) for h in hands])

    def close(self):
        try:
            self._impl.close()
        except Exception:
            pass


if __name__ == "__main__":
    # Vision smoke test:  python -m sentinel.vision.mp_compat
    import cv2
    mode, detail = probe_mediapipe()
    print(f"MediaPipe: {detail}")
    if mode == "none":
        sys.exit(1)
    try:
        face, hands = FaceMeshWrapper(), HandsWrapper()
    except VisionUnavailable as e:
        print(f"FAILED: {e}")
        sys.exit(1)
    cap = cv2.VideoCapture(0, cv2.CAP_DSHOW if sys.platform == "win32" else cv2.CAP_ANY)
    if not cap.isOpened():
        print("camera index 0 unavailable")
        sys.exit(1)
    print("10-second test: look at the camera, then raise a hand near your face…")
    t0, last, frames, saw_face, saw_hand = time.time(), None, 0, 0, 0
    while time.time() - t0 < 10:
        ok, frame = cap.read()
        if not ok:
            continue
        frames += 1
        rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        fr, hr = face.process(rgb), hands.process(rgb)
        nf, nh = len(fr.multi_face_landmarks or []), len(hr.multi_hand_landmarks or [])
        saw_face += nf > 0
        saw_hand += nh > 0
        if (nf, nh) != last and (nf or nh or last):
            lm = len(fr.multi_face_landmarks[0].landmark) if nf else 0
            print(f"  t+{time.time() - t0:4.1f}s  faces={nf} hands={nh}"
                  + (f" face-landmarks={lm} (478 expected)" if nf else ""))
        last = (nf, nh)
    cap.release(); face.close(); hands.close()
    print(f"\nframes={frames}  face seen in {saw_face}  hand seen in {saw_hand}")
    if saw_face == 0:
        print("NO FACE EVER DETECTED — check lighting/camera and report back.")
        sys.exit(1)
    print("Vision stack OK. Next:  python -m tests.test_gaze --seconds 20")