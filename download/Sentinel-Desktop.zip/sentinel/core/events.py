import threading, traceback

class EventBus:
    """Synchronous, thread-safe pub/sub. Handler exceptions are logged, never fatal."""
    def __init__(self):
        self._subs = {}
        self._lock = threading.Lock()
        self.on_error = None
    def subscribe(self, etype, fn):
        with self._lock: self._subs.setdefault(etype, []).append(fn)
    def publish(self, etype, data=None):
        with self._lock: handlers = list(self._subs.get(etype, ()))
        for fn in handlers:
            try: fn(data if data is not None else {})
            except Exception:
                if self.on_error: self.on_error(f"{etype} handler {fn}: {traceback.format_exc()}")