import collections
import threading
import time


class Arbiter:
    """Central hub: scoring, tier/level decisions, stats. Owns the bus and refs
    to every subsystem so plugins can register(arbiter) with one argument."""

    def __init__(self, bus, cfg, db):
        self.bus, self.cfg, self.db = bus, cfg, db
        self.ui = None
        self.audio = None
        self.camera = None
        self.alerts = None
        self.lock = threading.RLock()
        self._stop = threading.Event()
        s = cfg.get("scoring")
        self.score = float(s["start_score"])
        self.clamp = tuple(s["clamp"])
        db.start_session()
        # live inputs
        self.gaze = "UNKNOWN"
        self.present = True
        self.phone_active = False
        self.phone_since = None
        self.desktop = "UNKNOWN"
        self.distraction_since = None
        self.absent_since = None
        self._promise_reasons = set()
        self._promise_breach_active = set()
        # bookkeeping
        self.t_start = time.time()
        self.last_tick = time.time()
        self.state_seconds = collections.Counter()
        self.distraction_titles = collections.Counter()
        self.recent_events = []  # (t, kind) for repeat escalation
        self.history = []  # (t, state, score) @1Hz — report timeline
        self._stand_down = (
            set()
        )  # plugins add reasons (pomodoro break, eye rest)
        self._snooze = (
            {}
        )  # reason -> until-timestamp (acknowledged alerts)
        self.latest = {}
        for et, fn in [
            ("gaze.state", self._on_gaze),
            ("phone.active", self._on_phone),
            ("phone.glance", self._on_glance),
            ("phone.sustained", self._on_sustained),
            ("presence.state", self._on_presence),
            ("presence.absent", self._on_absent),
            ("presence.returned", self._on_returned),
            ("desktop.activity", self._on_desktop),
        ]:
            bus.subscribe(et, fn)
        self.thread = threading.Thread(
            target=self.run, daemon=True, name="arbiter"
        )

    # ---------- stand-down (plugins may suppress enforcement) ----------
    def add_stand_down(self, tag):
        with self.lock:
            self._stand_down.add(tag)

    def remove_stand_down(self, tag):
        with self.lock:
            self._stand_down.discard(tag)

    def snooze_alert(self, reason, seconds):
        """User acknowledged an alert for `reason`: cap its escalation at Tier 1
        for the next `seconds`. Score penalties still apply — acknowledgment
        pauses the alarm, not the accountability."""
        with self.lock:
            self._snooze[reason] = time.time() + seconds

    def record_promise(self, reason):
        """Record a checked acknowledgement for the rest of this session."""
        # Repeats are escalation labels for the same underlying behaviour. Store
        # the canonical action so a renewed alert cannot dodge its promise.
        reason = {
            "repeat_phone": "sustained_phone",
            "repeat_distraction": "distracted_screen",
        }.get(reason, reason)
        with self.lock:
            self._promise_reasons.add(reason)
        self.db.log_event("alert.promise", {"reason": reason}, source="arbiter")

    # ---------- event handlers ----------
    def _on_gaze(self, d):
        with self.lock:
            self.gaze = d.get("class", "UNKNOWN")

    def _on_phone(self, d):
        with self.lock:
            self.phone_active = bool(d.get("active"))
            self.phone_since = time.time() if self.phone_active else None

    def _on_glance(self, d):
        self._event_penalty("phone_glance_under_5s", d, source="phone")

    def _on_sustained(self, d):
        with self.lock:
            self.recent_events.append((time.time(), "phone_sustained"))
        self._event_penalty("phone_sustained_over_10s", d, source="phone")

    def _on_presence(self, d):
        with self.lock:
            self.present = bool(d.get("present", True))
            self.absent_since = None if self.present else (self.absent_since or time.time())

    def _on_absent(self, d):
        self._event_penalty("left_frame", d, source="presence")

    def _on_returned(self, d):
        self.db.log_event("presence.returned", d, source="presence")

    def _on_desktop(self, d):
        with self.lock:
            label = d.get("label", "NEUTRAL")
            now = time.time()
            if label == "DISTRACTION":
                if self.desktop != "DISTRACTION":
                    self.distraction_since = now
                    self.recent_events.append((now, "distraction"))
                self.distraction_titles[d.get("title", "?")[:80]] += 1
            else:
                self.distraction_since = None
            self.desktop = label
        self.db.log_event("desktop.activity", d, source="desktop")

    # ---------- scoring ----------
    def _adjust(self, delta, reason):
        lo, hi = self.clamp
        new = max(lo, min(hi, self.score + delta))
        if abs(new - self.score) < 1e-9:
            return
        self.db.log_score(new, new - self.score, reason)
        self.score = new
        self.bus.publish(
            "score.change",
            {
                "score": round(new, 2),
                "delta": round(delta, 3),
                "reason": reason,
            },
        )

    def _event_penalty(self, key, data, source=""):
        pts = self.cfg.get(f"scoring.per_event.{key}")
        if pts is None:
            self.db.log_event(
                "scoring.unknown_key", {"key": key}, source="arbiter"
            )
            return
        with self.lock:
            self._adjust(float(pts), f"event:{key}")
        self.db.log_event(
            "penalty",
            {"key": key, "points": pts, **(data or {})},
            source=source,
        )

    def apply_penalty(self, points, reason):
        """Generic API for invented features (plugins). Values still come from config
        by convention — plugins read their own keys and pass the number here."""
        with self.lock:
            self._adjust(float(points), f"plugin:{reason}")

    def _dominant_state(self, now):
        if self._stand_down:
            return "break"
        if not self.present:
            return "absent"
        sus = self.cfg.get("phone.sustained_s", 10)
        if self.phone_active and self.phone_since and now - self.phone_since >= sus:
            return "sustained_phone"
        desk_mode = self.cfg.get("camera.mode", "desk") == "desk"
        if self.desktop == "DISTRACTION" and (desk_mode or self.gaze in (
            "SCREEN",
            "PHONE",
            "UNKNOWN",
        )):
            return "distracted_screen"
        if self.gaze == "PAPER":
            return "studying_paper"
        if self.desktop == "STUDY" and (desk_mode or self.gaze == "SCREEN"):
            return "studying_screen"
        return "neutral_idle"

    def _maybe_promise_breach(self, reason):
        """Apply one severe extra penalty per continuous repeated behavior."""
        if reason not in self._promise_reasons or reason in self._promise_breach_active:
            return
        self._promise_breach_active.add(reason)
        points = float(self.cfg.get("alerts.promise_repeat_penalty",
                                    self.cfg.get("scoring.per_event.promise_repeat_breach", -40)))
        self._adjust(points, f"promise_repeat:{reason}")
        self.db.log_event("alert.promise_breached", {"reason": reason, "points": points}, source="arbiter")

    def _check_promise_breaches(self, now):
        action_s = float(self.cfg.get("alerts.action_sustained_s", 30))
        score_threshold = float(self.cfg.get("alerts.annoying_score_threshold", 40))
        active = set()
        if not self.present and now - (self.absent_since or (now - action_s)) >= action_s:
            active.add("left_frame")
        if self.phone_active and self.phone_since and now - self.phone_since >= action_s:
            active.add("sustained_phone")
        if self.desktop == "DISTRACTION" and self.distraction_since and now - self.distraction_since >= action_s:
            active.add("distracted_screen")
        if self.score <= score_threshold:
            active.add("score_threshold")
        for reason in active:
            self._maybe_promise_breach(reason)
        self._promise_breach_active.intersection_update(active)

    def _snapshot(self, now):
        s = self.cfg.get("scoring")
        t = s["tiers"]
        score = self.score
        label = (
            "excellent"
            if score >= t["excellent"]
            else "okay"
            if score >= t["okay"]
            else "warning"
            if score >= t["warning"]
            else "critical"
        )
        score_level = 3 if score <= float(self.cfg.get("alerts.annoying_score_threshold", t["warning"])) else 0
        hard, reason = 0, ""
        action_s = float(self.cfg.get("alerts.action_sustained_s", 30))
        if not self.present and now - (self.absent_since or (now - action_s)) >= action_s:
            hard, reason = 3, "left_frame"
        else:
            sus = self.cfg.get("phone.sustained_s", 10)
            if self.phone_active and self.phone_since and now - self.phone_since >= sus:
                hard, reason = 3, "sustained_phone"
            dsus = action_s
            if (
                self.desktop == "DISTRACTION"
                and (self.cfg.get("camera.mode", "desk") == "desk"
                     or self.gaze in ("SCREEN", "UNKNOWN"))
                and self.distraction_since
                and now - self.distraction_since >= dsus
            ):
                hard, reason = max(hard, 3), "distracted_screen"
        # repeat escalation inside the window
        win = self.cfg.get("alerts.repeat_window_s", 300)
        kinds = [k for ts, k in self.recent_events if now - ts <= win]
        thr = int(self.cfg.get("alerts.repeat_threshold", 3))
        if kinds.count("phone_sustained") >= thr and hard >= 2:
            hard, reason = 3, "repeat_phone"
        if kinds.count("distraction") >= thr and hard >= 2:
            hard, reason = 3, "repeat_distraction"
        if not reason and score_level >= 3:
            reason = "score_threshold"
        # acknowledged reasons: nudge-tier only while the grace period lasts
        self._snooze = {
            r: until for r, until in self._snooze.items() if until > now
        }
        if reason and reason in self._snooze:
            hard = min(hard, 1)
            score_level = min(score_level, 1)
        level = 0 if self._stand_down else max(score_level, hard)
        desk_mode = self.cfg.get("camera.mode", "desk") == "desk"
        compliant = (self.present and not self.phone_active and self.desktop != "DISTRACTION"
                     and (desk_mode or self.gaze in ("PAPER", "SCREEN")))
        return {
            "score": round(score, 1),
            "tier": label,
            "level": level,
            "hard_reason": reason,
            "state": self._dominant_state(now),
            "gaze": self.gaze,
            "present": self.present,
            "phone": self.phone_active,
            "desktop": self.desktop,
            "stand_down": bool(self._stand_down),
            "compliant": compliant,
            "t": now,
        }

    # ---------- main loop ----------
    def run(self):
        while not self._stop.is_set():
            time.sleep(1.0)
            with self.lock:
                now = time.time()
                raw_gap = now - self.last_tick
                if raw_gap > 5:
                    self.db.log_event(
                        "system.sleep_gap",
                        {"seconds": round(raw_gap, 1)},
                        source="arbiter",
                    )
                dt = min(raw_gap, 2.0)
                self.last_tick = now
                state = self._dominant_state(now)
                self._check_promise_breaches(now)
                rate = float(
                    self.cfg.get(f"scoring.per_minute.{state}", 0) or 0
                )
                if rate and not self._stand_down:
                    self._adjust(rate * dt / 60.0, f"rate:{state}")
                self.state_seconds[state] += dt
                self.history.append((now, state, round(self.score, 1)))
                self.recent_events = [
                    e for e in self.recent_events if now - e[0] <= 400
                ]
                self.latest = self._snapshot(now)
            self.bus.publish("arbiter.snapshot", dict(self.latest))
            if self.alerts:
                try:
                    self.alerts.on_snapshot(self.latest)
                except Exception as e:
                    self.db.log_event("error.alerts", {"error": str(e)})

    def stop(self):
        self._stop.set()

    def start(self):
        self.thread.start()

    def finalize(self):
        with self.lock:
            total = max(time.time() - self.t_start, 1)
            study = (
                self.state_seconds["studying_paper"]
                + self.state_seconds["studying_screen"]
            )
            distract = (
                self.state_seconds["distracted_screen"]
                + self.state_seconds["sustained_phone"]
                + self.state_seconds["absent"]
            )
            timeline = []
            for t, state, _ in self.history:
                if not timeline or timeline[-1][1] != state:
                    timeline.append([t, state])
            if self.history:
                timeline.append([self.history[-1][0], self.history[-1][1]])
            return {
                "total_s": total,
                "study_s": study,
                "distracted_s": distract,
                "focus_pct": round(100 * study / total, 1),
                "absent_s": self.state_seconds["absent"],
                "phone_s": self.state_seconds["sustained_phone"],
                "timeline": timeline,
                "top_distractions": self.distraction_titles.most_common(5),
                "end_score": round(self.score, 1),
            }
