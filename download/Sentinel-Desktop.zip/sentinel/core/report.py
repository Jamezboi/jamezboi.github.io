"""Sentinel Focus After-Action Report Generator.
Produces high-quality, standalone HTML session reports with score trajectory,
state timeline, distraction leaks analysis, lifetime stats, and Proctor debrief.
"""
import datetime
import html
import os
import time

STATE_COLORS = {
    "studying_paper": "#10b981",
    "studying_screen": "#34d399",
    "neutral_idle": "#64748b",
    "distracted_screen": "#f59e0b",
    "sustained_phone": "#ef4444",
    "absent": "#a855f7",
    "break": "#38bdf8",
}

STATE_LABELS = {
    "studying_paper": "Paper Study 📖",
    "studying_screen": "Screen Study 💻",
    "neutral_idle": "Neutral Idle ⏸️",
    "distracted_screen": "Distracted ⚠️",
    "sustained_phone": "Phone Use 📱",
    "absent": "Off Desk 🚪",
    "break": "Pomodoro Break ☕",
}

TIER_COLORS = {
    "excellent": "#10b981",
    "okay": "#f59e0b",
    "warning": "#f97316",
    "critical": "#ef4444",
}


def _svg_curve(scores, w=760, h=220):
    if not scores:
        return '<div style="padding:40px; text-align:center; color:#64748b;">No score logs recorded for this session.</div>'
    try:
        t0 = time.mktime(datetime.datetime.fromisoformat(scores[0][0]).timetuple())
        t_last = time.mktime(datetime.datetime.fromisoformat(scores[-1][0]).timetuple())
        total = max(t_last - t0, 1)
    except Exception:
        total = max(len(scores), 1)
        t0 = 0

    pts = []
    for i, s in enumerate(scores):
        try:
            cur_t = time.mktime(datetime.datetime.fromisoformat(s[0]).timetuple())
            x = 30 + (cur_t - t0) / total * (w - 60)
        except Exception:
            x = 30 + (i / total) * (w - 60)
        val = max(0, min(100, float(s[1])))
        y = h - 25 - (val / 100.0) * (h - 50)
        pts.append(f"{x:.1f},{y:.1f}")

    poly_pts = " ".join(pts)
    first_x = pts[0].split(",")[0]
    last_x = pts[-1].split(",")[0]
    fill_pts = f"{first_x},{h-25} " + poly_pts + f" {last_x},{h-25}"

    bands = "".join(
        f'<line x1="30" x2="{w - 30}" y1="{h - 25 - v / 100.0 * (h - 50):.1f}" '
        f'y2="{h - 25 - v / 100.0 * (h - 50):.1f}" stroke="{c}" stroke-dasharray="4 4" stroke-width="1" opacity="0.35"/>'
        f'<text x="{w - 26}" y="{h - 21 - v / 100.0 * (h - 50):.1f}" fill="{c}" font-size="10" font-family="sans-serif">{v}</text>'
        for v, c in ((85, "#10b981"), (60, "#f59e0b"), (40, "#f97316"), (20, "#ef4444"))
    )

    return f"""<svg width="100%" height="{h}" viewBox="0 0 {w} {h}" preserveAspectRatio="none" style="display:block;">
      <defs>
        <linearGradient id="scoreGrad" x1="0%" y1="0%" x2="0%" y2="100%">
          <stop offset="0%" stop-color="#38bdf8" stop-opacity="0.35"/>
          <stop offset="100%" stop-color="#38bdf8" stop-opacity="0.0"/>
        </linearGradient>
      </defs>
      {bands}
      <polygon points="{fill_pts}" fill="url(#scoreGrad)"/>
      <polyline points="{poly_pts}" fill="none" stroke="#38bdf8" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"/>
    </svg>"""


def _svg_timeline(timeline, t_start, t_end, w=760, h=26):
    if not timeline:
        return ""
    total = max(t_end - t_start, 1)
    parts = []
    for i, (t, state) in enumerate(timeline):
        t2 = timeline[i + 1][0] if i + 1 < len(timeline) else t_end
        x = (t - t_start) / total * w
        width = max((t2 - t) / total * w, 2.0)
        color = STATE_COLORS.get(state, "#334155")
        label = STATE_LABELS.get(state, state)
        parts.append(
            f'<rect x="{x:.1f}" y="0" width="{width:.1f}" height="{h}" '
            f'fill="{color}" rx="3"><title>{label} ({int(t2 - t)}s)</title></rect>'
        )
    return f"""<svg width="100%" height="{h}" viewBox="0 0 {w} {h}" preserveAspectRatio="none" style="display:block; border-radius:6px;">
      {"".join(parts)}
    </svg>"""


def _coach(stats, top):
    f = stats.get("focus_pct", 0)
    top_s = f" Your biggest distraction leak was “{top[0][0]}” ({top[0][1]} checks)." if top else ""
    if f >= 85:
        verdict = "Outstanding discipline. You owned your desk and executed with surgical precision."
        tip = "Keep this benchmark as your standard. Excellent momentum."
    elif f >= 70:
        verdict = "Solid session. You experienced minor gravity pulls, but consistently refocused." + top_s
        tip = "Close any background messaging or browser tabs before starting your next block."
    elif f >= 50:
        verdict = "Moderate friction. Focus fractured periodically during this block." + top_s
        tip = "Consider enabling the Pomodoro plugin for structured 25-minute sprints with mandatory breaks."
    else:
        verdict = "Difficult session. Desktop distractions claimed significant focus capital." + top_s
        tip = "Tomorrow, run an Exam Lockdown or Deep Work profile and set a single strict outcome."
    return verdict, tip


def generate_report(db, stats, cfg, session_id):
    os.makedirs("reports", exist_ok=True)
    scores = db.scores_for(session_id)
    events = db.events_for(session_id)
    life = db.lifetime_stats()
    heat = db.heatmap(14)
    days = sorted({k.split("|")[0] for k in heat}, reverse=True)[:14]

    # End score and tier
    end_score = stats.get("end_score", 100.0)
    tiers = cfg.get("scoring.tiers", {"excellent": 85, "okay": 60, "warning": 40, "critical": 20})
    if end_score >= tiers.get("excellent", 85):
        tier_label = "EXCELLENT"
        tier_col = "#10b981"
    elif end_score >= tiers.get("okay", 60):
        tier_label = "OKAY"
        tier_col = "#f59e0b"
    elif end_score >= tiers.get("warning", 40):
        tier_label = "WARNING"
        tier_col = "#f97316"
    else:
        tier_label = "CRITICAL"
        tier_col = "#ef4444"

    # Distraction heatmap matrix
    hm_rows = []
    hm_rows.append("<tr><th>Day \\ Hour</th>" + "".join(f"<th>{i:02d}</th>" for i in range(24)) + "</tr>")
    for d in days:
        cells = [f'<td style="font-weight:600; font-size:11px;">{d}</td>']
        for i in range(24):
            v = heat.get(f"{d}|{i}", 0)
            if v > 5:
                bg = "#ef4444"
            elif v > 2:
                bg = "#f59e0b"
            elif v > 0:
                bg = "#3b82f6"
            else:
                bg = "#111c30"
            cells.append(f'<td style="background:{bg}; text-align:center; font-size:10px;">{v if v else ""}</td>')
        hm_rows.append("<tr>" + "".join(cells) + "</tr>")
    hm_table = "".join(hm_rows)

    # Top distractions list
    top_dist = stats.get("top_distractions", [])
    max_hits = max([count for _, count in top_dist], default=1)
    if top_dist:
        dist_html = "".join(
            f"""<div style="margin-bottom:12px;">
              <div style="display:flex; justify-content:space-between; font-size:13px; margin-bottom:4px;">
                <span><b>{html.escape(str(name))}</b></span>
                <span style="color:#f87171; font-weight:700;">{count} occurrences</span>
              </div>
              <div style="height:6px; background:#1e293b; border-radius:3px; overflow:hidden;">
                <div style="width:{min(100, int(count / max_hits * 100))}%; height:100%; background:linear-gradient(90deg, #f59e0b, #ef4444); border-radius:3px;"></div>
              </div>
            </div>"""
            for name, count in top_dist
        )
    else:
        dist_html = '<div style="color:#10b981; font-size:13px; font-weight:600;">✓ Zero desktop distraction leaks recorded. Perfect session fidelity.</div>'

    # Timeline SVG
    tl = stats.get("timeline", [])
    t_start = tl[0][0] if tl else 0
    t_end = tl[-1][0] if tl else 1
    timeline_svg = _svg_timeline(tl, t_start, t_end)

    # Event log tail
    ev_items = []
    for e in events[-80:]:
        ts = str(e[0]).replace("T", " ")
        etype = str(e[1])
        raw_data = str(e[2])[:120]
        is_bad = etype == "penalty" or "sustained" in etype or "absent" in etype
        is_study = "STUDY" in raw_data
        badge_cls = "badge-danger" if is_bad else ("badge-success" if is_study else "badge-info")
        ev_items.append(
            f"""<tr>
              <td style="font-family:monospace; color:#94a3b8; font-size:12px;">{html.escape(ts)}</td>
              <td><span class="badge {badge_cls}">{html.escape(etype)}</span></td>
              <td style="color:#e2e8f0; font-size:12px;">{html.escape(raw_data)}</td>
            </tr>"""
        )
    ev_table = "".join(ev_items) if ev_items else '<tr><td colspan="3" style="text-align:center; color:#64748b;">No events recorded.</td></tr>'

    verdict_text, tip_text = _coach(stats, top_dist)
    label = html.escape(cfg.get("session.label", "") or "Unlabeled Focus Block")
    total_min = stats.get("total_s", 0) / 60.0
    study_min = stats.get("study_s", 0) / 60.0
    dist_min = stats.get("distracted_s", 0) / 60.0
    absent_min = stats.get("absent_s", 0) / 60.0
    focus_pct = stats.get("focus_pct", 0)
    now_str = datetime.datetime.now().strftime("%B %d, %Y · %I:%M %p")

    # Score circle gauge parameters
    score_pct = max(0, min(100, end_score))
    circumference = 2 * 3.14159 * 54
    stroke_dashoffset = circumference * (1 - score_pct / 100.0)

    html_content = f"""<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Sentinel Debrief — Session #{session_id}</title>
<style>
:root {{
  --bg: #070e1c;
  --bg-surface: #0f1b2f;
  --bg-card: #14243d;
  --border: #21375a;
  --text: #f1f5f9;
  --text-muted: #94a3b8;
  --primary: #38bdf8;
  --success: #10b981;
  --warning: #f59e0b;
  --danger: #ef4444;
}}
* {{ box-sizing: border-box; margin: 0; padding: 0; }}
body {{
  font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
  background: var(--bg);
  color: var(--text);
  line-height: 1.5;
  padding: 30px 20px;
}}
.container {{
  max-width: 960px;
  margin: 0 auto;
}}
header {{
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 24px;
  padding-bottom: 18px;
  border-bottom: 1px solid var(--border);
}}
.brand {{
  display: flex;
  align-items: center;
  gap: 14px;
}}
.brand-logo {{
  width: 44px;
  height: 44px;
  border-radius: 50%;
  background: linear-gradient(135deg, #2563eb, #38bdf8);
  display: flex;
  align-items: center;
  justify-content: center;
  font-weight: 800;
  font-size: 22px;
  color: #fff;
  box-shadow: 0 0 16px rgba(56, 189, 248, 0.4);
}}
.btn {{
  background: var(--bg-surface);
  border: 1px solid var(--border);
  color: var(--text);
  padding: 8px 14px;
  border-radius: 6px;
  font-size: 13px;
  font-weight: 600;
  cursor: pointer;
  display: inline-flex;
  align-items: center;
  gap: 6px;
  text-decoration: none;
  transition: all 0.2s;
}}
.btn:hover {{
  background: #1e293b;
  border-color: var(--primary);
}}
.btn-primary {{
  background: #2563eb;
  border-color: #3b82f6;
  color: #fff;
}}
.btn-primary:hover {{
  background: #1d4ed8;
}}
.card {{
  background: var(--bg-card);
  border: 1px solid var(--border);
  border-radius: 12px;
  padding: 22px;
  margin-bottom: 20px;
}}
.card-title {{
  font-size: 15px;
  font-weight: 700;
  margin-bottom: 14px;
  display: flex;
  align-items: center;
  gap: 8px;
  color: var(--primary);
  text-transform: uppercase;
  letter-spacing: 0.5px;
}}
.hero-grid {{
  display: grid;
  grid-template-columns: 200px 1fr;
  gap: 24px;
  align-items: center;
}}
@media (max-width: 768px) {{
  .hero-grid {{ grid-template-columns: 1fr; justify-items: center; text-align: center; }}
}}
.stats-grid {{
  display: grid;
  grid-template-columns: repeat(4, 1fr);
  gap: 14px;
}}
@media (max-width: 640px) {{
  .stats-grid {{ grid-template-columns: repeat(2, 1fr); }}
}}
.stat-box {{
  background: #0a1424;
  border: 1px solid var(--border);
  border-radius: 8px;
  padding: 14px;
  text-align: center;
}}
.stat-val {{
  font-size: 22px;
  font-weight: 800;
  color: #fff;
}}
.stat-lbl {{
  font-size: 11px;
  color: var(--text-muted);
  text-transform: uppercase;
  font-weight: 600;
  margin-top: 4px;
}}
.badge {{
  display: inline-block;
  padding: 3px 10px;
  border-radius: 12px;
  font-size: 11px;
  font-weight: 700;
  text-transform: uppercase;
}}
.badge-success {{ background: rgba(16, 185, 129, 0.15); color: #34d399; border: 1px solid rgba(16, 185, 129, 0.3); }}
.badge-danger {{ background: rgba(239, 68, 68, 0.15); color: #f87171; border: 1px solid rgba(239, 68, 68, 0.3); }}
.badge-info {{ background: rgba(56, 189, 248, 0.15); color: #7dd3fc; border: 1px solid rgba(56, 189, 248, 0.3); }}
.coach-box {{
  background: linear-gradient(180deg, rgba(37, 99, 235, 0.08) 0%, rgba(15, 27, 47, 0.4) 100%);
  border-left: 4px solid var(--primary);
  padding: 16px 20px;
  border-radius: 0 8px 8px 0;
  margin-top: 10px;
}}
table {{
  width: 100%;
  border-collapse: collapse;
  font-size: 12px;
}}
th, td {{
  padding: 8px 10px;
  border: 1px solid var(--border);
  text-align: left;
}}
th {{
  background: #0a1424;
  color: var(--text-muted);
  font-weight: 600;
}}
.legend {{
  display: flex;
  gap: 14px;
  flex-wrap: wrap;
  font-size: 11px;
  color: var(--text-muted);
  margin-top: 10px;
}}
.legend-item {{
  display: flex;
  align-items: center;
  gap: 6px;
}}
.legend-dot {{
  width: 10px;
  height: 10px;
  border-radius: 2px;
}}
@media print {{
  body {{ background: #fff; color: #000; padding: 0; }}
  .card {{ border: 1px solid #ccc; background: #fff; color: #000; break-inside: avoid; }}
  .btn {{ display: none; }}
}}
</style>
</head>
<body>

<div class="container">
  <header>
    <div class="brand">
      <div class="brand-logo">S</div>
      <div>
        <h1 style="font-size:18px; font-weight:800;">SENTINEL FOCUS DEBRIEF</h1>
        <p style="font-size:12px; color:var(--text-muted);">{now_str} · Session #{session_id}</p>
      </div>
    </div>
    <div style="display:flex; gap:10px;">
      <button class="btn" onclick="window.print()">🖨️ Print / Save PDF</button>
      <a class="btn btn-primary" href="http://127.0.0.1:8765" target="_blank">⚙️ Settings Console</a>
    </div>
  </header>

  <!-- Hero Performance Card -->
  <div class="card">
    <div style="font-size:12px; font-weight:700; color:var(--text-muted); margin-bottom:12px;">GOAL / FOCUS CONTRACT: <span style="color:#fff;">{label}</span></div>
    <div class="hero-grid">
      <!-- Circular Gauge -->
      <div style="position:relative; width:130px; height:130px; margin:0 auto;">
        <svg width="130" height="130" viewBox="0 0 130 130">
          <circle cx="65" cy="65" r="54" stroke="#1e293b" stroke-width="10" fill="none"/>
          <circle cx="65" cy="65" r="54" stroke="{tier_col}" stroke-width="10" fill="none"
                  stroke-dasharray="{circumference}" stroke-dashoffset="{stroke_dashoffset}"
                  stroke-linecap="round" transform="rotate(-90 65 65)"/>
        </svg>
        <div style="position:absolute; top:0; left:0; right:0; bottom:0; display:flex; flex-direction:column; align-items:center; justify-content:center;">
          <span style="font-size:32px; font-weight:800; color:#fff;">{int(end_score)}</span>
          <span style="font-size:9px; font-weight:700; color:{tier_col}; text-transform:uppercase;">{tier_label}</span>
        </div>
      </div>

      <!-- Quick Metrics -->
      <div>
        <div class="stats-grid">
          <div class="stat-box">
            <div class="stat-val">{total_min:.1f}m</div>
            <div class="stat-lbl">Session Time</div>
          </div>
          <div class="stat-box">
            <div class="stat-val" style="color:#10b981;">{study_min:.1f}m</div>
            <div class="stat-lbl">Deep Study</div>
          </div>
          <div class="stat-box">
            <div class="stat-val" style="color:#f87171;">{dist_min:.1f}m</div>
            <div class="stat-lbl">Distracted</div>
          </div>
          <div class="stat-box">
            <div class="stat-val" style="color:#38bdf8;">{focus_pct:.0f}%</div>
            <div class="stat-lbl">Focus Ratio</div>
          </div>
        </div>

        <div class="coach-box">
          <div style="font-size:13px; font-weight:600; color:#e2e8f0; margin-bottom:4px;">“{html.escape(verdict_text)}”</div>
          <div style="font-size:12px; color:var(--primary);"><b>Tactical Takeaway:</b> {html.escape(tip_text)}</div>
        </div>
      </div>
    </div>
  </div>

  <!-- Focus Score Trajectory -->
  <div class="card">
    <div class="card-title">📈 Focus Score Trajectory</div>
    {_svg_curve(scores)}
  </div>

  <!-- State Timeline -->
  <div class="card">
    <div class="card-title">⏱️ State Progression Timeline</div>
    {timeline_svg}
    <div class="legend">
      <div class="legend-item"><div class="legend-dot" style="background:#10b981;"></div><span>Paper Study</span></div>
      <div class="legend-item"><div class="legend-dot" style="background:#34d399;"></div><span>Screen Study</span></div>
      <div class="legend-item"><div class="legend-dot" style="background:#f59e0b;"></div><span>Distraction</span></div>
      <div class="legend-item"><div class="legend-dot" style="background:#ef4444;"></div><span>Phone Use</span></div>
      <div class="legend-item"><div class="legend-dot" style="background:#a855f7;"></div><span>Off Desk</span></div>
      <div class="legend-item"><div class="legend-dot" style="background:#38bdf8;"></div><span>Break</span></div>
    </div>
  </div>

  <div style="display:grid; grid-template-columns: 1fr 1fr; gap:20px;">
    <!-- Top Distractions -->
    <div class="card">
      <div class="card-title">⚠️ Focus Leaks & Distractions</div>
      {dist_html}
    </div>

    <!-- Lifetime Summary -->
    <div class="card">
      <div class="card-title">🏆 Lifetime Achievements</div>
      <div style="font-size:13px; line-height:2;">
        <div>Cumulative Focus Sessions: <b>{life.get('total_sessions', 0)} blocks</b></div>
        <div>Total Time Studied: <b>{life.get('study_hours', 0)} hours</b></div>
        <div>Total Time Distracted: <b>{life.get('distracted_hours', 0)} hours</b></div>
        <div>Active Consistency Streak: <b>{life.get('days_active', 0)} days active</b></div>
      </div>
    </div>
  </div>

  <!-- 14-Day Heatmap -->
  <div class="card">
    <div class="card-title">🔥 14-Day Distraction Heatmap (Hour × Day)</div>
    <div style="overflow-x:auto;">
      <table>{hm_table}</table>
    </div>
  </div>

  <!-- Event Log Stream -->
  <div class="card">
    <div class="card-title">📜 Session Event Log (Recent Tail)</div>
    <div style="overflow-x:auto; max-height:300px; overflow-y:auto;">
      <table>
        <thead>
          <tr>
            <th style="width:150px;">Time</th>
            <th style="width:160px;">Event</th>
            <th>Details</th>
          </tr>
        </thead>
        <tbody>
          {ev_table}
        </tbody>
      </table>
    </div>
  </div>

  <footer style="text-align:center; padding:18px; font-size:11px; color:#64748b; border-top:1px solid var(--border);">
    Sentinel Autonomous Study Focus Proctor · 100% Local Inference & Storage · No External Telemetry
  </footer>
</div>

</body>
</html>"""

    timestamp_str = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
    path = os.path.abspath(os.path.join("reports", f"session_{session_id}_{timestamp_str}.html"))
    with open(path, "w", encoding="utf-8") as f:
        f.write(html_content)
    return path
