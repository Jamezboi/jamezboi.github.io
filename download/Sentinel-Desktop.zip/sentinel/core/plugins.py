import os, importlib.util, glob

class SentinelPlugin:
    """Standard drop-in interface (spec §7): implement register(arbiter).
    The arbiter hub exposes .bus, .cfg, .db, .ui, .audio, .camera."""
    name = "unnamed"
    def register(self, arbiter): raise NotImplementedError
    def stop(self):
        if hasattr(self, "_stop") and hasattr(self._stop, "set"):
            self._stop.set()

_LOADED_PLUGINS = {}

PLUGIN_METADATA = {
    "pomodoro": {
        "name": "Pomodoro Engine",
        "description": "Timed focus and break blocks. Automatic stand-down suppresses penalties during designated breaks.",
        "icon": "🍅",
        "defaults": {"focus_min": 25, "break_min": 5, "long_break_min": 15, "cycles_before_long": 4, "tts": True},
    },
    "streaks": {
        "name": "Daily Focus Streaks",
        "description": "Tracks daily study goals and consecutive days of active focus sessions.",
        "icon": "🔥",
        "defaults": {"daily_goal_minutes": 30},
    },
    "eye_rest": {
        "name": "Eye Rest (20-20-20)",
        "description": "Enforces periodic optical relief (look at 20 ft away for 20 s every 20 min) to prevent digital eye strain.",
        "icon": "👁️",
        "defaults": {"every_min": 20, "rest_s": 20},
    },
    "drowsiness": {
        "name": "Drowsiness & Microsleep Guard",
        "description": "Monitors eye aspect ratio (EAR) and mouth aspect ratio (MAR) to detect drooping eyelids and excessive yawning.",
        "icon": "🥱",
        "defaults": {"blink_closed_ear": 0.18, "microsleep_s": 1.4, "blink_rate_alert": 28, "yawn_mar": 0.62, "yawn_s": 2.0},
    },
    "posture_guard": {
        "name": "Ergonomic Posture Guard",
        "description": "Detects forward head slumping, slouching, and screen-crowding posture shifts.",
        "icon": "🧍",
        "defaults": {"slouch_dy": 0.07, "shrink_ratio": 0.85, "sustained_s": 20, "cooldown_s": 120},
    },
    "camera_tamper": {
        "name": "Camera Tamper & Freeze Guard",
        "description": "Detects frozen video feeds, covered camera lenses, or artificially looped webcam frames.",
        "icon": "📷",
        "defaults": {"frozen_s": 6, "min_diff": 0.6, "cooldown_s": 60},
    },
}

def list_available_plugins(cfg=None, plugins_dir="plugins"):
    """Discover all plugins in plugins/ and return rich status and config."""
    available = []
    enabled_set = set(cfg.get("plugins.enabled", []) if cfg else [])
    
    if os.path.isdir(plugins_dir):
        for path in sorted(glob.glob(os.path.join(plugins_dir, "*.py"))):
            name = os.path.splitext(os.path.basename(path))[0]
            if name.startswith("_") or name == "api": continue
            
            meta = PLUGIN_METADATA.get(name, {
                "name": name.replace("_", " ").title(),
                "description": "Sentinel extension plugin.",
                "icon": "🧩",
                "defaults": {},
            })
            
            pcfg = cfg.get(f"plugins.{name}", {}) if cfg else {}
            # Merge defaults with custom config
            active_cfg = dict(meta.get("defaults", {}))
            if isinstance(pcfg, dict):
                active_cfg.update(pcfg)
                
            available.append({
                "id": name,
                "name": meta["name"],
                "description": meta["description"],
                "icon": meta["icon"],
                "enabled": name in enabled_set,
                "is_running": name in _LOADED_PLUGINS,
                "config": active_cfg,
            })
    return available

def load_plugins(arbiter, plugins_dir="plugins", enabled=None):
    """Scan /plugins, import every module, self-register every SentinelPlugin
    subclass whose name is in the enabled list."""
    registered = []
    if not os.path.isdir(plugins_dir): return registered
    for path in sorted(glob.glob(os.path.join(plugins_dir, "*.py"))):
        name = os.path.splitext(os.path.basename(path))[0]
        if name.startswith("_") or name == "api": continue
        try:
            spec = importlib.util.spec_from_file_location(f"plugins.{name}", path)
            mod = importlib.util.module_from_spec(spec); spec.loader.exec_module(mod)
            for attr in vars(mod).values():
                if (isinstance(attr, type) and issubclass(attr, SentinelPlugin)
                        and attr is not SentinelPlugin and attr.__module__ == mod.__name__):
                    inst = attr()
                    if enabled is not None and inst.name not in (enabled or []): continue
                    inst.register(arbiter)
                    _LOADED_PLUGINS[inst.name] = inst
                    registered.append(inst.name)
        except Exception as e:
            if arbiter and getattr(arbiter, "db", None):
                arbiter.db.log_event("plugin.load_error", {"plugin": name, "error": str(e)[:120]})
    return registered

def toggle_plugin(name, enable, arbiter=None, cfg=None, plugins_dir="plugins"):
    """Enable or disable a plugin at runtime and update configuration."""
    if cfg is None and arbiter is not None:
        cfg = arbiter.cfg
    if not cfg:
        return False
        
    plugins_sec = cfg.data.setdefault("plugins", {})
    enabled_list = list(plugins_sec.get("enabled", []))
    
    if enable:
        if name not in enabled_list:
            enabled_list.append(name)
        plugins_sec["enabled"] = enabled_list
        if arbiter and name not in _LOADED_PLUGINS:
            # Load and register plugin
            path = os.path.join(plugins_dir, f"{name}.py")
            if os.path.exists(path):
                spec = importlib.util.spec_from_file_location(f"plugins.{name}", path)
                mod = importlib.util.module_from_spec(spec); spec.loader.exec_module(mod)
                for attr in vars(mod).values():
                    if (isinstance(attr, type) and issubclass(attr, SentinelPlugin)
                            and attr is not SentinelPlugin and attr.__module__ == mod.__name__):
                        inst = attr()
                        inst.register(arbiter)
                        _LOADED_PLUGINS[name] = inst
                        break
    else:
        if name in enabled_list:
            enabled_list.remove(name)
        plugins_sec["enabled"] = enabled_list
        if name in _LOADED_PLUGINS:
            inst = _LOADED_PLUGINS.pop(name)
            try:
                inst.stop()
            except Exception:
                pass
            if arbiter and hasattr(arbiter, "remove_stand_down"):
                arbiter.remove_stand_down(name)
                
    cfg.save("config.yaml")
    return True