import sqlite3, json, threading, time, os, datetime

_NOW = lambda: datetime.datetime.now().isoformat(timespec="seconds")

class Database:
    def __init__(self, path="sentinel.db"):
        os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
        self.path = path
        self.lock = threading.RLock()
        self.conn = sqlite3.connect(path, check_same_thread=False)
        self.conn.execute("PRAGMA journal_mode=WAL")
        self._exec("""CREATE TABLE IF NOT EXISTS sessions(
            id INTEGER PRIMARY KEY AUTOINCREMENT, started_at TEXT, ended_at TEXT,
            baseline TEXT, report TEXT)""")
        self._exec("""CREATE TABLE IF NOT EXISTS events(
            id INTEGER PRIMARY KEY AUTOINCREMENT, ts TEXT, session_id INTEGER,
            type TEXT, source TEXT, data TEXT)""")
        self._exec("""CREATE TABLE IF NOT EXISTS score_log(
            id INTEGER PRIMARY KEY AUTOINCREMENT, ts TEXT, session_id INTEGER,
            score REAL, delta REAL, reason TEXT)""")
        self._exec("""CREATE TABLE IF NOT EXISTS daily(
            date TEXT PRIMARY KEY, study_seconds REAL, distracted_seconds REAL, sessions INTEGER)""")
        self._exec("""CREATE TABLE IF NOT EXISTS activity_labels(
            signature TEXT PRIMARY KEY, label TEXT NOT NULL, title TEXT,
            process TEXT, updated_at TEXT NOT NULL)""")
        self._exec("""CREATE TABLE IF NOT EXISTS evidence(
            id INTEGER PRIMARY KEY AUTOINCREMENT, ts TEXT, session_id INTEGER,
            reason TEXT, path TEXT, upload_state TEXT NOT NULL DEFAULT 'queued')""")
        self._exec("""CREATE TABLE IF NOT EXISTS phone_training(
            id INTEGER PRIMARY KEY AUTOINCREMENT, ts TEXT NOT NULL,
            is_phone INTEGER NOT NULL, confidence REAL NOT NULL)""")
        self.session_id = None

    def _exec(self, sql, args=()):
        with self.lock:
            cur = self.conn.execute(sql, args); self.conn.commit(); return cur

    def start_session(self, baseline=None):
        self.session_id = self._exec("INSERT INTO sessions(started_at, baseline) VALUES(?,?)",
            (_NOW(), json.dumps(baseline))).lastrowid
        return self.session_id

    def end_session(self, report_path=None):
        if self.session_id:
            self._exec("UPDATE sessions SET ended_at=?, report=? WHERE id=?",
                       (_NOW(), report_path, self.session_id))

    def log_event(self, etype, data, source=""):
        if self.session_id is None: return
        self._exec("INSERT INTO events(ts, session_id, type, source, data) VALUES(?,?,?,?,?)",
                   (_NOW(), self.session_id, etype, source, json.dumps(data, default=str)))

    def log_score(self, score, delta, reason):
        if self.session_id is None: return
        self._exec("INSERT INTO score_log(ts, session_id, score, delta, reason) VALUES(?,?,?,?,?)",
                   (_NOW(), self.session_id, round(score, 2), round(delta, 3), reason))

    def upsert_daily(self, study_s, distracted_s):
        d = datetime.date.today().isoformat()
        with self.lock:
            row = self.conn.execute("SELECT * FROM daily WHERE date=?", (d,)).fetchone()
            if row:
                self.conn.execute("UPDATE daily SET study_seconds=?, distracted_seconds=?, sessions=? WHERE date=?",
                    (row[1] + study_s, row[2] + distracted_s, row[3] + 1, d))
            else:
                self.conn.execute("INSERT INTO daily VALUES(?,?,?,1)", (d, study_s, distracted_s))
            self.conn.commit()

    def events_for(self, sid):
        return self._exec("SELECT ts, type, data FROM events WHERE session_id=? ORDER BY id", (sid,)).fetchall()

    def scores_for(self, sid):
        return self._exec("SELECT ts, score, delta, reason FROM score_log WHERE session_id=? ORDER BY id", (sid,)).fetchall()

    def alert_log(self, sid):
        return self._exec("SELECT ts, type, data FROM events WHERE session_id=? AND type LIKE 'alert.%' ORDER BY id", (sid,)).fetchall()

    def daily_rows(self, n=60):
        return self._exec("SELECT date, study_seconds, distracted_seconds, sessions FROM daily ORDER BY date DESC LIMIT ?", (n,)).fetchall()

    def lifetime_stats(self):
        r = self._exec("SELECT COUNT(*), SUM(study_seconds), SUM(distracted_seconds), SUM(sessions) FROM daily").fetchone()
        return {"days_active": len(self.daily_rows(365)), "total_sessions": r[3] or 0,
                "study_hours": round((r[1] or 0) / 3600, 1), "distracted_hours": round((r[2] or 0) / 3600, 1)}

    def recent_sessions(self, n=20):
        return self._exec("SELECT id,started_at,ended_at,report FROM sessions ORDER BY id DESC LIMIT ?", (n,)).fetchall()

    def list_sessions(self, limit=50):
        """Rich session listing with violation count, duration, and final score."""
        rows = self._exec("""
            SELECT s.id, s.started_at, s.ended_at, s.report,
                   (SELECT COUNT(*) FROM events e WHERE e.session_id = s.id AND (e.type = 'penalty' OR e.type LIKE 'phone.sustained%' OR e.type LIKE 'presence.absent%')) as violations,
                   (SELECT score FROM score_log sl WHERE sl.session_id = s.id ORDER BY sl.id DESC LIMIT 1) as final_score,
                   (SELECT COUNT(*) FROM events e WHERE e.session_id = s.id) as total_events
            FROM sessions s
            ORDER BY s.id DESC
            LIMIT ?
        """, (limit,)).fetchall()
        result = []
        for r in rows:
            dur_str = "Active"
            if r[1] and r[2]:
                try:
                    t1 = datetime.datetime.fromisoformat(r[1])
                    t2 = datetime.datetime.fromisoformat(r[2])
                    sec = int((t2 - t1).total_seconds())
                    dur_str = f"{sec // 60}m {sec % 60}s"
                except Exception:
                    dur_str = "–"
            result.append({
                "id": r[0],
                "started_at": r[1],
                "ended_at": r[2],
                "report": r[3],
                "violations": r[4] or 0,
                "final_score": round(r[5], 1) if r[5] is not None else 100.0,
                "total_events": r[6] or 0,
                "duration": dur_str,
            })
        return result

    def latest_session_id(self):
        row = self._exec("SELECT id FROM sessions ORDER BY id DESC LIMIT 1").fetchone()
        return row[0] if row else None

    def heatmap(self, days=14):
        """(date, hour) -> approx distracted minutes, from DISTRACTION desktop events."""
        rows = self._exec("SELECT ts, data FROM events WHERE type='desktop.activity' AND data LIKE '%DISTRACTION%' ORDER BY id DESC").fetchall()
        grid = {}
        for ts, data in rows:
            try:
                dt = datetime.datetime.fromisoformat(ts)
                if (datetime.datetime.now() - dt).days > days: continue
                grid.setdefault((dt.date().isoformat(), dt.hour), 0)
                grid[(dt.date().isoformat(), dt.hour)] += 1  # ≈1 sample per desktop interval
            except Exception: continue
        return {f"{d}|{h}": m for (d, h), m in grid.items()}

    def train_activity(self, title, process, label):
        label = str(label).upper()
        if label not in ("STUDY", "DISTRACTION", "NEUTRAL"):
            raise ValueError("activity label must be STUDY, DISTRACTION, or NEUTRAL")
        signature = f"{title} {process}".strip().lower()
        if not signature:
            raise ValueError("cannot train an unnamed activity")
        self._exec("INSERT INTO activity_labels(signature,label,title,process,updated_at) VALUES(?,?,?,?,?) "
                   "ON CONFLICT(signature) DO UPDATE SET label=excluded.label,title=excluded.title,"
                   "process=excluded.process,updated_at=excluded.updated_at",
                   (signature, label, title[:300], process[:160], _NOW()))
        return signature

    def activity_labels(self):
        return self._exec("SELECT signature,label FROM activity_labels ORDER BY updated_at DESC").fetchall()

    def activity_labels_full(self):
        return self._exec("SELECT signature,label,title,process,updated_at FROM activity_labels ORDER BY updated_at DESC").fetchall()

    def delete_activity_label(self, signature):
        self._exec("DELETE FROM activity_labels WHERE signature=?", (signature,))
        return True

    def log_evidence(self, reason, path):
        self._exec("INSERT INTO evidence(ts,session_id,reason,path) VALUES(?,?,?,?)",
                   (_NOW(), self.session_id, reason, path))

    def queued_evidence(self):
        return self._exec("SELECT id,ts,reason,path FROM evidence WHERE upload_state='queued' ORDER BY id").fetchall()

    def train_phone(self, is_phone, confidence):
        self._exec("INSERT INTO phone_training(ts,is_phone,confidence) VALUES(?,?,?)",
                   (_NOW(), int(bool(is_phone)), float(confidence)))

    def phone_threshold(self, default):
        rows = self._exec("SELECT is_phone,confidence FROM phone_training ORDER BY id DESC LIMIT 100").fetchall()
        yes = [r[1] for r in rows if r[0]]
        no = [r[1] for r in rows if not r[0]]
        if yes and no:
            return max(0.05, min(0.95, (sum(yes) / len(yes) + sum(no) / len(no)) / 2))
        if yes:
            return max(0.05, min(0.95, (sum(yes) / len(yes)) * 0.8))
        return float(default)

    def query_logs(self, session_id=None, start_time=None, end_time=None, event_type=None, keyword=None, limit=100, offset=0):
        """Flexible query for logs filtered across different times, sessions, types, and keywords."""
        conditions = []
        params = []
        if session_id is not None and session_id != "" and session_id != "all":
            try:
                conditions.append("session_id = ?")
                params.append(int(session_id))
            except ValueError:
                pass
        if start_time:
            conditions.append("ts >= ?")
            params.append(str(start_time))
        if end_time:
            conditions.append("ts <= ?")
            params.append(str(end_time))
        if event_type and event_type != "all":
            if event_type == "violations":
                conditions.append("(type = 'penalty' OR type LIKE 'phone.sustained%' OR type LIKE 'presence.absent%')")
            elif event_type == "distractions":
                conditions.append("(type = 'desktop.activity' AND data LIKE '%DISTRACTION%')")
            elif event_type == "penalties":
                conditions.append("type = 'penalty'")
            elif event_type == "alerts":
                conditions.append("type LIKE 'alert.%'")
            elif event_type == "plugins":
                conditions.append("(type LIKE 'pomodoro.%' OR type LIKE 'streaks.%' OR type LIKE 'plugin.%')")
            else:
                conditions.append("type LIKE ?")
                params.append(f"%{event_type}%")
        if keyword:
            kw = f"%{keyword.strip()}%"
            conditions.append("(type LIKE ? OR source LIKE ? OR data LIKE ?)")
            params.extend([kw, kw, kw])

        where_clause = " WHERE " + " AND ".join(conditions) if conditions else ""

        # Total count
        count_sql = f"SELECT COUNT(*) FROM events{where_clause}"
        total = self._exec(count_sql, tuple(params)).fetchone()[0]

        # Paginated items
        select_sql = f"SELECT id, ts, session_id, type, source, data FROM events{where_clause} ORDER BY id DESC LIMIT ? OFFSET ?"
        rows = self._exec(select_sql, tuple(params + [limit, offset])).fetchall()

        events = []
        for r in rows:
            try:
                parsed_data = json.loads(r[5] or "{}")
            except Exception:
                parsed_data = r[5] or ""
            events.append({
                "id": r[0],
                "ts": r[1],
                "session_id": r[2],
                "type": r[3],
                "source": r[4],
                "data": parsed_data,
            })
        return {"total": total, "events": events, "limit": limit, "offset": offset}

    def session_score_curve(self, session_id):
        """Retrieve score timeline for any historical session."""
        rows = self._exec("SELECT id, ts, score, delta, reason FROM score_log WHERE session_id=? ORDER BY id", (session_id,)).fetchall()
        return [{"id": r[0], "ts": r[1], "score": r[2], "delta": r[3], "reason": r[4]} for r in rows]

    def export_logs_data(self, session_id=None, start_time=None, end_time=None, event_type=None, keyword=None):
        """Export raw log data matching filter criteria."""
        res = self.query_logs(session_id=session_id, start_time=start_time, end_time=end_time,
                                event_type=event_type, keyword=keyword, limit=5000, offset=0)
        return res["events"]

    def close(self):
        with self.lock: self.conn.close()
