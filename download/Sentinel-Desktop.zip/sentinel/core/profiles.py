"""Profiles system for Sentinel: presets and custom configuration profiles."""
import copy
import glob
import json
import os
import yaml

PROFILES_DIR = "profiles"

BUILTIN_PROFILES = {
    "deep_work": {
        "id": "deep_work",
        "name": "Deep Work (Balanced)",
        "badge": "Standard Focus",
        "color": "#38bdf8",
        "description": "Balanced focus accountability for general study and problem solving. Standard penalties and a 5-second countdown grace.",
        "config": {
            "camera": {"mode": "desk"},
            "desktop": {
                "interval_s": 10,
                "jitter_s": 2,
                "ocr": "auto",
            },
            "scoring": {
                "start_score": 100,
                "clamp": [0, 100],
                "tiers": {"critical": 20, "warning": 40, "okay": 60, "excellent": 85},
                "per_minute": {
                    "studying_paper": 10,
                    "studying_screen": 8,
                    "neutral_idle": 0,
                    "distracted_screen": -20,
                    "sustained_phone": -15,
                },
                "per_event": {
                    "phone_glance_under_5s": -5,
                    "phone_sustained_over_10s": -25,
                    "left_frame": -30,
                    "drowsy_microsleep": -5,
                    "slouch_sustained": -5,
                    "camera_blocked": -10,
                    "promise_repeat_breach": -40,
                },
            },
            "alerts": {
                "compliance_s": 5,
                "countdown_s": 5,
                "action_sustained_s": 30,
                "annoying_score_threshold": 40,
                "repeat_window_s": 300,
                "repeat_threshold": 3,
                "ack_snooze_s": 90,
                "ack_max": 3,
                "mute": False,
            },
            "plugins": {
                "enabled": ["pomodoro", "streaks", "eye_rest"],
            },
            "punishments": {
                "enabled": True,
                "typing_pledge": "I will not trade my long-term goals for short-term digital distractions.",
                "math_difficulty": "medium",
                "kill_mode": "terminate",
                "tier2": {"toast_warning": True, "chime": True, "minimize_app": False, "score_tax": 0},
                "tier3": {"countdown_modal": True, "minimize_app": True, "kill_app": False, "typing_challenge": True, "math_challenge": False, "lock_seconds": 5, "score_tax": 10, "physical_action": False},
                "tier4": {"alarm_sound": True, "proctor_drill": True, "kill_app": True, "minimize_app": False, "typing_challenge": True, "math_challenge": True, "lock_seconds": 12, "score_tax": 25, "physical_action": True},
            },
        },
    },
    "exam_strict": {
        "id": "exam_strict",
        "name": "Exam Lockdown (Ultra Strict)",
        "badge": "High Stakes",
        "color": "#ef4444",
        "description": "High-severity proctoring mode with rapid alerts (3s countdown), swift distraction triggers, and heavy score penalties.",
        "config": {
            "camera": {"mode": "desk"},
            "desktop": {
                "interval_s": 5,
                "jitter_s": 1,
                "ocr": "auto",
            },
            "scoring": {
                "start_score": 100,
                "clamp": [0, 100],
                "tiers": {"critical": 30, "warning": 50, "okay": 75, "excellent": 90},
                "per_minute": {
                    "studying_paper": 6,
                    "studying_screen": 5,
                    "neutral_idle": -5,
                    "distracted_screen": -35,
                    "sustained_phone": -30,
                },
                "per_event": {
                    "phone_glance_under_5s": -15,
                    "phone_sustained_over_10s": -40,
                    "left_frame": -45,
                    "drowsy_microsleep": -10,
                    "slouch_sustained": -10,
                    "camera_blocked": -25,
                    "promise_repeat_breach": -50,
                },
            },
            "alerts": {
                "compliance_s": 2,
                "countdown_s": 3,
                "action_sustained_s": 12,
                "annoying_score_threshold": 50,
                "repeat_window_s": 360,
                "repeat_threshold": 1,
                "ack_snooze_s": 45,
                "ack_max": 1,
                "mute": False,
            },
            "plugins": {
                "enabled": ["streaks", "camera_tamper"],
            },
            "punishments": {
                "enabled": True,
                "typing_pledge": "Exam integrity is absolute. I will not seek external distractions.",
                "math_difficulty": "hard",
                "kill_mode": "terminate",
                "tier2": {"toast_warning": True, "chime": True, "minimize_app": True, "score_tax": 5},
                "tier3": {"countdown_modal": True, "minimize_app": True, "kill_app": True, "typing_challenge": True, "math_challenge": True, "lock_seconds": 10, "score_tax": 20, "physical_action": False},
                "tier4": {"alarm_sound": True, "proctor_drill": True, "kill_app": True, "minimize_app": False, "typing_challenge": True, "math_challenge": True, "lock_seconds": 25, "score_tax": 35, "physical_action": True},
            },
        },
    },
    "coding_dev": {
        "id": "coding_dev",
        "name": "Software Engineering / Dev",
        "badge": "Coding Mode",
        "color": "#10b981",
        "description": "Optimized for software developers with whitelisted coding tools, IDEs, terminals, Git platforms, and documentation sites.",
        "config": {
            "camera": {"mode": "desk"},
            "desktop": {
                "interval_s": 15,
                "jitter_s": 3,
                "ocr": "auto",
                "whitelist": [
                    "github", "gitlab", "stackoverflow", "localhost", "127\\.0\\.0\\.1",
                    "postman", "docker", "terminal", "powershell", "cmd\\.exe", "cursor",
                    "visual studio", "vscode", "pycharm", "intellij", "webstorm", "neovim",
                    "devdocs", "developer\\.mozilla\\.org", "chatgpt", "claude\\.ai"
                ],
            },
            "browser": {
                "website_whitelist": [
                    "github.com", "gitlab.com", "stackoverflow.com", "devdocs.io",
                    "docs.python.org", "pypi.org", "npm.im", "developer.mozilla.org",
                    "claude.ai", "chatgpt.com", "gemini.google.com"
                ],
            },
            "scoring": {
                "start_score": 100,
                "clamp": [0, 100],
                "tiers": {"critical": 20, "warning": 40, "okay": 60, "excellent": 85},
                "per_minute": {
                    "studying_paper": 8,
                    "studying_screen": 10,
                    "neutral_idle": 0,
                    "distracted_screen": -22,
                    "sustained_phone": -18,
                },
                "per_event": {
                    "phone_glance_under_5s": -5,
                    "phone_sustained_over_10s": -25,
                    "left_frame": -25,
                    "drowsy_microsleep": -5,
                    "slouch_sustained": -5,
                    "camera_blocked": -10,
                    "promise_repeat_breach": -40,
                },
            },
            "alerts": {
                "compliance_s": 6,
                "countdown_s": 7,
                "action_sustained_s": 35,
                "annoying_score_threshold": 40,
                "repeat_window_s": 300,
                "repeat_threshold": 3,
                "ack_snooze_s": 120,
                "ack_max": 3,
                "mute": False,
            },
            "plugins": {
                "enabled": ["pomodoro", "eye_rest", "streaks", "posture_guard"],
            },
        },
    },
    "casual_reading": {
        "id": "casual_reading",
        "name": "Casual Reading & Research",
        "badge": "Gentle Flow",
        "color": "#a855f7",
        "description": "Relaxed monitoring for reading documentation, whitepapers, textbooks, and long-form research with generous grace periods.",
        "config": {
            "camera": {"mode": "desk"},
            "desktop": {
                "interval_s": 20,
                "jitter_s": 5,
                "ocr": "auto",
            },
            "scoring": {
                "start_score": 100,
                "clamp": [0, 100],
                "tiers": {"critical": 15, "warning": 30, "okay": 50, "excellent": 80},
                "per_minute": {
                    "studying_paper": 12,
                    "studying_screen": 10,
                    "neutral_idle": 0,
                    "distracted_screen": -10,
                    "sustained_phone": -10,
                },
                "per_event": {
                    "phone_glance_under_5s": -2,
                    "phone_sustained_over_10s": -12,
                    "left_frame": -15,
                    "drowsy_microsleep": -2,
                    "slouch_sustained": -2,
                    "camera_blocked": -5,
                    "promise_repeat_breach": -20,
                },
            },
            "alerts": {
                "compliance_s": 10,
                "countdown_s": 10,
                "action_sustained_s": 60,
                "annoying_score_threshold": 30,
                "repeat_window_s": 300,
                "repeat_threshold": 4,
                "ack_snooze_s": 180,
                "ack_max": 5,
                "mute": False,
            },
            "plugins": {
                "enabled": ["eye_rest", "streaks"],
            },
        },
    },
    "focus_flow": {
        "id": "focus_flow",
        "name": "Focus Flow (Silent Proctor)",
        "badge": "Silent Tracking",
        "color": "#f59e0b",
        "description": "Silent background metrics logging. Tracks focus scores, app categories, and daily stats without audible alarms.",
        "config": {
            "camera": {"mode": "desk"},
            "desktop": {
                "interval_s": 15,
                "jitter_s": 3,
                "ocr": "auto",
            },
            "scoring": {
                "start_score": 100,
                "clamp": [0, 100],
                "tiers": {"critical": 20, "warning": 40, "okay": 60, "excellent": 85},
                "per_minute": {
                    "studying_paper": 10,
                    "studying_screen": 8,
                    "neutral_idle": 0,
                    "distracted_screen": -20,
                    "sustained_phone": -15,
                },
                "per_event": {
                    "phone_glance_under_5s": -5,
                    "phone_sustained_over_10s": -25,
                    "left_frame": -30,
                    "drowsy_microsleep": -5,
                    "slouch_sustained": -5,
                    "camera_blocked": -10,
                    "promise_repeat_breach": -40,
                },
            },
            "alerts": {
                "compliance_s": 10,
                "countdown_s": 10,
                "action_sustained_s": 45,
                "annoying_score_threshold": 40,
                "repeat_window_s": 300,
                "repeat_threshold": 3,
                "ack_snooze_s": 120,
                "ack_max": 5,
                "mute": True,
            },
            "plugins": {
                "enabled": ["pomodoro", "streaks", "eye_rest"],
            },
        },
    },
}


def ensure_profiles_dir(directory=PROFILES_DIR):
    os.makedirs(directory, exist_ok=True)
    # Save builtin profiles if they don't exist yet on disk
    for pid, profile in BUILTIN_PROFILES.items():
        path = os.path.join(directory, f"{pid}.yaml")
        if not os.path.exists(path):
            try:
                with open(path, "w", encoding="utf-8") as f:
                    yaml.safe_dump(profile, f, sort_keys=False, default_flow_style=False)
            except Exception:
                pass


def deep_merge(base, override):
    """Deep merge override into base."""
    for k, v in override.items():
        if isinstance(v, dict) and isinstance(base.get(k), dict):
            deep_merge(base[k], v)
        else:
            base[k] = copy.deepcopy(v)
    return base


def list_profiles(directory=PROFILES_DIR, active_id="deep_work"):
    ensure_profiles_dir(directory)
    profiles = {}
    # First load builtins
    for pid, p in BUILTIN_PROFILES.items():
        profiles[pid] = copy.deepcopy(p)
        profiles[pid]["builtin"] = True

    # Scan directory for any updated or custom yaml profiles
    for filepath in glob.glob(os.path.join(directory, "*.yaml")):
        try:
            with open(filepath, "r", encoding="utf-8") as f:
                data = yaml.safe_load(f)
            if isinstance(data, dict) and "id" in data:
                pid = str(data["id"])
                is_builtin = pid in BUILTIN_PROFILES
                profiles[pid] = data
                profiles[pid]["builtin"] = is_builtin
        except Exception:
            continue

    result = []
    for pid, p in profiles.items():
        item = copy.deepcopy(p)
        item["is_active"] = (pid == active_id)
        result.append(item)
    return result


def get_profile(profile_id, directory=PROFILES_DIR):
    ensure_profiles_dir(directory)
    path = os.path.join(directory, f"{profile_id}.yaml")
    if os.path.exists(path):
        try:
            with open(path, "r", encoding="utf-8") as f:
                data = yaml.safe_load(f)
            if isinstance(data, dict):
                return data
        except Exception:
            pass
    if profile_id in BUILTIN_PROFILES:
        return copy.deepcopy(BUILTIN_PROFILES[profile_id])
    return None


def save_custom_profile(profile_data, directory=PROFILES_DIR):
    ensure_profiles_dir(directory)
    pid = profile_data.get("id", "").strip().lower()
    if not pid:
        raise ValueError("Profile must have an 'id'")
    # Sanitize id
    pid = "".join(c if c.isalnum() or c in ("-", "_") else "_" for c in pid)
    profile_data["id"] = pid
    if "name" not in profile_data or not profile_data["name"]:
        profile_data["name"] = pid.replace("_", " ").title()
    path = os.path.join(directory, f"{pid}.yaml")
    with open(path, "w", encoding="utf-8") as f:
        yaml.safe_dump(profile_data, f, sort_keys=False, default_flow_style=False)
    return profile_data


def delete_custom_profile(profile_id, directory=PROFILES_DIR):
    if profile_id in BUILTIN_PROFILES:
        raise ValueError("Cannot delete a built-in profile.")
    path = os.path.join(directory, f"{profile_id}.yaml")
    if os.path.exists(path):
        os.remove(path)
        return True
    return False


def apply_profile(profile_id, cfg, arbiter=None, db=None, save_yaml=True, config_path="config.yaml"):
    """Apply profile settings to config, Arbiter, Desktop sentinel, and persist."""
    profile = get_profile(profile_id)
    if not profile:
        raise ValueError(f"Profile '{profile_id}' not found.")

    pcfg = profile.get("config", {})
    deep_merge(cfg.data, pcfg)
    cfg.data["active_profile"] = profile_id

    # If arbiter is active, update runtime scoring parameters
    if arbiter is not None:
        scoring = cfg.get("scoring")
        if scoring:
            with arbiter.lock:
                arbiter.clamp = tuple(scoring.get("clamp", [0, 100]))
                # Keep score within clamp
                arbiter.score = max(arbiter.clamp[0], min(arbiter.clamp[1], arbiter.score))

    # Reload desktop sentinel rules if present
    if arbiter and getattr(arbiter, "sentinels", None):
        for s in arbiter.sentinels:
            if s.name == "desktop" and hasattr(s, "reload_rules"):
                s.reload_rules()

    # Log profile activation event
    if db is not None:
        try:
            db.log_event("profile.switched", {"profile_id": profile_id, "name": profile.get("name")}, source="profiles")
        except Exception:
            pass

    # Save to disk
    if save_yaml:
        cfg.save(config_path)

    return profile
