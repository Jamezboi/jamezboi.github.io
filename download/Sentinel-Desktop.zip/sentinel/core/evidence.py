"""Violation-only local evidence capture.

Frames are never retained until a confirmed event asks for one.  Desk images
are cropped before saving so the configured upper area (where a face would be)
is excluded.  Upload stays queued until the user supplies an approved target.
"""
import datetime
import os
import threading


class EvidenceCapture:
    def __init__(self, cfg, db, camera=None):
        self.cfg, self.db, self.camera = cfg, db, camera
        self._lock, self._last = threading.Lock(), {}
        self.directory = cfg.get("evidence.directory", "evidence")
        os.makedirs(self.directory, exist_ok=True)

    def _allowed(self, reason):
        if not self.cfg.get("evidence.enabled", True):
            return False
        import time
        with self._lock:
            now, cooldown = time.time(), float(self.cfg.get("evidence.cooldown_s", 30))
            if now - self._last.get(reason, 0) < cooldown:
                return False
            self._last[reason] = now
            return True

    def _path(self, reason, suffix):
        safe = "".join(c if c.isalnum() or c in "-_" else "_" for c in reason)
        stamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S_%f")
        return os.path.abspath(os.path.join(self.directory, f"{stamp}_{safe}.{suffix}"))

    def capture_desktop(self, reason):
        if not self._allowed(reason):
            return None
        try:
            import cv2
            import numpy as np
            from sentinel.utils.platform import mss_instance
            with mss_instance() as sct:
                mon = sct.monitors[min(int(self.cfg.get("desktop.monitor_index", 1)), len(sct.monitors) - 1)]
                image = np.array(sct.grab(mon))[:, :, :3]
            path = self._path(reason, "jpg")
            if not cv2.imwrite(path, image):
                return None
            self.db.log_evidence(reason, path)
            return path
        except Exception as exc:
            self.db.log_event("evidence.error", {"reason": reason, "error": str(exc)[:100]}, source="evidence")
            return None

    def capture_desk(self, reason):
        if not self._allowed(reason) or not self.camera or self.camera.frame is None:
            return None
        try:
            import cv2
            frame = self.camera.frame.copy()
            h, w = frame.shape[:2]
            x0, y0, x1, y1 = self.cfg.get("evidence.desk_crop", [0, .35, 1, 1])
            frame = frame[max(0, int(h * y0)):min(h, int(h * y1)), max(0, int(w * x0)):min(w, int(w * x1))]
            if frame.size == 0:
                return None
            path = self._path(reason, "jpg")
            if not cv2.imwrite(path, frame):
                return None
            self.db.log_evidence(reason, path)
            return path
        except Exception as exc:
            self.db.log_event("evidence.error", {"reason": reason, "error": str(exc)[:100]}, source="evidence")
            return None
