import sys, subprocess, shutil, os, platform

OS = sys.platform  # 'win32' | 'darwin' | 'linux'
OS_NAME = {"win32": "Windows", "darwin": "macOS", "linux": "Linux"}.get(OS, OS)
IS_WAYLAND = OS == "linux" and (os.environ.get("WAYLAND_DISPLAY") or "wayland" in os.environ.get("XDG_SESSION_TYPE", ""))

def active_window():
    """Return (title, process_name) of the focused window, best-effort per OS."""
    try:
        if OS == "win32":
            import ctypes
            from ctypes import wintypes
            user32 = ctypes.windll.user32
            hwnd = user32.GetForegroundWindow()
            if not hwnd: return ("", "")
            buf = ctypes.create_unicode_buffer(512)
            user32.GetWindowTextW(hwnd, buf, 512)
            pid = ctypes.c_ulong()
            user32.GetWindowThreadProcessId(hwnd, ctypes.byref(pid))
            proc = ""
            try:
                import psutil; proc = psutil.Process(pid.value).name()
            except Exception: pass
            return (buf.value, proc)
        if OS == "darwin":
            try:
                from Quartz import (CGWindowListCopyWindowInfo, kCGWindowListOptionOnScreenOnly,
                                    kCGNullWindowID, kCGWindowLayer, kCGWindowName, kCGWindowOwnerName)
                for w in CGWindowListCopyWindowInfo(kCGWindowListOptionOnScreenOnly, kCGNullWindowID):
                    if w.get(kCGWindowLayer) == 0 and w.get(kCGWindowName):
                        return (w.get(kCGWindowName, ""), w.get(kCGWindowOwnerName, ""))
            except ImportError:
                r = subprocess.run(["osascript", "-e",
                    'tell application "System Events" to get name of first application process whose frontmost is true'],
                    capture_output=True, text=True, timeout=5)
                proc = r.stdout.strip() if r.returncode == 0 else ""
                r2 = subprocess.run(["osascript", "-e",
                    'tell application "System Events" to get name of front window of first application process whose frontmost is true'],
                    capture_output=True, text=True, timeout=5)
                return (r2.stdout.strip() if r2.returncode == 0 else "", proc)
            return ("", "")
        # Linux
        if shutil.which("xdotool"):
            wid = subprocess.run(["xdotool", "getactivewindow"], capture_output=True, text=True, timeout=5).stdout.strip()
            if wid:
                title = subprocess.run(["xdotool", "getwindowname", wid], capture_output=True, text=True, timeout=5).stdout.strip()
                pid = subprocess.run(["xdotool", "getwindowpid", wid], capture_output=True, text=True, timeout=5).stdout.strip()
                proc = ""
                try:
                    import psutil; proc = psutil.Process(int(pid)).name()
                except Exception: pass
                return (title, proc)
        return ("", "")
    except Exception:
        return ("", "")

def list_running_applications():
    """List running processes and windows with name, window title, PID, and memory."""
    import psutil
    apps = []
    pid_titles = {}

    if OS == "win32":
        try:
            import ctypes
            from ctypes import wintypes
            user32 = ctypes.windll.user32

            def enum_cb(hwnd, lparam):
                if user32.IsWindowVisible(hwnd):
                    length = user32.GetWindowTextLengthW(hwnd)
                    if length > 0:
                        buf = ctypes.create_unicode_buffer(length + 1)
                        user32.GetWindowTextW(hwnd, buf, length + 1)
                        t = buf.value.strip()
                        if t:
                            pid = wintypes.DWORD()
                            user32.GetWindowThreadProcessId(hwnd, ctypes.byref(pid))
                            if pid.value and pid.value not in pid_titles:
                                pid_titles[pid.value] = t
                return True

            WNDENUMPROC = ctypes.WINFUNCTYPE(wintypes.BOOL, wintypes.HWND, wintypes.LPARAM)
            user32.EnumWindows(WNDENUMPROC(enum_cb), 0)
        except Exception:
            pass

    sys_procs = {
        "system idle process", "system", "registry", "smss.exe", "csrss.exe",
        "wininit.exe", "services.exe", "lsass.exe", "svchost.exe", "fontdrvhost.exe",
        "winlogon.exe", "dwm.exe", "conhost.exe", "wlanext.exe", "spoolsv.exe"
    }

    seen_names = {}
    for p in psutil.process_iter(['pid', 'name', 'memory_info']):
        try:
            name = p.info['name']
            if not name: continue
            pid = p.info['pid']
            title = pid_titles.get(pid, "")
            mem = round((p.info['memory_info'].rss or 0) / (1024 * 1024), 1) if p.info.get('memory_info') else 0.0
            is_sys = name.lower() in sys_procs or name.lower().startswith("svchost")

            lower = name.lower()
            if lower in seen_names:
                existing = seen_names[lower]
                if not existing["title"] and title:
                    existing["title"] = title
                    existing["pid"] = pid
                    existing["has_window"] = True
                continue

            entry = {
                "name": name,
                "title": title,
                "pid": pid,
                "has_window": bool(title),
                "memory_mb": mem,
                "is_system": is_sys,
            }
            seen_names[lower] = entry
            apps.append(entry)
        except (psutil.NoSuchProcess, psutil.AccessDenied, psutil.ZombieProcess):
            continue
        except Exception:
            continue

    # Sort: apps with windows first, then non-system user apps, then memory usage
    apps.sort(key=lambda x: (not x["has_window"], x["is_system"], -x["memory_mb"]))
    return apps

def open_path(p):
    try:
        if OS == "win32": os.startfile(p)
        elif OS == "darwin": subprocess.Popen(["open", p])
        else: subprocess.Popen(["xdg-open", p])
    except Exception: pass

def mss_instance():
    """mss() is deprecated in newer releases (renamed mss.MSS); support both."""
    import mss
    cls = getattr(mss, "MSS", None) or mss.mss
    return cls()