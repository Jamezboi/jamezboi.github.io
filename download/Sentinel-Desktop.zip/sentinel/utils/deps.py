import importlib, shutil, subprocess, sys

REQUIRED = {"cv2": "opencv-python", "mediapipe": "mediapipe", "numpy": "numpy",
            "mss": "mss", "yaml": "PyYAML", "pyttsx3": "pyttsx3",
            "PIL": "Pillow", "psutil": "psutil",
            "ultralytics": "ultralytics (desk-camera phone detection)"}
OPTIONAL = {"pytesseract": "pytesseract (OCR assist; also needs tesseract binary)",
            "Quartz": "pyobjc-framework-Quartz (macOS window titles)"}

def check():
    rows = []
    for mod, pkg in REQUIRED.items():
        try: importlib.import_module(mod); rows.append((pkg, True, ""))
        except Exception as e: rows.append((pkg, False, str(e)[:60]))
    for mod, pkg in OPTIONAL.items():
        try: importlib.import_module(mod); rows.append((pkg, True, "optional OK"))
        except Exception: rows.append((pkg, False, "optional, missing"))
    return rows

def missing_required():
    return [pkg for mod, pkg in REQUIRED.items() if not _ok(mod)]

def _ok(mod):
    try: importlib.import_module(mod); return True
    except Exception: return False

def auto_install():
    """Install missing required packages via pip. Optional packages are only listed."""
    missing = missing_required()
    if not missing: return True
    print(f"[deps] auto-installing: {', '.join(missing)}")
    r = subprocess.run([sys.executable, "-m", "pip", "install", *missing])
    return r.returncode == 0

def binary_report():
    out = {"tesseract": bool(shutil.which("tesseract")),
           "espeak": bool(shutil.which("espeak") or shutil.which("espeak-ng")),
           "xdotool": bool(shutil.which("xdotool")),
           "afplay/paplay/aplay": any(shutil.which(p) for p in ("afplay", "paplay", "aplay"))}
    return out
