"""Optional local Chrome domain lookup.

Chrome exposes currently open pages only when the user explicitly starts it
with a local remote-debugging port. No extension, cloud service, or history
access is used.
"""
import json
from urllib.parse import urlparse
from urllib.request import urlopen


def active_chrome_domain(title, process, cfg):
    if not cfg.get("browser.chrome_debug_enabled", False):
        return ""
    if "chrome" not in f"{process} {title}".lower():
        return ""
    port = int(cfg.get("browser.chrome_debug_port", 9222))
    try:
        with urlopen(f"http://127.0.0.1:{port}/json", timeout=0.35) as response:
            pages = json.loads(response.read())
        page_title = (title or "").strip().lower()
        candidates = [p for p in pages if p.get("type") == "page" and p.get("url", "").startswith(("http://", "https://"))]
        selected = next((p for p in candidates if p.get("title", "").strip().lower() == page_title), None)
        selected = selected or next((p for p in candidates if page_title and page_title in p.get("title", "").lower()), None)
        if not selected:
            return ""
        return (urlparse(selected["url"]).hostname or "").lower().removeprefix("www.")
    except Exception:
        return ""
