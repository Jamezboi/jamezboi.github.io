"""Pomodoro engine: focus/break cycles. During breaks the entire enforcement
system stands down (arbiter.add_stand_down), score holds, alerts mute."""
import time, threading
from sentinel.core.plugins import SentinelPlugin

class PomodoroPlugin(SentinelPlugin):
    name = "pomodoro"
    def register(self, arbiter):
        c = arbiter.cfg.get("plugins.pomodoro", {})
        self.focus_m, self.break_m = c.get("focus_min", 25), c.get("break_min", 5)
        self.long_m, self.cycles = c.get("long_break_min", 15), c.get("cycles_before_long", 4)
        self.tts = c.get("tts", True)
        self.arbiter = arbiter; self._n = 0
        self._stop = threading.Event()
        threading.Thread(target=self._loop, daemon=True, name="pomodoro").start()
    def _fmt(self, s): return f"{int(s // 60):02d}:{int(s % 60):02d}"
    def _loop(self):
        while not self._stop.wait(1.0):
            self._phase(self.focus_m * 60, "focus")
            self._n += 1
            self.arbiter.audio.chime()
            self.arbiter.ui.toast(f"🍅 Focus block {self._n} done — break time!", "#0ea5e9")
            if self.tts: self.arbiter.audio.speak("Focus block complete. Take your break.")
            self.arbiter.add_stand_down("pomodoro")
            self.arbiter.db.log_event("pomodoro.phase", {"phase": "break"}, source="pomodoro")
            self._phase(self.long_m * 60 if self._n % self.cycles == 0 else self.break_m * 60, "break")
            self.arbiter.remove_stand_down("pomodoro")
            self.arbiter.audio.chime()
            self.arbiter.ui.toast("Break over. Back to work. 📖", "#22c55e")
            if self.tts: self.arbiter.audio.speak("Break's over. Back to work.")
            self.arbiter.db.log_event("pomodoro.phase", {"phase": "focus"}, source="pomodoro")
    def _phase(self, total, kind):
        for left in range(total, 0, -1):
            if self._stop.is_set(): return
            if left % 5 == 0:
                icon = "📖" if kind == "focus" else "☕"
                self.arbiter.ui.set_status_line("pomodoro", f"{icon} {kind} {self._fmt(left)}")
            time.sleep(1)