"""Anti-cheat: detects a frozen/black/covered camera feed (the classic
'cover the webcam' evasion). Sustained blockage → warning + penalty."""
import time, threading
import cv2, numpy as np
from sentinel.core.plugins import SentinelPlugin

class CameraTamperPlugin(SentinelPlugin):
    name = "camera_tamper"
    def register(self, arbiter):
        c = arbiter.cfg.get("plugins.camera_tamper", {})
        self.frozen_s, self.min_diff = c.get("frozen_s", 6), c.get("min_diff", 0.6)
        self.cooldown = c.get("cooldown_s", 60)
        self.arbiter, self._prev, self._still_since, self._last_hit = arbiter, None, None, 0
        self._face_present, self._last_obs_at = False, 0.0
        if arbiter.camera:
            arbiter.camera.add_subscriber(self._on_frame)
        arbiter.bus.subscribe("obs", self._on_obs)

    def _on_obs(self, obs):
        self._face_present = bool((obs or {}).get("face"))
        self._last_obs_at = time.time()

    def _on_frame(self, frame, t, luma):
        small = cv2.resize(frame, (64, 48))
        blocked = luma < 5  # lens covered (black)
        if self._prev is not None:
            diff = float(np.abs(small.astype(int) - self._prev.astype(int)).mean())
            # A genuinely motionless reader can produce near-identical frames.
            # Treat a frozen stream as tampering only when vision has not
            # recently confirmed a live face; black lens detection remains
            # immediate regardless of face state.
            frozen_without_face = (
                diff < self.min_diff
                and (not self._face_present or t - self._last_obs_at > 2.0)
            )
            if frozen_without_face:
                blocked = True
                if self._still_since is None: self._still_since = t
            elif not blocked:
                self._still_since = None
        self._prev = small
        if blocked and self._still_since and t - self._still_since > self.frozen_s \
                and t - self._last_hit > self.cooldown:
            self._last_hit = t
            self.arbiter.ui.toast("📷 Camera blocked or frozen — Sentinel can't verify you.", "#ef4444")
            self.arbiter.apply_penalty(self.arbiter.cfg.get("scoring.per_event.camera_blocked", -10), "camera_blocked")
            self.arbiter.db.log_event("camera.tamper", {"luma": round(luma, 1)}, source="camera_tamper")
