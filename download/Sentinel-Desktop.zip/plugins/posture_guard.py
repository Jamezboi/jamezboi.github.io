"""Posture Guard: baseline-relative slouch detection. Head sinking (face center
y drift) or chin-drop (face bbox shrink) sustained 20s → nudge + penalty, 2-min cooldown."""
import time
from sentinel.core.plugins import SentinelPlugin

class PosturePlugin(SentinelPlugin):
    name = "posture_guard"
    def register(self, arbiter):
        c = arbiter.cfg.get("plugins.posture_guard", {})
        self.dy_t, self.shrink_t = c.get("slouch_dy", 0.07), c.get("shrink_ratio", 0.85)
        self.sus_s, self.cooldown = c.get("sustained_s", 20), c.get("cooldown_s", 120)
        self._base_cy = self._base_h = None; self._slouch_since = None; self._last_nudge = 0
        self.arbiter = arbiter
        arbiter.bus.subscribe("calibration.done", self._on_cal)
        arbiter.bus.subscribe("obs", self._on_obs)
    def _on_cal(self, base):
        s = base.get("screen") or {}
        self._base_cy, self._base_h = s.get("face_cy"), s.get("face_h")
    def _on_obs(self, o):
        b = o.get("bbox")
        if not b or self._base_cy is None: return
        now = time.time()
        cy, h = b[1] + b[3] / 2, b[3]
        slouch = (cy - self._base_cy > self.dy_t) or (h < self._base_h * self.shrink_t)
        if slouch:
            if self._slouch_since is None: self._slouch_since = now
            elif now - self._slouch_since > self.sus_s and now - self._last_nudge > self.cooldown:
                self._last_nudge = now
                self.arbiter.ui.toast("🧍 Sit up straight — shoulders back, chin level.", "#eab308")
                self.arbiter.apply_penalty(self.arbiter.cfg.get("scoring.per_event.slouch_sustained", -5), "slouch_sustained")
                self.arbiter.db.log_event("posture.slouch", {}, source="posture_guard")
        else: self._slouch_since = None