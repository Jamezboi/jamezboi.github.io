"""Drowsiness Sentinel: EAR-based blink/microsleep detection + yawn (MAR).
Microsleep (>1.4s closure) → nudge + config penalty. Chronic blink-rate
elevation → fatigue warning."""
import time
from sentinel.core.plugins import SentinelPlugin

class DrowsinessPlugin(SentinelPlugin):
    name = "drowsiness"
    def register(self, arbiter):
        c = arbiter.cfg.get("plugins.drowsiness", {})
        self.closed_ear = c.get("blink_closed_ear", 0.18)
        self.microsleep_s = c.get("microsleep_s", 1.4)
        self.rate_alert = c.get("blink_rate_alert", 28)
        self.yawn_mar, self.yawn_s = c.get("yawn_mar", 0.62), c.get("yawn_s", 2.0)
        self._closed_since = None; self._warned_micro = 0; self._warned_rate = 0
        self._yawn_since = None
        self._blinks = []
        arbiter.bus.subscribe("obs", self._on_obs)
        self.arbiter = arbiter
    def _on_obs(self, o):
        now = time.time(); ear = o.get("ear")
        if ear is None: return
        if ear < self.closed_ear:
            if self._closed_since is None: self._closed_since = now
            dur = now - self._closed_since
            if dur > self.microsleep_s and now - self._warned_micro > 60:
                self._warned_micro = now
                self.arbiter.ui.toast("😴 Microsleep detected. Stand up, splash water.", "#0ea5e9")
                self.arbiter.apply_penalty(self.arbiter.cfg.get("scoring.per_event.drowsy_microsleep", -5), "drowsy_microsleep")
                self.arbiter.db.log_event("drowsiness.microsleep", {"duration": round(dur, 1)}, source="drowsiness")
        else:
            if self._closed_since is not None:
                if 0.08 < now - self._closed_since < 1.0: self._blinks.append(now)
                self._closed_since = None
        self._blinks = [b for b in self._blinks if now - b < 60]
        if len(self._blinks) >= self.rate_alert and now - self._warned_rate > 300:
            self._warned_rate = now
            self.arbiter.ui.toast(f"😴 {len(self._blinks)} blinks/min — you're getting sleepy.", "#0ea5e9")
            self.arbiter.db.log_event("drowsiness.blink_rate", {"per_min": len(self._blinks)}, source="drowsiness")
            self._blinks = []
        mar = o.get("mar")
        if mar is not None and mar > self.yawn_mar:
            if self._yawn_since is None: self._yawn_since = now
            elif now - self._yawn_since > self.yawn_s and now - self._warned_rate > 120:
                self._warned_rate = now; self._yawn_since = None
                self.arbiter.ui.toast("Yawning — consider a real break (pomodoro will schedule one).", "#0ea5e9")
        else: self._yawn_since = None