"""Streaks: consecutive days meeting the daily study goal. 🔥 on the widget."""
import time, datetime
from sentinel.core.plugins import SentinelPlugin

class StreaksPlugin(SentinelPlugin):
    name = "streaks"
    def register(self, arbiter):
        self.goal = arbiter.cfg.get("plugins.streaks.daily_goal_minutes", 30)
        self.arbiter = arbiter
        arbiter.bus.subscribe("arbiter.snapshot", self._tick)
        self._last = 0
    def _streak(self):
        rows = {r[0]: r[1] for r in self.arbiter.db.daily_rows(400)}
        streak, d = 0, datetime.date.today()
        if rows.get(d.isoformat(), 0) < self.goal * 60: d -= datetime.timedelta(days=1)  # today not done yet
        while rows.get(d.isoformat(), 0) >= self.goal * 60:
            streak += 1; d -= datetime.timedelta(days=1)
        return streak
    def _tick(self, snap):
        now = time.time()
        if now - self._last < 30: return
        self._last = now
        try:
            s = self._streak()
            today = next((r[1] for r in self.arbiter.db.daily_rows(1) if r[0] == datetime.date.today().isoformat()), 0)
            self.arbiter.ui.set_status_line("streaks", f"🔥 {s}-day streak · today {int(today // 60)}m/{self.goal}m")
        except Exception: pass