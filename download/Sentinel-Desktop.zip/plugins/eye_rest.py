"""Eye-strain guard: 20-20-20 rule. Every 20 min, gaze scoring stands down for
20 s while you look at something 20 feet away."""
import time, threading
from sentinel.core.plugins import SentinelPlugin

class EyeRestPlugin(SentinelPlugin):
    name = "eye_rest"
    def register(self, arbiter):
        c = arbiter.cfg.get("plugins.eye_rest", {})
        self.every, self.rest = c.get("every_min", 20) * 60, c.get("rest_s", 20)
        self.arbiter = arbiter
        threading.Thread(target=self._loop, daemon=True, name="eyerest").start()
    def _loop(self):
        while True:
            time.sleep(self.every)
            self.arbiter.ui.toast("👀 Eye break — look 20 feet away for 20 seconds.", "#0ea5e9")
            self.arbiter.add_stand_down("eyerest")
            self.arbiter.db.log_event("eyerest.begin", {}, source="eyerest")
            time.sleep(self.rest)
            self.arbiter.remove_stand_down("eyerest")