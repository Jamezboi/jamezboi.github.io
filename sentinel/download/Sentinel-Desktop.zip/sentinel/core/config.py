import copy, os, yaml
from urllib.parse import urlparse

class ConfigError(Exception): pass

_MIN_DEFAULTS = {
    "scoring": {"start_score": 100, "clamp": [0, 100],
        "per_minute": {"studying_paper": 10, "studying_screen": 8, "neutral_idle": 0,
                        "distracted_screen": -20, "sustained_phone": -15},
        "per_event": {"phone_glance_under_5s": -5, "phone_sustained_over_10s": -25, "left_frame": -30},
        "tiers": {"excellent": 85, "okay": 60, "warning": 40, "critical": 20}}}

def _merge(base, user):
    for k, v in user.items():
        if isinstance(v, dict) and isinstance(base.get(k), dict): _merge(base[k], v)
        else: base[k] = v
    return base

class Config:
    def __init__(self, data): self.data = data
    def get(self, path, default=None):
        cur = self.data
        for p in path.split("."):
            if not isinstance(cur, dict) or p not in cur: return default
            cur = cur[p]
        return cur
    def __repr__(self): return f"Config({self.data!r})"

def _validate(d):
    s = d.get("scoring", {})
    for key in ("start_score", "per_minute", "per_event", "tiers", "clamp"):
        if key not in s: raise ConfigError(f"config.yaml: scoring.{key} is required")
    if not isinstance(s["clamp"], (list, tuple)) or len(s["clamp"]) != 2:
        raise ConfigError("scoring.clamp must contain exactly two numbers")
    lo, hi = s["clamp"]
    if not all(isinstance(v, (int, float)) for v in (lo, hi)):
        raise ConfigError("scoring.clamp values must be numeric")
    if not (0 <= lo < hi <= 1000): raise ConfigError("scoring.clamp must be [low, high], low >= 0")
    t = s["tiers"]
    if not all(k in t and isinstance(t[k], (int, float)) for k in ("critical", "warning", "okay", "excellent")):
        raise ConfigError("scoring.tiers must define numeric critical, warning, okay, and excellent values")
    if not (t["critical"] < t["warning"] < t["okay"] < t["excellent"]):
        raise ConfigError("scoring.tiers must be ordered critical < warning < okay < excellent")
    endpoint = d.get("desktop", {}).get("vision_endpoint", "")
    if endpoint:
        parsed = urlparse(endpoint)
        if parsed.scheme not in ("http", "https") or parsed.hostname not in ("localhost", "127.0.0.1", "::1"):
            raise ConfigError("privacy: desktop.vision_endpoint must be an HTTP endpoint on localhost (or empty)")

def load_config(path="config.yaml"):
    data = copy.deepcopy(_MIN_DEFAULTS)
    if os.path.exists(path):
        with open(path, "r", encoding="utf-8") as f:
            user = yaml.safe_load(f) or {}
        if not isinstance(user, dict): raise ConfigError(f"{path} must be a YAML mapping")
        _merge(data, user)
    else:
        print(f"[config] WARNING: {path} not found — running on built-in defaults.")
    _validate(data)
    return Config(data)
