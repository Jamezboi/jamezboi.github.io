import os, importlib.util, glob

class SentinelPlugin:
    """Standard drop-in interface (spec §7): implement register(arbiter).
    The arbiter hub exposes .bus, .cfg, .db, .ui, .audio, .camera."""
    name = "unnamed"
    def register(self, arbiter): raise NotImplementedError

def load_plugins(arbiter, plugins_dir="plugins", enabled=None):
    """Scan /plugins, import every module, self-register every SentinelPlugin
    subclass whose name is in the enabled list."""
    registered = []
    if not os.path.isdir(plugins_dir): return registered
    for path in sorted(glob.glob(os.path.join(plugins_dir, "*.py"))):
        name = os.path.splitext(os.path.basename(path))[0]
        if name.startswith("_"): continue
        try:
            spec = importlib.util.spec_from_file_location(f"plugins.{name}", path)
            mod = importlib.util.module_from_spec(spec); spec.loader.exec_module(mod)
            for attr in vars(mod).values():
                if (isinstance(attr, type) and issubclass(attr, SentinelPlugin)
                        and attr is not SentinelPlugin and attr.__module__ == mod.__name__):
                    inst = attr()
                    if enabled is not None and inst.name not in (enabled or []): continue
                    inst.register(arbiter)
                    registered.append(inst.name)
        except Exception as e:
            arbiter.db.log_event("plugin.load_error", {"plugin": name, "error": str(e)[:120]})
    return registered