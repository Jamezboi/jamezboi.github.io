import os, html, time, datetime, statistics

STATE_COLORS = {"studying_paper": "#22c55e", "studying_screen": "#4ade80", "neutral_idle": "#64748b",
                "distracted_screen": "#f97316", "sustained_phone": "#ef4444", "absent": "#7c3aed",
                "break": "#0ea5e9"}

def _svg_curve(scores, w=720, h=200):
    if not scores: return "<i>no score changes logged</i>"
    t0 = time.mktime(datetime.datetime.fromisoformat(scores[0][0]).timetuple())
    total = max(time.mktime(datetime.datetime.fromisoformat(scores[-1][0]).timetuple()) - t0, 1)
    pts = " ".join(f"{20 + (time.mktime(datetime.datetime.fromisoformat(s[0]).timetuple()) - t0) / total * (w - 40):.1f},"
                   f"{h - 20 - s[1] / 100 * (h - 40):.1f}" for s in scores)
    bands = "".join(f'<line x1="20" x2="{w - 20}" y1="{h - 20 - v / 100 * (h - 40):.1f}" '
                    f'y2="{h - 20 - v / 100 * (h - 40):.1f}" stroke="{c}" stroke-dasharray="4 4" opacity="0.5"/>'
                    for v, c in ((85, "#22c55e"), (60, "#eab308"), (40, "#f97316"), (20, "#ef4444")))
    return (f'<svg width="{w}" height="{h}">{bands}<polyline points="{pts}" fill="none" '
            f'stroke="#38bdf8" stroke-width="2"/></svg>')

def _svg_timeline(timeline, t_start, t_end, w=720):
    if not timeline: return ""
    total = max(t_end - t_start, 1); parts = []
    for i, (t, state) in enumerate(timeline):
        t2 = timeline[i + 1][0] if i + 1 < len(timeline) else t_end
        x = (t - t_start) / total * w; width = max((t2 - t) / total * w, 1.5)
        parts.append(f'<rect x="{x:.1f}" y="0" width="{width:.1f}" height="18" '
                     f'fill="{STATE_COLORS.get(state, "#334155")}" rx="2"><title>{state}</title></rect>')
    return f'<svg width="{w}" height="18">{"".join(parts)}</svg>'

def _coach(stats, top):
    f = stats["focus_pct"]
    top_s = f" Your biggest leak was “{top[0][0]}” ({top[0][1]} hits)." if top else ""
    if f >= 80: verdict = "Outstanding. You studied like it matters — because it does."
    elif f >= 60: verdict = "Solid session. A few slips, but you kept coming back. That return-muscle IS the skill."
    elif f >= 40: verdict = "Rough one. Your focus fractured under pressure." + top_s + " Next session: close that app before we start."
    else: verdict = "Let’s be honest — the desk lost to the internet today." + top_s + " Tomorrow we run a 15-minute contract and rebuild from there."
    return (f"{verdict} You held focus {f}% of {stats['total_s']/60:.0f} minutes and finished at a score of "
            f"{stats['end_score']}. The Proctor sees you. The Proctor remembers. — PROCTOR-9")

def generate_report(db, stats, cfg, session_id):
    os.makedirs("reports", exist_ok=True)
    scores = db.scores_for(session_id); events = db.events_for(session_id)
    life = db.lifetime_stats(); heat = db.heatmap(14)
    days = sorted({k.split("|")[0] for k in heat}, reverse=True)[:14]
    hm = "<table><tr><td></td>" + "".join(f"<td>{i}</td>" for i in range(24)) + "</tr>"
    for d in days:
        hm += f"<tr><td>{d}</td>" + "".join(
            f'<td style="background:#ef4444;color:#fff;text-align:center">{heat.get(d + "|" + str(i), "")}</td>'
            if heat.get(d + "|" + str(i)) else "<td></td>" for i in range(24)) + "</tr>"
    hm += "</table>"
    ev_rows = "".join(f"<tr><td>{html.escape(str(e[0]))}</td><td>{html.escape(str(e[1]))}</td>"
                      f"<td>{html.escape(str(e[2])[:90])}</td></tr>" for e in events[-120:])
    label = html.escape(cfg.get("session.label", "") or "Study session")
    page = f"""<!doctype html><html><head><meta charset="utf-8"><title>Sentinel report</title>
<style>body{{font-family:system-ui;background:#0e1116;color:#e6e8ec;margin:28px;max-width:820px}}
h1{{font-size:22px}}h2{{font-size:15px;color:#9aa;margin-top:26px}}table{{border-collapse:collapse;font-size:12px}}
td,th{{border:1px solid #232a36;padding:3px 8px}}.card{{background:#161b24;border-radius:10px;padding:16px;margin:8px 0}}</style></head>
<body><h1>Sentinel session report — {label}</h1>
<div class="card"><b>{stats['total_s']/60:.1f} min</b> · focus <b>{stats['focus_pct']}%</b> ·
study {stats['study_s']/60:.1f} min · distracted {stats['distracted_s']/60:.1f} min ·
absent {stats['absent_s']/60:.1f} min · final score <b>{stats['end_score']}</b></div>
<h2>Score curve</h2><div class="card">{_svg_curve(scores)}</div>
<h2>State timeline</h2><div class="card">{_svg_timeline(stats['timeline'], stats['timeline'][0][0] if stats['timeline'] else 0, stats['timeline'][-1][0] if stats['timeline'] else 1)}</div>
<h2>Top distractions</h2><div class="card">{'<br>'.join(f'{html.escape(str(t))} — {n} hits' for t, n in stats['top_distractions']) or 'None. Clean session.'}</div>
<h2>Coach summary</h2><div class="card">{html.escape(_coach(stats, stats['top_distractions']))}</div>
<h2>Distraction heatmap (last 14 days × hour)</h2><div class="card">{hm}</div>
<h2>Lifetime</h2><div class="card">{life['total_sessions']} sessions · {life['study_hours']} h studied ·
{life['distracted_hours']} h distracted · {life['days_active']} active days</div>
<h2>Event log (tail)</h2><table><tr><th>time</th><th>type</th><th>data</th></tr>{ev_rows}</table>
<p style="color:#667">All processing was local. Evidence is saved only for configured confirmed violations. — Sentinel</p></body></html>"""
    path = os.path.abspath(os.path.join("reports", f"session_{session_id}_{datetime.datetime.now().strftime('%Y%m%d_%H%M%S')}.html"))
    with open(path, "w", encoding="utf-8") as f: f.write(page)
    return path
