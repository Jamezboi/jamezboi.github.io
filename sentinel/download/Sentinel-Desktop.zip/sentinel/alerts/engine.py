import time, threading

class AlertEngine:
    """Escalation ladder (spec §6) with hysteresis. Logs every escalation
    and resolution. De-escalates the moment compliance resumes (countdown
    cancels instantly on presence.returned; full step-down after compliance_s)."""
    def __init__(self, arbiter, cfg, audio, ui, db):
        self.arbiter, self.cfg, self.audio, self.ui, self.db = arbiter, cfg, audio, ui, db
        self.level = 0; self.compliance_since = None
        self._cd_thread = None; self._cd_cancel = threading.Event()
        self._cd_lock = threading.RLock(); self._cd_generation = 0
        self._last_desktop = {}
        self._alarm_tts_t = 0
        arbiter.bus.subscribe("presence.returned", self._on_returned)
        arbiter.bus.subscribe("desktop.activity", lambda d: setattr(self, "_last_desktop", d or {}))

    # ---------- escalation ----------
    def on_snapshot(self, snap):
        desired = snap["level"]
        if desired > self.level:
            self._escalate(desired, snap)
        elif desired < self.level:
            if snap["compliant"]:
                if self.compliance_since is None: self.compliance_since = snap["t"]
                if snap["t"] - self.compliance_since >= self.cfg.get("alerts.compliance_s", 5):
                    self._deescalate(desired, snap)
            else:
                self.compliance_since = None
        else:
            self.compliance_since = None if not snap["compliant"] else self.compliance_since
        # keep the alarm voice alive while stuck at tier 4
        if self.level == 4 and time.time() - self._alarm_tts_t > 10:
            self._alarm_tts_t = time.time(); self.audio.speak_proctor()

    def _escalate(self, desired, snap):
        prev = self.level; self.level = desired
        reason = snap.get("hard_reason") or f"score {snap['score']}"
        self.db.log_event("alert.escalate", {"from": prev, "to": desired, "reason": reason})
        if desired == 1:
            self.ui.toast(self.cfg.get("alerts.nudge_message", "Eyes on your paper."), "#f97316")
        elif desired == 2:
            self.audio.chime()
            det = self._last_desktop.get("title", "")
            msg = f"{reason.replace('_', ' ').title()} detected" + (f" — {det[:40]}?" if det and reason == "distracted_screen" else " — studying?")
            self.ui.toast(msg, "#ef4444")
        elif desired == 3:
            self._start_countdown(snap)
        if desired == 4:
            self._cancel_countdown(resolved=False)
            self.audio.alarm_start(); self._alarm_tts_t = time.time()
            self.audio.speak_proctor(); self.ui.alarm_flash(True)
            self.ui.toast("ALARM — return to your desk NOW", "#ef4444")

    def _deescalate(self, desired, snap):
        prev = self.level; self.level = desired
        self.compliance_since = None
        self._cancel_countdown(resolved=True)
        self.audio.alarm_stop(); self.ui.alarm_flash(False)
        self.db.log_event("alert.resolve", {"from": prev, "to": desired, "reason": "compliance resumed"})
        if prev >= 3: self.ui.toast("Good. Studying resumed.", "#22c55e")

    # ---------- countdown (tier 3) ----------
    def _start_countdown(self, snap):
        with self._cd_lock:
            if self._cd_thread and self._cd_thread.is_alive(): return
            self._cd_generation += 1
            generation = self._cd_generation
            self._cd_cancel.clear()
            self._cd_thread = threading.Thread(target=self._countdown, args=(generation,), daemon=True)
            self._cd_thread.start()
    def _countdown(self, generation):
        n = int(self.cfg.get("alerts.countdown_s", 10))
        reason = (self.arbiter.latest or {}).get("hard_reason") or "this behavior"
        wording = {
            "sustained_phone": "use my phone",
            "distracted_screen": "use distracting desktop content",
            "left_frame": "leave my focus area",
            "score_threshold": "let my focus score fall below the limit",
        }.get(reason, reason.replace("_", " "))
        promise = f"I promise not to {wording} again during this session, and to return to my work."
        self.ui.start_countdown("FOCUS REQUIRED", "This notification needs your acknowledgement.", allow_ack=True, promise_text=promise)
        for i in range(n, 0, -1):
            if self._cd_cancel.is_set(): return
            self.ui.update_countdown(i, n)
            self.audio.beep(500 + (n - i + 1) * 60)          # rising pitch each second
            self.arbiter.bus.publish("alert.countdown", {"remaining": i})
            self._cd_cancel.wait(1.0)
            if self._cd_cancel.is_set(): return
        # zero → tier 4.  Cancellation invalidates the generation under the
        # same lock, closing the final-tick acknowledgement race.
        with self._cd_lock:
            if self._cd_cancel.is_set() or generation != self._cd_generation:
                return
            self.level = 3
            self._escalate(4, {"hard_reason": "countdown_expired", "score": self.arbiter.latest.get("score", 0)})
    def _cancel_countdown(self, resolved=True):
        with self._cd_lock:
            self._cd_generation += 1
            active = self._cd_thread and self._cd_thread.is_alive()
            self._cd_cancel.set()
        if active:
            if resolved:
                self.ui.stop_countdown()
                self.db.log_event("alert.countdown_cancelled", {"note": "user returned"})
    def _on_returned(self, d):
        # spec: de-escalate the MOMENT compliant behavior resumes
        if self.level >= 3:
            self._cancel_countdown(resolved=True)

    def acknowledge(self, reason="user_ack"):
        """Cancel the visible countdown after the user acknowledges it.

        Arbiter owns the temporary escalation cap; this method owns the UI and
        timer so an acknowledged countdown cannot still reach the alarm.
        """
        with self._cd_lock:
            previous = self.level
            self._cancel_countdown(resolved=True)
            self.audio.alarm_stop()
            self.ui.alarm_flash(False)
            # Acknowledgement is a temporary nudge-tier cap, not merely a hidden
            # overlay.  Without lowering this internal level the next snapshots
            # could leave Sentinel stuck at tier 3 until full compliance.
            self.level = min(self.level, 1)
            self.compliance_since = None
        self.arbiter.record_promise(reason)
        self.db.log_event("alert.acknowledged", {"from": previous, "to": self.level, "reason": reason})
    def shutdown(self):
        self._cancel_countdown(False); self.audio.alarm_stop()
