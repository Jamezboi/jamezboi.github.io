import sys, subprocess, shutil, os, platform

OS = sys.platform  # 'win32' | 'darwin' | 'linux'
OS_NAME = {"win32": "Windows", "darwin": "macOS", "linux": "Linux"}.get(OS, OS)
IS_WAYLAND = OS == "linux" and (os.environ.get("WAYLAND_DISPLAY") or "wayland" in os.environ.get("XDG_SESSION_TYPE", ""))

def active_window():
    """Return (title, process_name) of the focused window, best-effort per OS."""
    try:
        if OS == "win32":
            import ctypes
            from ctypes import wintypes
            user32 = ctypes.windll.user32
            hwnd = user32.GetForegroundWindow()
            if not hwnd: return ("", "")
            buf = ctypes.create_unicode_buffer(512)
            user32.GetWindowTextW(hwnd, buf, 512)
            pid = ctypes.c_ulong()
            user32.GetWindowThreadProcessId(hwnd, ctypes.byref(pid))
            proc = ""
            try:
                import psutil; proc = psutil.Process(pid.value).name()
            except Exception: pass
            return (buf.value, proc)
        if OS == "darwin":
            try:
                from Quartz import (CGWindowListCopyWindowInfo, kCGWindowListOptionOnScreenOnly,
                                    kCGNullWindowID, kCGWindowLayer, kCGWindowName, kCGWindowOwnerName)
                for w in CGWindowListCopyWindowInfo(kCGWindowListOptionOnScreenOnly, kCGNullWindowID):
                    if w.get(kCGWindowLayer) == 0 and w.get(kCGWindowName):
                        return (w.get(kCGWindowName, ""), w.get(kCGWindowOwnerName, ""))
            except ImportError:
                r = subprocess.run(["osascript", "-e",
                    'tell application "System Events" to get name of first application process whose frontmost is true'],
                    capture_output=True, text=True, timeout=5)
                proc = r.stdout.strip() if r.returncode == 0 else ""
                r2 = subprocess.run(["osascript", "-e",
                    'tell application "System Events" to get name of front window of first application process whose frontmost is true'],
                    capture_output=True, text=True, timeout=5)
                return (r2.stdout.strip() if r2.returncode == 0 else "", proc)
            return ("", "")
        # Linux
        for cmd, args in ((["xdotool", "getactivewindow", "getwindowname"], "title"),
                          (["xdotool", "getactivewindow", "getwindowname"], "title")):
            pass
        if shutil.which("xdotool"):
            wid = subprocess.run(["xdotool", "getactivewindow"], capture_output=True, text=True, timeout=5).stdout.strip()
            if wid:
                title = subprocess.run(["xdotool", "getwindowname", wid], capture_output=True, text=True, timeout=5).stdout.strip()
                pid = subprocess.run(["xdotool", "getwindowpid", wid], capture_output=True, text=True, timeout=5).stdout.strip()
                proc = ""
                try:
                    import psutil; proc = psutil.Process(int(pid)).name()
                except Exception: pass
                return (title, proc)
        return ("", "")
    except Exception:
        return ("", "")

def open_path(p):
    try:
        if OS == "win32": os.startfile(p)
        elif OS == "darwin": subprocess.Popen(["open", p])
        else: subprocess.Popen(["xdg-open", p])
    except Exception: pass

def mss_instance():
    """mss() is deprecated in newer releases (renamed mss.MSS); support both."""
    import mss
    cls = getattr(mss, "MSS", None) or mss.mss
    return cls()