import queue
import threading
import tkinter as tk

TIER_COLORS = {
    "excellent": "#48d597", "okay": "#f6c85f", "warning": "#ff9f43",
    "critical": "#ff5d73", "collapse": "#ff5d73",
}
BG, SURFACE, BORDER, TEXT, MUTED = "#07101f", "#101d31", "#263957", "#f6f8fc", "#a9b8d0"
STATE_ICONS = {
    "studying_paper": "📖",
    "studying_screen": "💻",
    "neutral_idle": "⏸️",
    "distracted_screen": "⚠️",
    "sustained_phone": "📱",
    "absent": "🚪",
    "break": "🍅",
    "UNKNOWN": "❓",
    "UNCALIBRATED": "⚙️",
}


class NullUI:
    """Headless stand-in for simulation/CI. Every method is a no-op."""

    def start_countdown(self, head="", sub="", allow_ack=True, promise_text="I promise to return to my work."):
        pass

    def stop_countdown(self):
        pass

    def update_countdown(self, n, total):
        pass

    def __getattr__(self, _):
        return lambda *a, **k: None


class SentinelUI:
    """Central desktop focus console with work-goal and activity training.

    It intentionally has no live camera preview: desk-camera frames are only
    used transiently for phone detection and violation evidence.
    """

    def __init__(self, cfg):
        self.cfg = cfg
        self.root = tk.Tk()
        self.root.withdraw()
        self.q = queue.Queue()
        self._tkimg = None
        self._flash = False
        self._flash_job = None
        self.on_ack = None
        self.on_recalibrate = None
        self.on_train_activity = None
        self.on_goal = None
        self.on_check_desktop = None
        self.on_train_phone = None
        self._build_widget()
        self.root.after(30, self._drain)

    # ---------- thread bridge ----------
    def schedule(self, fn):
        self.q.put(fn)

    def _drain(self):
        while True:
            try:
                fn = self.q.get_nowait()
            except queue.Empty:
                break
            try:
                fn()
            except Exception:
                pass
        self.root.after(30, self._drain)

    # ---------- widget ----------
    def _build_widget(self):
        w = self.root
        w.title("Sentinel | Focus console")
        w.configure(bg=BG)
        width, height = 1010, 680
        x = max(0, (w.winfo_screenwidth() - width) // 2)
        y = max(0, (w.winfo_screenheight() - height) // 2)
        w.geometry(f"{width}x{height}+{x}+{y}")
        w.minsize(860, 590)
        header = tk.Frame(w, bg="#0d1930", padx=34, pady=23)
        header.pack(fill="x")
        emblem = tk.Canvas(header, width=58, height=58, bg="#0d1930", highlightthickness=0)
        emblem.create_oval(4, 4, 54, 54, fill="#2e63f3", outline="#83a5ff", width=1)
        emblem.create_text(29, 29, text="S", fill="#fff", font=("Segoe UI", 25, "bold"))
        emblem.pack(side="left", padx=(0, 16))
        titles = tk.Frame(header, bg="#0d1930")
        titles.pack(side="left", fill="x", expand=True)
        tk.Label(titles, text="SENTINEL", bg="#0d1930", fg=TEXT, font=("Segoe UI", 24, "bold")).pack(anchor="w")
        tk.Label(titles, text="Private desk monitoring · camera frames never appear in this console", bg="#0d1930", fg="#9fb7ff", font=("Segoe UI", 10)).pack(anchor="w", pady=(2, 0))
        tk.Button(header, text="End session", command=self.close_app, bg="#8f2433", activebackground="#b83043", activeforeground="#fff", fg="#fff", relief="flat", cursor="hand2", padx=18, pady=10, font=("Segoe UI", 10, "bold")).pack(side="right")
        body = tk.Frame(w, bg=BG, padx=34, pady=26)
        body.pack(fill="both", expand=True)
        body.grid_columnconfigure(0, weight=5); body.grid_columnconfigure(1, weight=6); body.grid_rowconfigure(0, weight=1)
        left = tk.Frame(body, bg=SURFACE, padx=26, pady=24, highlightbackground=BORDER, highlightthickness=1)
        left.grid(row=0, column=0, sticky="nsew", padx=(0, 10))
        tk.Label(left, text="FOCUS STATUS", bg=SURFACE, fg=MUTED, font=("Segoe UI", 10, "bold")).pack(anchor="w")
        self.ring = tk.Canvas(
            left, width=218, height=218, bg=SURFACE, highlightthickness=0
        )
        self.ring.pack(pady=(24, 6))
        self.ring.create_oval(18, 18, 200, 200, fill="#0a1629", outline="#263b5d", width=2)
        self._arc = self.ring.create_arc(
            18, 18, 200, 200,
            start=90,
            extent=-359.9,
            style="arc",
            width=13,
            outline="#22c55e",
        )
        self._score_txt = self.ring.create_text(
            109, 100,
            text="100",
            fill=TEXT,
            font=("Segoe UI", 40, "bold"),
        )
        self.ring.create_text(109, 133, text="FOCUS SCORE", fill=MUTED, font=("Segoe UI", 9, "bold"))
        self.icon = tk.Label(
            left, text="●", bg=SURFACE, fg="#48d597", font=("Segoe UI", 16, "bold")
        )
        self.icon.pack()
        self.state = tk.Label(
            left, text="Starting safeguards…", bg=SURFACE, fg=MUTED, font=("Segoe UI", 13, "bold")
        )
        self.state.pack(pady=(2, 18))
        self.line1 = tk.Label(
            left, text="Desk mode is active\nNo face processing · local evidence only", bg="#0a1629", fg=MUTED, font=("Segoe UI", 10), justify="left", anchor="w", padx=16, pady=13, wraplength=350
        )
        self.line1.pack(fill="x", pady=(0, 4))
        right = tk.Frame(body, bg=SURFACE, padx=27, pady=24, highlightbackground=BORDER, highlightthickness=1)
        right.grid(row=0, column=1, sticky="nsew", padx=(10, 0))
        tk.Label(right, text="SESSION PLAN", bg=SURFACE, fg=MUTED, font=("Segoe UI", 10, "bold")).pack(anchor="w")
        tk.Label(right, text="What are you working on?", bg=SURFACE, fg=TEXT, font=("Segoe UI", 18, "bold")).pack(anchor="w", pady=(9, 2))
        tk.Label(right, text="Set one clear outcome so Sentinel can track the session around it.", bg=SURFACE, fg=MUTED, font=("Segoe UI", 10)).pack(anchor="w", pady=(0, 11))
        self.goal_var = tk.StringVar(value=self.cfg.get("session.label", ""))
        goal = tk.Entry(right, textvariable=self.goal_var, bg="#091629", fg=TEXT, insertbackground=TEXT, relief="flat", highlightthickness=1, highlightbackground="#314763", highlightcolor="#5b82ff", font=("Segoe UI", 11))
        goal.pack(fill="x", ipady=10)
        tk.Button(right, text="Save session goal", command=self._save_goal, bg="#3465f4", activebackground="#5480ff", activeforeground="#fff", fg="#fff", relief="flat", cursor="hand2", padx=16, pady=9, font=("Segoe UI", 10, "bold")).pack(anchor="w", pady=(10, 25))
        tk.Label(right, text="TEACH SENTINEL", bg=SURFACE, fg=MUTED, font=("Segoe UI", 10, "bold")).pack(anchor="w")
        tk.Label(right, text="Classify the app that is currently in front. Your choice persists for future sessions.", bg=SURFACE, fg=MUTED, font=("Segoe UI", 10), wraplength=450, justify="left").pack(anchor="w", pady=(6, 11))
        train = tk.Frame(right, bg=SURFACE)
        train.pack(fill="x")
        tk.Button(train, text="✓  Mark as work", command=lambda: self._train("STUDY"), bg="#197a59", activebackground="#249b70", activeforeground="#fff", fg="#fff", relief="flat", cursor="hand2", padx=13, pady=9, font=("Segoe UI", 10, "bold")).pack(side="left", padx=(0, 8))
        tk.Button(train, text="✕  Mark as distraction", command=lambda: self._train("DISTRACTION"), bg="#a44a22", activebackground="#ca6030", activeforeground="#fff", fg="#fff", relief="flat", cursor="hand2", padx=13, pady=9, font=("Segoe UI", 10, "bold")).pack(side="left")
        tk.Button(right, text="Check active desktop app now", command=lambda: self.on_check_desktop and self.on_check_desktop(), bg="#20314d", activebackground="#304869", activeforeground="#fff", fg="#e4ebf8", relief="flat", cursor="hand2", padx=14, pady=8, font=("Segoe UI", 10, "bold")).pack(anchor="w", pady=(13, 22))
        tk.Label(right, text="PHONE CALIBRATION", bg=SURFACE, fg=MUTED, font=("Segoe UI", 10, "bold")).pack(anchor="w")
        tk.Label(right, text="Aim the camera at your desk; label the view to tune phone detection.", bg=SURFACE, fg=MUTED, font=("Segoe UI", 10), wraplength=450, justify="left").pack(anchor="w", pady=(6, 10))
        phone_train = tk.Frame(right, bg=SURFACE)
        phone_train.pack(fill="x")
        tk.Button(phone_train, text="Phone visible", command=lambda: self._train_phone(True), bg="#6747b9", activebackground="#8062d5", activeforeground="#fff", fg="#fff", relief="flat", cursor="hand2", padx=13, pady=8).pack(side="left", padx=(0, 8))
        tk.Button(phone_train, text="Desk is clear", command=lambda: self._train_phone(False), bg="#20314d", activebackground="#304869", activeforeground="#fff", fg="#e4ebf8", relief="flat", cursor="hand2", padx=13, pady=8).pack(side="left")
        self.thumb = None
        w.deiconify()

    def _save_goal(self):
        if self.on_goal:
            self.on_goal(self.goal_var.get())
        self.toast("Work goal saved for this session.", "#22c55e")

    def _train(self, label):
        if self.on_train_activity:
            self.on_train_activity(label)

    def _train_phone(self, is_phone):
        if self.on_train_phone:
            self.on_train_phone(is_phone)

    def _drag_start(self, e):
        self._dx, self._dy = e.x, e.y

    def _drag_motion(self, e):
        self.root.geometry(
            f"+{self.root.winfo_x() + e.x - self._dx}+{self.root.winfo_y() + e.y - self._dy}"
        )

    def bind_arbiter(self, arbiter):
        self._poll_arb = lambda: None

        def poll():
            snap = arbiter.latest
            if snap:
                self.set_snapshot(snap)
            self.root.after(300, poll)

        self.root.after(300, poll)

    def set_snapshot(self, s):
        def f():
            col = TIER_COLORS.get(s["tier"], "#eab308")
            self.ring.itemconfig(
                self._arc, extent=-(s["score"] * 3.6), outline=col
            )
            self.ring.itemconfig(self._score_txt, text=str(int(s["score"])))
            self.icon.config(text=STATE_ICONS.get(s["state"], "❓"))
            self.state.config(
                text=f"{s['tier'].upper()}{' · ' + s['gaze'] if s['gaze'] not in ('UNKNOWN',) else ''}"
                + (" · MUTED" if s["stand_down"] else ""),
                fg=col,
            )

        self.schedule(f)

    def set_thumbnail(self, bgr):
        if not self.thumb:
            return

        def f():
            try:
                import cv2
                from PIL import Image, ImageTk

                small = cv2.resize(bgr, (128, 96))
                img = Image.fromarray(cv2.cvtColor(small, cv2.COLOR_BGR2RGB))
                self._tkimg = ImageTk.PhotoImage(img)
                self.thumb.config(image=self._tkimg)
            except Exception:
                pass

        self.schedule(f)

    def set_status_line(self, slot, text):
        def f():
            self.line1.config(text=text)

        self.schedule(f)

    # ---------- toasts / prompts ----------
    def toast(self, msg, color="#f97316", ms=4000):
        def f():
            t = tk.Toplevel(self.root)
            t.overrideredirect(True)
            t.attributes("-topmost", True)
            try:
                t.attributes("-alpha", 0.92)
            except Exception:
                pass
            t.configure(bg="#17233a")
            frame = tk.Frame(t, bg="#17233a", highlightbackground=color, highlightthickness=2, padx=16, pady=12)
            frame.pack()
            tk.Label(frame, text="SENTINEL", bg="#17233a", fg=color, font=("Segoe UI", 9, "bold")).pack(anchor="w")
            tk.Label(frame, text=msg, bg="#17233a", fg=TEXT, font=("Segoe UI", 11, "bold"), wraplength=360, justify="left").pack(anchor="w", pady=(3, 0))
            t.geometry(f"+{self.root.winfo_x() + 24}+{self.root.winfo_y() + 102}")
            t.after(ms, t.destroy)

        self.schedule(f)

    def show_big(self, title, msg):
        def f():
            if not hasattr(self, "big"):
                self.big = tk.Toplevel(self.root)
                self.big.overrideredirect(True)
                self.big.attributes("-topmost", True)
                self.big.configure(bg="#0b1020")
                self.big_t = tk.Label(
                    self.big,
                    text="",
                    bg="#0b1020",
                    fg="#fff",
                    font=("Segoe UI", 22, "bold"),
                )
                self.big_m = tk.Label(
                    self.big,
                    text="",
                    bg="#0b1020",
                    fg="#bcc",
                    font=("Segoe UI", 13),
                )
            self.big_t.config(text=title)
            self.big_m.config(text=msg)
            self.big_t.pack(pady=(50, 10))
            self.big_m.pack(pady=(0, 50))
            self.big.geometry(
                f"{self.root.winfo_screenwidth()}x220+0+"
                f"{self.root.winfo_screenheight() // 3}"
            )
            self.big.deiconify()

        self.schedule(f)

    def hide_big(self):
        def f():
            if hasattr(self, "big"):
                self.big.withdraw()

        self.schedule(f)

    # ---------- countdown & alarm ----------
    def start_countdown(self, head, sub, allow_ack=True, promise_text="I promise to return to my work."):
        def f():
            if not hasattr(self, "cd"):
                self.cd = tk.Toplevel(self.root)
                self.cd.overrideredirect(True)
                self.cd.attributes("-topmost", True)
                self.cd.configure(bg="#080d18")
                panel = tk.Frame(self.cd, bg="#111c30", highlightbackground="#ff5d73", highlightthickness=2, padx=48, pady=42)
                panel.place(relx=.5, rely=.5, anchor="center", width=650, height=440)
                self.cd_head = tk.Label(
                    panel,
                    text="",
                    bg="#111c30", fg="#ff7689", font=("Segoe UI", 13, "bold"),
                )
                self.cd_n = tk.Label(
                    panel,
                    text="5",
                    bg="#111c30", fg=TEXT, font=("Segoe UI", 72, "bold"),
                )
                self.cd_m = tk.Label(
                    panel,
                    text="",
                    bg="#111c30", fg=MUTED, font=("Segoe UI", 13), wraplength=500, justify="center",
                )
                self.cd_ack_var = tk.IntVar(value=0)
                self.cd_ack = tk.Checkbutton(
                    panel,
                    text="",
                    variable=self.cd_ack_var,
                    command=self._ack_clicked,
                    bg="#111c30", fg=TEXT, selectcolor="#263c61", activebackground="#111c30",
                    activeforeground=TEXT, font=("Segoe UI", 12, "bold"), wraplength=490, justify="left",
                )
                self.cd_head.pack(pady=(0, 14))
                self.cd_n.pack(pady=(0, 3))
                self.cd_m.pack(pady=(0, 22))
            self.cd_head.config(text=head)
            self.cd_m.config(text=sub)
            self.cd_ack.config(text="  " + promise_text + "  ")
            self.cd_ack_var.set(0)
            if allow_ack:
                self.cd_ack.pack(pady=(8, 0), anchor="w")
            else:
                self.cd_ack.pack_forget()
            self.cd.geometry(
                f"{self.root.winfo_screenwidth()}x{self.root.winfo_screenheight()}+0+0"
            )
            self.cd.deiconify()
            self.cd.lift()

        self.schedule(f)

    def _ack_clicked(self):
        # Dismiss window immediately when checked
        self.stop_countdown()
        if self.on_ack:
            try:
                self.on_ack()
            except Exception:
                pass

    def update_countdown(self, n, total):
        def f():
            if hasattr(self, "cd"):
                self.cd_n.config(text=str(n))

        self.schedule(f)

    def stop_countdown(self):
        def f():
            if hasattr(self, "cd"):
                self.cd.withdraw()

        self.schedule(f)

    def alarm_flash(self, on):
        self._flash = on
        if on:
            self._flash_step(True)

    def _flash_step(self, state):
        if not self._flash:
            return

        def f():
            self.root.configure(bg="#ef4444" if state else "#111318")

        self.schedule(f)
        self.root.after(400, lambda: self._flash_step(not state))

    # ---------- lifecycle ----------
    def close_app(self):
        self.root.after(0, self.root.destroy)

    def run(self):
        self.root.mainloop()
