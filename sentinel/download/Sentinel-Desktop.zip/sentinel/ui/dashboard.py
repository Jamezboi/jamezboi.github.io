import collections, json, threading, http.server, socketserver, datetime

_PAGE = """<!doctype html><html><head><meta charset="utf-8"><title>Sentinel Dashboard</title>
<style>body{font-family:system-ui;background:#0e1116;color:#e6e8ec;margin:24px}
h1{font-size:20px}h2{font-size:15px;color:#9aa;margin-top:28px}
.big{font-size:44px;font-weight:700}.card{background:#161b24;border-radius:10px;padding:16px;margin:8px 0}
#ev li{margin:2px 0}table{border-collapse:collapse}td{border:1px solid #232a36;padding:3px 7px;font-size:12px}
.hm{background:#ef4444}</style></head><body>
<h1>SENTINEL — live dashboard</h1>
<div class="card">Score: <span class="big" id="sc">–</span> · tier <b id="ti">–</b> · state <b id="st">–</b> · level <b id="lv">–</b></div>
<h2>Score curve (this session)</h2><div class="card"><svg id="curve" width="720" height="160"></svg></div>
<h2>Recent events</h2><div class="card"><ul id="ev"></ul></div>
<h2>Lifetime</h2><div class="card" id="life">–</div>
<h2>Advanced analysis</h2><div class="card" id="analysis">–</div>
<h2>Distraction heatmap (approx. minutes / hour, last 14 days)</h2><div class="card" id="hm"></div>
<script>async function tick(){try{const s=await (await fetch('/api/stats')).json();
document.getElementById('sc').textContent=s.now.score;document.getElementById('ti').textContent=s.now.tier;
document.getElementById('st').textContent=s.now.state;document.getElementById('lv').textContent=s.now.level;
const c=document.getElementById('curve');let p='';const n=s.scores.length||1;
s.scores.forEach((v,i)=>{const x=10+i*(700/n),y=150-1.3*v[1];p+=(i?'L':'M')+x.toFixed(1)+' '+y.toFixed(1)+' '});
c.innerHTML='<path d="'+p+'" stroke="#22c55e" fill="none" stroke-width="2"/>'; 
document.getElementById('ev').innerHTML=s.events.slice(-25).map(e=>'<li>'+e[0]+' · <b>'+e[1]+'</b> · '+e[2]+'</li>').join('');
document.getElementById('life').innerHTML=Object.entries(s.life).map(([k,v])=>k+': <b>'+v+'</b>').join(' · ');
document.getElementById('analysis').innerHTML='violations: <b>'+s.analysis.violations+'</b> · evidence queued locally: <b>'+s.analysis.evidence_queued+'</b> · trained app rules: <b>'+s.analysis.trained_apps+'</b> · phone calibration samples: <b>'+s.analysis.phone_samples+'</b><br><br><b>Top distraction sources</b><br>'+Object.entries(s.analysis.sources).map(([k,v])=>k+' — '+v+' checks').join('<br>');
let h='<table><tr><td>day\\h</td>';for(let i=0;i<24;i++)h+='<td>'+i+'</td>';h+='</tr>';
for(const d of s.days){h+='<tr><td>'+d+'</td>';for(let i=0;i<24;i++){const v=s.heat[d+'|'+i]||0;
h+='<td class="'+(v>0?'hm':'')+'">'+(v>0?v:'')+'</td>'}h+='</tr>'}
document.getElementById('hm').innerHTML=h+'</table>';}catch(e){}}setInterval(tick,3000);tick();</script>
</body></html>"""

class DashboardServer:
    def __init__(self, db, arbiter, cfg):
        self.db, self.arbiter, cfg = db, arbiter, cfg
        port = int(cfg.get("ui.dashboard_port", 8765))
        db2, arb2 = db, arbiter
        class H(http.server.BaseHTTPRequestHandler):
            def log_message(self, *a): pass
            def do_GET(self):
                if self.path.startswith("/api/stats"):
                    now = getattr(arb2, "latest", None) or {"score": "-", "tier": "-", "state": "-", "level": 0}
                    sid = db2.session_id or db2.latest_session_id()
                    scores = db2.scores_for(sid) if sid else []
                    events = db2.events_for(sid) if sid else []
                    heat = db2.heatmap(14)
                    days = sorted({k.split("|")[0] for k in heat}, reverse=True)[:14]
                    sources, violations = collections.Counter(), 0
                    for _, kind, raw in events:
                        try: data = json.loads(raw or "{}")
                        except Exception: data = {}
                        if kind == "desktop.activity" and data.get("label") == "DISTRACTION":
                            sources[data.get("domain") or data.get("title") or "unknown"] += 1
                        if kind in ("penalty", "phone.sustained", "presence.absent"):
                            violations += 1
                    phone_samples = db2._exec("SELECT COUNT(*) FROM phone_training").fetchone()[0]
                    payload = json.dumps({"now": now,
                        "scores": [[i, s[1]] for i, s in enumerate(scores[-200:])],
                        "events": [[e[0], e[1], (e[2] or "")[:60]] for e in events[-60:]],
                        "life": db2.lifetime_stats(), "heat": heat, "days": days,
                        "analysis": {"violations": violations, "evidence_queued": len(db2.queued_evidence()),
                                     "trained_apps": len(db2.activity_labels()), "phone_samples": phone_samples,
                                     "sources": dict(sources.most_common(8))}}).encode()
                    self.send_response(200); self.send_header("Content-Type", "application/json")
                    self.end_headers(); self.wfile.write(payload)
                else:
                    self.send_response(200); self.send_header("Content-Type", "text/html")
                    self.end_headers(); self.wfile.write(_PAGE.encode())
        self.srv = socketserver.TCPServer(("127.0.0.1", port), H)
        self.srv.daemon_threads = True
        self.thread = threading.Thread(target=self.srv.serve_forever, daemon=True)
    @property
    def url(self): return f"http://127.0.0.1:{self.srv.server_address[1]}"
    def start(self): self.thread.start()
    def stop(self):
        if self.thread.is_alive():
            self.srv.shutdown()
        self.srv.server_close()
