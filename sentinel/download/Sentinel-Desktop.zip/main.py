#!/usr/bin/env python3
"""Sentinel — autonomous study-focus enforcement. One command:
    python main.py                normal session (calibration → sentinels → alerts)
    python main.py --doctor       environment recon & dependency report
    python main.py --fix          auto-install missing required deps
    python main.py --simulate     60 s scripted session, full pipeline, assertions
    python main.py --no-calibrate / --duration 30 / --mute / --nogui
"""
import argparse
import os
import signal
import sys
import time
import webbrowser


def _doctor():
    import platform as pf
    from sentinel.utils import deps, platform

    print(f"OS: {platform.OS_NAME} {pf.release()}  (wayland={platform.IS_WAYLAND})")
    print(f"Python: {sys.version.split()[0]}")
    ok = True
    print("\nDependencies:")
    for pkg, good, note in deps.check():
        print(f"  {'OK ' if good else 'MISSING'} {pkg:38} {note}")
        if not good and pkg in deps.REQUIRED.values():
            ok = False
    print("\nBinaries:", deps.binary_report())

    print("\nMediaPipe:")
    try:
        from sentinel.vision.mp_compat import model_status, probe_mediapipe

        mode, detail = probe_mediapipe()
        print(f"  API: {detail}")
        for name, present in model_status().items():
            print(f"  model {name}: {'present' if present else 'auto-downloads on first run'}")
        if mode == "none":
            ok = False
            print("  -> Vision sentinels cannot run. Reinstall mediapipe or use Python 3.12.")
    except Exception as e:
        ok = False
        print(f"  probe failed: {e}")

    print("\nTTS (voice alerts):")
    try:
        import pyttsx3

        eng = pyttsx3.init()
        n = len(eng.getProperty("voices") or [])
        print(
            f"  OK — {n} system voice(s); alarms will speak"
            if n
            else "  OK but 0 voices found — beep/visual fallback only"
        )
    except Exception as e:
        print(f"  FAILED ({e}) — Tier 4 falls back to repeating tones + visuals")

    print("\nCamera:")
    try:
        import cv2

        cap = cv2.VideoCapture(0)
        r, f = cap.read() if cap.isOpened() else (False, None)
        print(
            f"  index 0: {'OK' if r else 'FAILED to read (busy? permissions?)'}"
            f" shape={None if f is None else f.shape}"
        )
        cap.release()
    except Exception as e:
        print(f"  ERROR: {e}")
        ok = False

    print("\nMonitors:")
    try:
        import warnings
        import mss

        mss_cls = getattr(mss, "MSS", None) or mss.mss
        with warnings.catch_warnings():
            warnings.simplefilter("ignore")
            with mss_cls() as s:
                print(f"  {[m for m in s.monitors]}")
    except Exception as e:
        print(f"  ERROR: {e}")

    print("\nConfig:")
    try:
        from sentinel.core.config import load_config

        load_config("config.yaml")
        print("  config.yaml valid ✓")
    except Exception as e:
        print(f"  INVALID: {e}")
        ok = False

    print(
        "\n"
        + (
            "DOCTOR: PASS"
            if ok
            else "DOCTOR: FAIL — run  python main.py --fix  and check README"
        )
    )
    return 0 if ok else 1


def _wire(args):
    from sentinel.alerts.audio import AudioEngine
    from sentinel.alerts.engine import AlertEngine
    from sentinel.core.arbiter import Arbiter
    from sentinel.core.config import load_config
    from sentinel.core.db import Database
    from sentinel.core.events import EventBus
    from sentinel.ui.overlay import NullUI, SentinelUI

    cfg = load_config("config.yaml")
    if args.mute:
        if hasattr(cfg, "data") and isinstance(cfg.data, dict) and "alerts" in cfg.data:
            cfg.data["alerts"]["mute"] = True
        elif hasattr(cfg, "set"):
            cfg.set("alerts.mute", True)

    bus = EventBus()
    db = Database("sentinel.db")
    bus.on_error = lambda msg: db.log_event("error.handler", {"detail": msg[:300]})
    arbiter = Arbiter(bus, cfg, db)
    ui = NullUI() if getattr(args, "nogui", False) else SentinelUI(cfg)
    if not isinstance(ui, NullUI):
        ui.bind_arbiter(arbiter)

    audio = AudioEngine(cfg, db)
    alerts = AlertEngine(arbiter, cfg, audio, ui, db)
    arbiter.ui, arbiter.audio, arbiter.alerts = ui, audio, alerts

    # Wire user alert acknowledgment button callback
    def handle_ack():
        snooze_s = cfg.get("alerts.ack_snooze_s", 90) if hasattr(cfg, "get") else 90
        if hasattr(arbiter, "snooze_alert"):
            # The arbiter applies snoozes by concrete reason. "user_ack"
            # was never consulted, so acknowledgement previously had no effect.
            reason = (arbiter.latest or {}).get("hard_reason") or "score_critical"
            arbiter.snooze_alert(reason, snooze_s)
        if hasattr(alerts, "acknowledge"):
            alerts.acknowledge(reason)
        elif hasattr(alerts, "ack"):
            alerts.ack()

    ui.on_ack = handle_ack

    def _warn(d, wtype=""):
        try:
            ui.toast("⚠ " + str((d or {}).get("detail") or (d or {}).get("error") or wtype), "#eab308")
            db.log_event(wtype, d or {})
        except Exception:
            pass

    for wtype in (
        "warning.calibration",
        "warning.low_light",
        "warning.multi_face",
        "warning.vision_unavailable",
        "warning.phone_detector_unavailable",
        "camera.failed",
    ):
        bus.subscribe(wtype, lambda d, w=wtype: _warn(d, w))

    return cfg, bus, db, arbiter, ui, audio, alerts


def run_session(args):
    from sentinel.core import report as report_mod
    from sentinel.core.plugins import load_plugins
    from sentinel.sentinels.desktop import DesktopSentinel
    from sentinel.sentinels.gaze import GazeSentinel
    from sentinel.sentinels.phone import PhoneSentinel
    from sentinel.sentinels.presence import PresenceSentinel
    from sentinel.ui.overlay import NullUI
    from sentinel.vision.camera import CameraBus

    cfg, bus, db, arbiter, ui, audio, alerts = _wire(args)

    print("[sentinel] starting — Ctrl+C or widget ✕ to end session")
    camera = CameraBus(cfg, bus)
    camera.start()
    arbiter.camera = camera
    from sentinel.core.evidence import EvidenceCapture
    arbiter.evidence = EvidenceCapture(cfg, db, camera)

    desk_mode = cfg.get("camera.mode", "desk") == "desk"
    pipeline = None
    if desk_mode:
        # Desk mode intentionally does not instantiate MediaPipe, Haar, gaze,
        # presence, posture, or drowsiness code. The camera is only a transient
        # phone detector and any evidence is cropped to the lower desk region.
        db.log_event("privacy.desk_camera_mode", {"face_processing": False}, source="main")
        sentinels = [PhoneSentinel(arbiter), DesktopSentinel(arbiter)]
    else:
        from sentinel.vision.pipeline import VisionPipeline
        pipeline = VisionPipeline(cfg, bus, camera)
        sentinels = [GazeSentinel(arbiter), PhoneSentinel(arbiter), DesktopSentinel(arbiter), PresenceSentinel(arbiter)]
    for s in sentinels:
        s.start()
    arbiter.start()
    plugins = load_plugins(arbiter, "plugins", cfg.get("plugins.enabled"))
    print(f"[sentinel] sentinels: {[s.name for s in sentinels]} · plugins: {plugins}")
    dashboard = None
    if cfg.get("ui.dashboard_autostart", False):
        try:
            from sentinel.ui.dashboard import DashboardServer
            dashboard = DashboardServer(db, arbiter, cfg)
            dashboard.start()
            print(f"[sentinel] analytics dashboard → {dashboard.url}")
        except Exception as exc:
            db.log_event("dashboard.error", {"error": str(exc)[:100]}, source="main")

    desktop = next((s for s in sentinels if s.name == "desktop"), None)
    phone = next((s for s in sentinels if s.name == "phone"), None)
    if not isinstance(ui, NullUI) and desktop:
        def train_activity(label):
            try:
                desktop.train_current(label)
                ui.toast(f"Saved this app as {label.lower()} for future sessions.", "#22c55e")
            except Exception as exc:
                ui.toast(f"Couldn't save training: {str(exc)[:60]}", "#ef4444")
        def set_goal(goal):
            cfg.data.setdefault("session", {})["label"] = goal.strip()
            db.log_event("session.goal", {"goal": goal.strip()}, source="ui")
        ui.on_train_activity = train_activity
        ui.on_goal = set_goal
        ui.on_check_desktop = desktop.run_once
        if phone:
            def train_phone(is_phone):
                try:
                    threshold = phone.train_current(is_phone)
                    ui.toast(f"Phone calibration saved (threshold {threshold:.2f}).", "#22c55e")
                except Exception as exc:
                    ui.toast(f"Couldn't save phone calibration: {str(exc)[:60]}", "#ef4444")
            ui.on_train_phone = train_phone

    if cfg.get("ui.thumbnail", True) and not isinstance(ui, NullUI):
        _last_thumb = [0.0]

        def throttled_thumbnail(frame, t, luma):
            if t - _last_thumb[0] >= 1.0:
                _last_thumb[0] = t
                ui.set_thumbnail(frame)

        camera.add_subscriber(throttled_thumbnail)

    def shutdown(signum=None, frame=None):
        print("\n[sentinel] shutting down…")
        try:
            for s in sentinels:
                s.stop()
            camera.stop()
            arbiter.stop()
            if hasattr(alerts, "shutdown"):
                alerts.shutdown()
            elif hasattr(alerts, "stop"):
                alerts.stop()

            if hasattr(audio, "shutdown"):
                audio.shutdown()
            elif hasattr(audio, "stop"):
                audio.stop()
            if dashboard:
                dashboard.stop()

            if pipeline is not None:
                try:
                    pipeline.close()
                except Exception:
                    pass

            stats = arbiter.finalize()
            if hasattr(db, "upsert_daily"):
                db.upsert_daily(stats.get("study_s", 0), stats.get("distracted_s", 0))

            path = report_mod.generate_report(db, stats, cfg, getattr(db, "session_id", None))
            if hasattr(db, "end_session"):
                db.end_session(path)
            db.close()

            print(f"[sentinel] report → {path}")
            if not isinstance(ui, NullUI):
                try:
                    if os.name == "nt" and os.path.exists(path):
                        os.startfile(path)
                    else:
                        webbrowser.open("file:///" + str(path).replace("\\", "/"))
                except Exception:
                    pass
        except Exception as e:
            print(f"[sentinel] shutdown issue: {e}")
        os._exit(0)

    signal.signal(signal.SIGINT, shutdown)
    signal.signal(signal.SIGTERM, shutdown)

    # ---- duration timer ----
    if getattr(args, "duration", 0) > 0:
        dur_ms = int(args.duration * 60 * 1000)
        if not isinstance(ui, NullUI) and hasattr(ui, "root"):
            ui.root.after(dur_ms, shutdown)
        else:
            import threading

            t = threading.Timer(args.duration * 60, shutdown)
            t.daemon = True
            t.start()

    # ---- calibration ----
    def start_calibration():
        def phase_screen():
            ui.show_big("CALIBRATION", "Sit naturally and look at your SCREEN\n(3 seconds)")
            bus.publish("calibration.phase", {"phase": "screen"})
            if hasattr(ui, "root"):
                ui.root.after(3200, phase_paper)

        def phase_paper():
            ui.show_big("CALIBRATION", "Now look down at your PAPER\n(5 seconds)")
            bus.publish("calibration.phase", {"phase": "paper"})
            if hasattr(ui, "root"):
                ui.root.after(5200, phase_end)

        def phase_end():
            ui.hide_big()
            bus.publish("calibration.phase", {"phase": "end"})
            ui.toast("Calibration complete — Sentinel is watching 📖", "#22c55e")

        if hasattr(ui, "root"):
            ui.root.after(500, phase_screen)

    if not desk_mode and not args.no_calibrate and not isinstance(ui, NullUI):
        start_calibration()
        ui.on_recalibrate = start_calibration
    elif not desk_mode:
        bus.publish("calibration.phase", {"phase": "end"})

    # ---- main loop ----
    if isinstance(ui, NullUI):
        print("[sentinel] headless — Ctrl+C to end session")
        try:
            while True:
                time.sleep(1)
        except KeyboardInterrupt:
            pass
    else:
        try:
            ui.run()
        except KeyboardInterrupt:
            pass

    shutdown()


def run_dashboard():
    """Serve saved Sentinel analytics without starting a camera session."""
    from types import SimpleNamespace
    from sentinel.core.config import load_config
    from sentinel.core.db import Database
    from sentinel.ui.dashboard import DashboardServer
    cfg, db = load_config("config.yaml"), Database("sentinel.db")
    server = DashboardServer(db, SimpleNamespace(latest={}), cfg)
    server.start()
    print(f"[sentinel] dashboard running at {server.url} — Ctrl+C to stop")
    try:
        webbrowser.open(server.url)
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        pass
    finally:
        server.stop()
        db.close()


def main():
    ap = argparse.ArgumentParser(description="Sentinel — study focus enforcement")
    ap.add_argument("--doctor", action="store_true", help="environment recon & report")
    ap.add_argument("--fix", action="store_true", help="auto-install missing required deps")
    ap.add_argument("--simulate", action="store_true", help="60 s scripted session w/ assertions")
    ap.add_argument("--dashboard", action="store_true", help="open the local analytics dashboard without starting a session")
    ap.add_argument("--no-calibrate", action="store_true")
    ap.add_argument("--mute", action="store_true")
    ap.add_argument("--nogui", action="store_true", help="headless (simulation only)")
    ap.add_argument("--duration", type=int, default=0, help="auto-end after N minutes")
    args = ap.parse_args()

    if args.fix:
        from sentinel.utils import deps

        sys.exit(0 if deps.auto_install() else 1)
    if args.doctor:
        sys.exit(_doctor())
    if args.dashboard:
        run_dashboard()
        return
    if args.simulate:
        from tests.simulate_session import run

        sys.exit(run(nogui=args.nogui, mute=args.mute or args.nogui))

    from sentinel.utils import deps

    missing = deps.missing_required()
    if missing:
        print(
            f"[sentinel] missing required deps: {missing}\n"
            f"           run:  python main.py --fix   (or pip install -r requirements.txt)"
        )
        sys.exit(1)

    run_session(args)


if __name__ == "__main__":
    main()
