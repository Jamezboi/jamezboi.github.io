#!/usr/bin/env python3
"""
╔══════════════════════════════════════════════════════════════════════╗
║   AetherScan — Network Intelligence Suite                            ║
║   Discover · Identify · Audit · Monitor                              ║
║                                                                      ║
║   Run:      python main.py                                           ║
║   Dev mode: python main.py --dev          (all premium unlocked)     ║
║   Demo LAN: python main.py --dev --demo   (seeded fake devices)      ║
║   Headless: python main.py --no-browser --scan                       ║
╚══════════════════════════════════════════════════════════════════════╝

AetherScan maps every device on your local network, resolves who made it
and roughly when, fingerprints what it's running, and runs a strictly
NON-INVASIVE security audit (banners, exposure, TLS, headers — never
exploits) so you can fix the weak spots before someone else finds them.

The web console opens at http://127.0.0.1:<port> and is reachable only
from this machine.
"""

from __future__ import annotations

import argparse
import base64
import json
import os
import secrets
import socket
import sys
import threading
import time
import urllib.request
import webbrowser

APP_DIR = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, APP_DIR)

from core import __version__, network  # noqa: E402
from core.devices import DeviceInventory  # noqa: E402
from core.engine import ScanEngine  # noqa: E402
from licensing import LicenseManager  # noqa: E402
from server import app as server_app  # noqa: E402

DEFAULT_UPDATE_URL = "https://jamezboi.github.io/aetherscan/engine/update.json"


def app_base() -> str:
    """Writable per-install directory (data, reports, user config)."""
    if getattr(sys, "frozen", False):            # PyInstaller executable
        return os.path.dirname(os.path.abspath(sys.executable))
    return os.path.dirname(os.path.abspath(__file__))


def resource_base() -> str:
    """Read-only bundled assets (web/ UI)."""
    if getattr(sys, "frozen", False):
        return getattr(sys, "_MEIPASS", app_base())
    return app_base()


DEFAULT_CONFIG = {
    "host": "127.0.0.1",
    "port": 8765,
    "data_dir": "data",
    "reports_dir": "reports",
    "web_root": "web",
    "open_browser": True,
    "online_lookup": False,
    "ping_timeout_ms": 500,
    "sweep_workers": 96,
    "port_timeout_s": 0.6,
    "port_workers": 128,
    "credential_audit": False,
    "license_mode": "production",
    "allow_demo_seed": False,
    "default_profile": "standard",
    "update_url": DEFAULT_UPDATE_URL,
    "license_server": "",
}


def load_config() -> dict:
    config = dict(DEFAULT_CONFIG)
    for path in (os.path.join(app_base(), "config.json"),
                 os.path.join(resource_base(), "config.json")):
        if os.path.exists(path):
            try:
                with open(path, "r", encoding="utf-8") as handle:
                    config.update(json.load(handle))
                break
            except (OSError, ValueError) as exc:
                print(f"[config] Could not parse {path} ({exc}).")
    return config


def banner(dev: bool) -> None:
    dev_tag = "  [DEV BUILD — premium unlocked]" if dev else ""
    print(rf"""
    ╭──────────────────────────────────────────────╮
    │                                              │
    │      ◈  AetherScan  v{__version__}  ·  Lumen     │
    │      Network Intelligence Suite              │{dev_tag}
    │                                              │
    ╰──────────────────────────────────────────────╯
    For auditing networks you own or are authorized to test.
    """)


def pick_port(preferred: int) -> int:
    """Find an open localhost port, starting at the preference."""
    probe = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    try:
        if sys.platform == "win32":
            # SO_REUSEADDR on Windows lets a bind succeed even when another
            # process is actively listening on the port, so two servers could
            # share 8765 and each reject the other's session tokens.
            probe.setsockopt(socket.SOL_SOCKET, socket.SO_EXCLUSIVEADDRUSE, 1)
        else:
            # On POSIX this only reuses TIME_WAIT ports, never live listeners.
            probe.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        probe.bind(("127.0.0.1", preferred))
        probe.close()
        return preferred
    except OSError:
        pass
    finally:
        try:
            probe.close()
        except OSError:
            pass
    # Ask the OS for a free ephemeral port.
    probe = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    try:
        probe.bind(("127.0.0.1", 0))
        return probe.getsockname()[1]
    finally:
        probe.close()


def print_help_text(port: int, token: str) -> None:
    print("  Console :  http://127.0.0.1:%d/?token=%s" % (port, token))
    print("  Token   :  embedded in the URL above (sent as X-Aether-Token")
    print("              by the bundled UI). Localhost-only server.")
    print("  Stop    :  Ctrl+C")
    print()


def version_tuple(version: str):
    return tuple(int(part) for part in version.split(".") if part.isdigit())


def start_update_check(config: dict, result: dict) -> None:
    """Non-blocking update check against the hosted release manifest.
    Mutates `result` in place so readers see the live value."""
    url = config.get("update_url") or DEFAULT_UPDATE_URL
    result.update({"available": False, "latest": "", "current": __version__,
                   "notes_url": "", "checked": False})

    def _work():
        try:
            req = urllib.request.Request(
                url, headers={"User-Agent": f"AetherScan/{__version__}"})
            with urllib.request.urlopen(req, timeout=4.0) as resp:
                manifest = json.loads(resp.read(4096).decode("utf-8"))
            latest = str(manifest.get("latest", "")).strip()
            available = bool(latest) and version_tuple(latest) > version_tuple(__version__)
            result.update({"available": available, "latest": latest,
                           "notes_url": manifest.get("notes_url", ""),
                           "checked": True})
            if available:
                print(f"  ⬆  Update available: v{latest} (you have v{__version__})")
        except Exception:
            result.update({"checked": False})

    threading.Thread(target=_work, daemon=True, name="aetherscan-update").start()


def open_pair_handoff(console_url: str, port: int, token: str) -> None:
    """
    Open the hosted console with pairing credentials in the URL fragment.
    Fragments are never sent to the web server, so the token stays on the
    user's machine; the console reads it, pairs, and strips the fragment.
    """
    payload = base64.urlsafe_b64encode(json.dumps(
        {"base": f"http://127.0.0.1:{port}", "token": token,
         "v": __version__}).encode()).decode().rstrip("=")
    target = f"{console_url}#pair={payload}"
    print(f"  ⇄  Pairing with {console_url} …")
    threading.Timer(0.8, lambda: webbrowser.open(target)).start()


def run_headless_scan(engine: ScanEngine, cidr: str, profile: str) -> None:
    print(f"[scan] Starting {profile} scan of {cidr} …")
    handle = engine.start_scan(cidr=cidr, profile=profile, do_audit=True)
    if not handle.get("ok"):
        print(f"[scan] Could not start: {handle.get('message')}")
        return
    last_phase = ""
    while engine.running:
        progress = engine.progress()
        line = f"  {progress['phase']:<10} {progress['percent']:>3}%  {progress['detail'][:60]}"
        if line != last_phase:
            print(line)
            last_phase = line
        time.sleep(0.4)
    progress = engine.progress()
    if progress["phase"] == "done":
        report = engine.last_report() or {}
        devices = report.get("devices", [])
        print(f"\n[scan] Complete — {len(devices)} devices in {report.get('duration_ms', 0)} ms\n")
        for device in sorted(devices, key=lambda d: d.get("ip", "")):
            ports = ",".join(str(p["port"]) for p in device.get("ports", []))
            print(f"  {device.get('ip',''):<16} {device.get('display_name','')[:28]:<30}"
                  f" {device.get('vendor','')[:24]:<26} {ports}")
    else:
        print(f"[scan] Ended with phase={progress['phase']} error={progress.get('error')}")


def main() -> int:
    # Frozen consoles may pipe stdout as cp1252 — never die on decorative glyphs.
    for stream in (sys.stdout, sys.stderr):
        try:
            stream.reconfigure(errors="replace")
        except (AttributeError, OSError):
            pass

    parser = argparse.ArgumentParser(
        prog="aetherscan",
        description="AetherScan — network discovery, fingerprinting and non-invasive security auditing.")
    parser.add_argument("--dev", action="store_true",
                        help="development mode: unlock all premium features")
    parser.add_argument("--demo", action="store_true",
                        help="seed a realistic demo LAN (development mode only)")
    parser.add_argument("--no-browser", action="store_true",
                        help="don't auto-open the web console")
    parser.add_argument("--scan", action="store_true",
                        help="run one headless scan in the terminal and exit")
    parser.add_argument("--cidr", default=None, help="override target subnet (e.g. 192.168.1.0/24)")
    parser.add_argument("--profile", default=None, choices=["quick", "standard", "deep"],
                        help="port-scan profile for --scan")
    parser.add_argument("--port", type=int, default=None, help="console port")
    parser.add_argument("--pair", default=None, metavar="CONSOLE_URL",
                        help="after startup, open a hosted console and hand it the "
                             "pairing credentials (e.g. https://jamezboi.github.io/aetherscan/console.html)")
    parser.add_argument("--origin", action="append", default=None, metavar="ORIGIN",
                        help="extra web origin allowed to pair with this engine "
                             "(repeatable); adds to pair_origins from config.json")
    parser.add_argument("--version", action="version", version=f"AetherScan {__version__}")
    args = parser.parse_args()

    config = load_config()
    if args.port:
        config["port"] = args.port
    if args.origin:
        origins = list(config.get("pair_origins", []))
        origins.extend(o for o in args.origin if o not in origins)
        config["pair_origins"] = origins
    dev_mode = args.dev or config.get("license_mode") == "development"
    if args.demo:
        dev_mode = True
        config["allow_demo_seed"] = True

    banner(dev_mode)

    base = app_base()
    data_dir = os.path.join(base, config["data_dir"])
    reports_dir = os.path.join(base, config["reports_dir"])
    web_root = (os.path.join(resource_base(), config["web_root"])
                if os.path.isdir(os.path.join(resource_base(), config["web_root"]))
                else os.path.join(base, config["web_root"]))
    os.makedirs(data_dir, exist_ok=True)
    os.makedirs(reports_dir, exist_ok=True)

    licenses = LicenseManager(data_dir=data_dir, dev_mode=dev_mode,
                              license_server=config.get("license_server", ""))
    inventory = DeviceInventory(os.path.join(data_dir, "aetherscan.db"))
    engine = ScanEngine(inventory, license_manager=licenses, config=config)

    if args.demo:
        count = engine.seed_demo_devices()
        print(f"  [demo] Seeded {count} demonstration devices.\n")

    if args.scan:
        interfaces = network.local_interfaces()
        cidr = args.cidr or (interfaces[0].cidr if interfaces else "192.168.1.0/24")
        profile = args.profile or config.get("default_profile", "standard")
        run_headless_scan(engine, cidr, profile)
        return 0

    token = secrets.token_urlsafe(24)
    port = pick_port(int(config["port"]))
    state = server_app.AppState(
        web_root=web_root, engine=engine, inventory=inventory,
        licenses=licenses, config=config, token=token, reports_dir=reports_dir)

    server = server_app.serve(state, host=config.get("host", "127.0.0.1"), port=port)
    print_help_text(port, token)

    state.update_info = {"available": False, "latest": "", "current": __version__,
                         "notes_url": "", "checked": False}
    start_update_check(config, state.update_info)

    url = f"http://127.0.0.1:{port}/?token={token}"
    if args.pair:
        open_pair_handoff(args.pair, port, token)
    elif config.get("open_browser", True) and not args.no_browser:
        threading.Timer(0.6, lambda: webbrowser.open(url)).start()

    license_status = licenses.status()
    if license_status["development"]:
        print("  ⚙  Development build — every premium feature is unlocked for testing.\n")
    elif license_status["trial_active"]:
        print(f"  ✦  Pro trial: {license_status['trial_days_left']} days remaining.\n")

    try:
        server.serve_forever(poll_interval=0.25)
    except KeyboardInterrupt:
        print("\n[aetherscan] Shutting down…")
        if state.monitor:
            state.monitor.stop()
        server.shutdown()
    print("[aetherscan] Goodbye.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
