"""
core/monitor.py — Continuous network watchman.

A background thread re-scans the subnet on an interval and diffs the
result against the inventory, emitting events:
  * device.joined   — a MAC we've never seen (or not seen in `away_grace`)
  * device.left     — a known device went silent
  * device.ip_change— a known MAC moved to a new address (DHCP renewal)
  * device.port_open / device.port_closed — surface changes (deep mode)
  * gateway.change  — the default gateway MAC changed (evil-twin hint)

DEEP mode (premium): every round also
  * probes a set of common TCP ports against hosts that never answered
    ping, so stealthed/quiet devices still show up,
  * port-scans any newly seen or changed host and records port events.

Free/pro mode stays a light presence sweep.
"""

from __future__ import annotations

import concurrent.futures
import socket
import threading
import time
from typing import Callable, Dict, List, Optional

from . import network
from .devices import Device, DeviceInventory

# Ports probed against ping-silent hosts to catch quiet devices.
SILENCE_PROBE_PORTS = (80, 443, 445, 22, 3389, 8080, 5000, 7547, 23, 8009, 631)


def _tcp_open(ip: str, port: int, timeout: float = 0.5) -> bool:
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
            sock.settimeout(timeout)
            return sock.connect_ex((ip, port)) == 0
    except OSError:
        return False


class NetworkMonitor:
    """Periodic sweep + diff engine."""

    def __init__(self, inventory: DeviceInventory, cidr: str,
                 interval_s: int = 60, away_grace_s: int = 300,
                 deep: bool = False,
                 on_event: Optional[Callable[[dict], None]] = None):
        self.inventory = inventory
        self.cidr = cidr
        self.interval_s = max(15, int(interval_s))
        self.away_grace_s = away_grace_s
        self.deep = bool(deep)
        self.on_event = on_event
        self._stop = threading.Event()
        self._thread: Optional[threading.Thread] = None
        self._last_states: Dict[str, dict] = {}
        self._last_ported: set = set()
        self.rounds = 0
        self.status = "stopped"

    # -- lifecycle --------------------------------------------------------------

    def start(self) -> bool:
        if self._thread and self._thread.is_alive():
            return False
        self._stop.clear()
        self.status = "running"
        self._thread = threading.Thread(target=self._loop, daemon=True,
                                        name="aetherscan-monitor")
        self._thread.start()
        return True

    def stop(self) -> None:
        self._stop.set()
        self.status = "stopped"
        if self._thread:
            self._thread.join(timeout=5.0)
            self._thread = None

    @property
    def running(self) -> bool:
        return bool(self._thread and self._thread.is_alive() and not self._stop.is_set())

    def to_dict(self) -> dict:
        return {
            "running": self.running,
            "status": self.status,
            "cidr": self.cidr,
            "interval_s": self.interval_s,
            "deep": self.deep,
            "rounds": self.rounds,
            "tracked": len(self._last_states),
        }

    # -- engine -------------------------------------------------------------------

    def _loop(self) -> None:
        while not self._stop.is_set():
            try:
                self._one_round()
            except Exception as exc:  # never die on a scan hiccup
                self._emit("monitor.error", message=f"Round failed: {exc}")
            self._stop.wait(self.interval_s)

    def _discover(self) -> Dict[str, dict]:
        """Presence sweep; deep mode adds TCP probing for silent hosts."""
        sweep = network.ping_sweep(self.cidr, workers=96, timeout_ms=400)
        arp = sweep.arp_entries
        now = time.time()
        alive_ips = {r.ip for r in sweep.results if r.alive}
        ttl_map = {r.ip: r.ttl for r in sweep.results}

        # Deep: TCP-probe hosts that answered neither ping nor ARP.
        if self.deep:
            try:
                import ipaddress
                net = ipaddress.ip_network(self.cidr, strict=False)
                candidates = [str(h) for h in net.hosts()
                              if str(h) not in alive_ips and str(h) not in arp]
                if candidates:
                    found_extra: List[str] = []

                    def _probe(ip: str) -> Optional[str]:
                        for port in SILENCE_PROBE_PORTS:
                            if _tcp_open(ip, port, 0.45):
                                return ip
                        return None

                    with concurrent.futures.ThreadPoolExecutor(max_workers=128) as pool:
                        for result in pool.map(_probe, candidates):
                            if result:
                                found_extra.append(result)
                    for ip in found_extra:
                        alive_ips.add(ip)
                    if found_extra:
                        self._emit("monitor.deep_find",
                                   message=f"Deep probe found {len(found_extra)} "
                                           f"device(s) that ignore ping",
                                   meta={"ips": found_extra[:20]})
            except Exception:
                pass

        current: Dict[str, dict] = {}
        all_ips = sorted(set(list(arp.keys()) + list(alive_ips)))
        for ip in all_ips:
            if not network.is_scannable_ipv4(ip):
                continue
            mac = arp.get(ip, "")
            key = mac or f"ip:{ip}"
            current[key] = {"ip": ip, "mac": mac, "ts": now, "ttl": ttl_map.get(ip)}
        return current

    def _one_round(self) -> None:
        self.rounds += 1
        current = self._discover()
        now = time.time()

        # --- joins -------------------------------------------------------------
        for key, info in current.items():
            if key in self._last_states:
                continue
            known_before = self.inventory.get(key)
            if known_before is None:
                self._emit("device.joined", ip=info["ip"], mac=info["mac"],
                           message=f"New device on the network: {info['ip']}",
                           meta={"first_time": True})
            else:
                gap = now - (known_before.last_seen or 0)
                if gap > self.away_grace_s:
                    self._emit("device.joined", ip=info["ip"], mac=info["mac"],
                               message=f"{known_before.display_name} is back online",
                               meta={"away_seconds": int(gap)})

        # --- leaves / IP moves ---------------------------------------------------
        for key, prev in self._last_states.items():
            if key in current:
                new_ip = current[key]["ip"]
                if new_ip != prev["ip"]:
                    self._emit("device.ip_change", ip=new_ip, mac=prev["mac"],
                               message=f"Device {prev['mac']} moved {prev['ip']} → {new_ip}",
                               meta={"old_ip": prev["ip"]})
                continue
            device = self.inventory.get(key)
            name = device.display_name if device else prev.get("mac", key)
            self._emit("device.left", ip=prev["ip"], mac=prev.get("mac", ""),
                       message=f"{name} went offline",
                       meta={"last_seen": prev["ts"]})

        self._last_states = current

        # --- deep: track surface changes on known hosts ---------------------------
        if self.deep:
            # Cap per-round port scanning to hosts that are new or not yet ported.
            interesting = [info for key, info in current.items()
                           if key not in getattr(self, "_last_ported", set())]
            self._last_ported = set(current.keys())
            for info in interesting[:8]:
                device = self.inventory.get(info["mac"] or f"ip:{info['ip']}")
                if device is None:
                    continue
                from . import portscan
                scanner = portscan.PortScanner(timeout=0.5, workers=96)
                report = scanner.scan(info["ip"], profile="quick", grab_banners=False)
                open_ports = sorted(p.port for p in report.open_ports)
                previous = sorted(device.open_ports())
                for port in open_ports:
                    if port not in previous:
                        self._emit("device.port_open", ip=info["ip"], mac=device.mac,
                                   message=f"{device.display_name}: port {port} opened",
                                   meta={"port": port})
                for port in previous:
                    if port not in open_ports:
                        self._emit("device.port_closed", ip=info["ip"], mac=device.mac,
                                   message=f"{device.display_name}: port {port} closed",
                                   meta={"port": port})

        # Persist presence so the UI timeline has data even after restart.
        for key, info in current.items():
            device = Device(id=key, ip=info["ip"], mac=info["mac"])
            self.inventory.upsert(device)

    def _emit(self, kind: str, ip: str = "", mac: str = "",
              message: str = "", meta: Optional[dict] = None) -> None:
        event = {"kind": kind, "ip": ip, "mac": mac, "message": message,
                 "meta": meta, "ts": time.time()}
        self.inventory.log_event(kind, message, ip=ip, mac=mac, meta=meta)
        if self.on_event:
            try:
                self.on_event(event)
            except Exception:
                pass
