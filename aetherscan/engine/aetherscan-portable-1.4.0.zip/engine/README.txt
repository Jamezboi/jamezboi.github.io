AetherScan portable engine v1.4.0

Run START-AETHERSCAN.bat or:
  runtime\python.exe engine\main.py --pair "https://jamezboi.github.io/aetherscan/console.html"

Data lives in engine\data. The engine listens on 127.0.0.1 only.
