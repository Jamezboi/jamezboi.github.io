"""
server/app.py — Local-only HTTP server.

Security posture:
  * Binds to 127.0.0.1 only — the console is unreachable from the LAN.
  * Session token: the app mints one per launch and the UI must present it
    (query param on first load, then X-Aether-Token header) for /api calls.
  * Static files are served from web/ with extension allow-listing and
    path-traversal protection.
  * No CORS headers: only the bundled UI talks to the API.

Built on http.server.ThreadingHTTPServer — zero dependencies, solid enough
for a single-operator local tool.
"""

from __future__ import annotations

import json
import mimetypes
import os
import re
import threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from typing import Optional
from urllib.parse import unquote

from . import api as api_routes

_STATIC_TYPES = {
    ".html": "text/html; charset=utf-8",
    ".css": "text/css; charset=utf-8",
    ".js": "application/javascript; charset=utf-8",
    ".svg": "image/svg+xml",
    ".png": "image/png",
    ".jpg": "image/jpeg",
    ".jpeg": "image/jpeg",
    ".webp": "image/webp",
    ".ico": "image/x-icon",
    ".json": "application/json; charset=utf-8",
    ".woff2": "font/woff2",
    ".txt": "text/plain; charset=utf-8",
}


class AppState:
    """Shared context handed to every request handler."""

    # Origins allowed to pair with this engine from a hosted web console.
    # localhost/127.0.0.1 (any port) is always allowed for local development.
    DEFAULT_PAIR_ORIGINS = ["https://jamezboi.github.io"]

    def __init__(self, web_root: str, engine, inventory, licenses,
                 config: dict, token: str, reports_dir: str):
        self.web_root = os.path.abspath(web_root)
        self.engine = engine
        self.inventory = inventory
        self.licenses = licenses
        self.config = config
        self.token = token
        self.reports_dir = reports_dir
        self.monitor = None  # attached by api when monitoring starts
        self.update_info = None  # set by main.start_update_check
        self.started_at = threading.Event()

    def pair_origin_allowed(self, origin: Optional[str]) -> bool:
        if not origin:
            return False
        allow = set(self.DEFAULT_PAIR_ORIGINS)
        allow.update(self.config.get("pair_origins", []))
        if origin in allow:
            return True
        low = origin.lower()
        for prefix in ("http://localhost:", "http://127.0.0.1:",
                       "https://localhost:", "https://127.0.0.1:"):
            if low.startswith(prefix):
                return True
        return False


def make_handler(state: AppState):
    class AetherHandler(BaseHTTPRequestHandler):
        server_version = "AetherScan/1.4"
        protocol_version = "HTTP/1.1"

        # -- plumbing -----------------------------------------------------------

        def log_message(self, fmt, *args):  # quiet console; errors still surface
            pass

        def _cors_headers(self) -> dict:
            """CORS headers for allowed pairing origins (hosted web console)."""
            origin = self.headers.get("Origin")
            if not state.pair_origin_allowed(origin):
                return {}
            headers = {
                "Access-Control-Allow-Origin": origin,
                "Access-Control-Allow-Methods": "GET, POST, DELETE, OPTIONS",
                "Access-Control-Allow-Headers": "Content-Type, X-Aether-Token",
                "Access-Control-Max-Age": "86400",
                "Vary": "Origin",
            }
            if (self.headers.get("Access-Control-Request-Private-Network") or ""
                    ).lower() == "true":
                # Chrome's Private Network Access: public page → local engine.
                headers["Access-Control-Allow-Private-Network"] = "true"
            return headers

        def do_OPTIONS(self):
            cors = self._cors_headers()
            if not cors:
                return self._send_json({"error": "forbidden"}, status=403)
            self.send_response(204)
            for key, value in cors.items():
                self.send_header(key, value)
            self.send_header("Content-Length", "0")
            self.end_headers()

        def _send_json(self, payload, status: int = 200,
                       headers: Optional[dict] = None) -> None:
            body = json.dumps(payload).encode("utf-8")
            self.send_response(status)
            self.send_header("Content-Type", "application/json; charset=utf-8")
            self.send_header("Content-Length", str(len(body)))
            self.send_header("Cache-Control", "no-store")
            for key, value in self._cors_headers().items():
                self.send_header(key, value)
            for key, value in (headers or {}).items():
                self.send_header(key, value)
            self.end_headers()
            self.wfile.write(body)

        def _send_bytes(self, body: bytes, content_type: str,
                        status: int = 200, cache: bool = False) -> None:
            self.send_response(status)
            self.send_header("Content-Type", content_type)
            self.send_header("Content-Length", str(len(body)))
            self.send_header("Cache-Control",
                             "public, max-age=3600" if cache else "no-store")
            for key, value in self._cors_headers().items():
                self.send_header(key, value)
            self.end_headers()
            self.wfile.write(body)

        def _authed(self) -> bool:
            expected = state.token
            provided = (self.headers.get("X-Aether-Token")
                        or self.path_query().get("token") or "")
            return bool(expected) and provided == expected

        def path_query(self) -> dict:
            if "?" not in self.path:
                return {}
            _, _, query = self.path.partition("?")
            out = {}
            for chunk in query.split("&"):
                if "=" in chunk:
                    key, _, value = chunk.partition("=")
                    out[key] = value
            return out

        def read_body(self) -> dict:
            length = int(self.headers.get("Content-Length") or 0)
            if length <= 0 or length > 1_048_576:
                return {}
            try:
                return json.loads(self.rfile.read(length).decode("utf-8"))
            except (ValueError, UnicodeDecodeError):
                return {}

        # -- routing ----------------------------------------------------------------

        def do_GET(self):
            path = unquote(self.path.split("?")[0])
            if path.startswith("/api/"):
                if not self._authed():
                    return self._send_json(
                        {"error": "token_required",
                         "hint": "Launch AetherScan from the terminal so the browser "
                                 "receives a session token, or paste the token printed "
                                 "at startup."}, status=401)
                return api_routes.dispatch(self, "GET", path, state)
            return self._serve_static(path)

        def do_POST(self):
            path = unquote(self.path.split("?")[0])
            if not path.startswith("/api/"):
                return self._send_json({"error": "not_found"}, status=404)
            if not self._authed():
                return self._send_json({"error": "token_required"}, status=401)
            body = self.read_body()
            return api_routes.dispatch(self, "POST", path, state, body=body)

        def do_PUT(self):
            self.do_POST()

        def do_DELETE(self):
            path = unquote(self.path.split("?")[0])
            if not path.startswith("/api/"):
                return self._send_json({"error": "not_found"}, status=404)
            if not self._authed():
                return self._send_json({"error": "token_required"}, status=401)
            return api_routes.dispatch(self, "DELETE", path, state)

        # -- static files -------------------------------------------------------------

        def _serve_static(self, path: str) -> None:
            if path in ("/", "/index.html", ""):
                path = "/index.html"
            relative = os.path.normpath(path.lstrip("/")).replace("\\", "/")
            if relative.startswith(".."):
                return self._send_json({"error": "forbidden"}, status=403)
            full = os.path.join(state.web_root, relative)
            if not os.path.abspath(full).startswith(state.web_root):
                return self._send_json({"error": "forbidden"}, status=403)
            if not os.path.isfile(full):
                # SPA fallback: unknown non-file paths get the shell.
                if "." not in os.path.basename(relative):
                    full = os.path.join(state.web_root, "index.html")
                else:
                    return self._send_json({"error": "not_found"}, status=404)
            ext = os.path.splitext(full)[1].lower()
            if ext not in _STATIC_TYPES:
                return self._send_json({"error": "forbidden"}, status=403)
            try:
                with open(full, "rb") as handle:
                    data = handle.read()
            except OSError:
                return self._send_json({"error": "io_error"}, status=500)
            # Local single-operator tool: always serve fresh assets.
            self._send_bytes(data, _STATIC_TYPES[ext], cache=False)

    return AetherHandler


def serve(state: AppState, host: str = "127.0.0.1", port: int = 8765):
    """Create (but don't start) the ThreadingHTTPServer."""
    handler = make_handler(state)
    server = ThreadingHTTPServer((host, port), handler)
    server.daemon_threads = True
    return server
