"""
core/fingerprint.py — Passive & lightweight-active device identification.

Signals collected (all non-invasive, standard protocols):
  * TTL from ICMP replies          -> rough OS family
  * Reverse DNS                    -> hostname
  * NetBIOS (nbtstat, Windows)     -> Windows machine names
  * mDNS unicast PTR query         -> Bonjour names ("android-xxxx", "Joe's Mac")
  * SSDP / UPnP device description -> manufacturer, model, friendly name
  * HTTP title + Server header     -> product ("NVG589 Web Manager", ...)

Everything degrades gracefully: on a hostile network every single probe
may fail and fingerprint() still returns a usable result.
"""

from __future__ import annotations

import re
import socket
import struct
import subprocess
import sys
import threading
import urllib.request
import xml.etree.ElementTree as ET
from typing import Dict, List, Optional

from .network import IS_WINDOWS, _run

# ---------------------------------------------------------------------------
# TTL -> OS family table (initial TTLs: Windows 128, Linux/BSD/IoT 64,
# macOS/iOS 64, some routers 255/254, Solaris 255)
# ---------------------------------------------------------------------------

_TTL_FAMILIES = [
    (1, 50, "Embedded/IoT firmware (low TTL)"),
    (51, 63, "Linux / iOS / macOS / Android / most IoT"),
    (64, 64, "Linux / macOS / iOS / Android (TTL 64)"),
    (65, 100, "Windows behind a VPN or router chain"),
    (101, 127, "Windows behind one router hop"),
    (128, 128, "Microsoft Windows (TTL 128)"),
    (129, 200, "Windows with tunneling (TTL reduced)"),
    (201, 255, "Legacy router firmware / Solaris (high TTL)"),
]


def os_from_ttl(ttl: Optional[int]) -> str:
    if ttl is None:
        return ""
    for low, high, label in _TTL_FAMILIES:
        if low <= ttl <= high:
            return label
    return f"Unknown (TTL {ttl})"


# ---------------------------------------------------------------------------
# NetBIOS name (Windows hosts)
# ---------------------------------------------------------------------------

_NBT_ROW = re.compile(r"^\s*(\S{1,15})\s+<(\w{2})>\s+(UNIQUE|GROUP)\s+(\w+)",
                      re.IGNORECASE)


def netbios_name(ip: str) -> str:
    """Query the local NetBIOS name table via nbtstat (Windows only)."""
    if not IS_WINDOWS:
        return ""
    out = _run(["nbtstat", "-A", ip], timeout=4.0)
    for line in out.splitlines():
        m = _NBt_row_match(line)
        if m:
            return m
    return ""


def _NBt_row_match(line: str) -> Optional[str]:
    m = _NBT_ROW.match(line)
    if not m:
        return None
    name, suffix, _kind, _flag = m.groups()
    if suffix.upper() in ("00", "03", "20"):  # workstation / messenger / server
        return name.strip()
    return None


# ---------------------------------------------------------------------------
# mDNS reverse lookup (unicast query to 224.0.0.251:5353)
# ---------------------------------------------------------------------------

_MDNS_GROUP = ("224.0.0.251", 5353)


def _encode_qname(name: str) -> bytes:
    out = b""
    for label in name.split("."):
        encoded = label.encode("utf-8")[:63]
        out += bytes([len(encoded)]) + encoded
    return out + b"\x00"


def _read_name(data: bytes, offset: int) -> tuple:
    """Decode a DNS name with compression pointers. Returns (name, next_off)."""
    labels: List[str] = []
    jumps = 0
    next_offset = None
    while True:
        if offset >= len(data):
            break
        length = data[offset]
        if length == 0:
            offset += 1
            if next_offset is None:
                next_offset = offset
            break
        if length & 0xC0 == 0xC0:  # compression pointer
            if offset + 1 >= len(data):
                break
            pointer = ((length & 0x3F) << 8) | data[offset + 1]
            if next_offset is None:
                next_offset = offset + 2
            jumps += 1
            if jumps > 8:
                break
            offset = pointer
            continue
        labels.append(data[offset + 1:offset + 1 + length].decode("utf-8", "replace"))
        offset += 1 + length
    return ".".join(labels), (next_offset or offset)


def mdns_reverse_name(ip: str, timeout: float = 1.0) -> str:
    """
    Ask the mDNS group for the PTR of `<reversed-ip>.in-addr.arpa`.
    Android TVs, Home Assistants, printers and Macs usually answer with
    a friendly name like 'living-room' or 'android-abc123...'.
    """
    parts = ip.split(".")
    qname = ".".join(reversed(parts)) + ".in-addr.arpa"
    query = struct.pack("!HHHH", 0, 0x0000, 1, 0) + _encode_qname(qname) + \
        struct.pack("!HH", 12, 1)  # QTYPE=PTR, QCLASS=IN
    result: Dict[str, str] = {"name": ""}
    sock_holder: List[socket.socket] = []

    def _ask():
        try:
            sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            sock_holder.append(sock)
            sock.settimeout(timeout)
            sock.setsockopt(socket.IPPROTO_IP, socket.IP_MULTICAST_TTL, 4)
            sock.sendto(query, _MDNS_GROUP)
            while True:
                data, _addr = sock.recvfrom(2048)
                name = _parse_mdns_ptr(data)
                if name:
                    result["name"] = name
                    return
        except (OSError, socket.timeout):
            return

    t = threading.Thread(target=_ask, daemon=True)
    t.start()
    t.join(timeout + 0.3)
    if sock_holder:
        try:
            sock_holder[0].close()
        except OSError:
            pass
    return result["name"]


def _parse_mdns_ptr(data: bytes) -> str:
    try:
        qdcount, ancount = struct.unpack("!H", data[4:6])[0], struct.unpack("!H", data[6:8])[0]
    except struct.error:
        return ""
    offset = 12
    for _ in range(qdcount):
        _name, offset = _read_name(data, offset)
        offset += 4
    for _ in range(ancount):
        name, offset = _read_name(data, offset)
        try:
            rtype, _rclass, _ttl, rdlength = struct.unpack("!HHIH", data[offset:offset + 10])
        except struct.error:
            return ""
        offset += 10
        if rtype == 12 and ".in-addr.arpa" in name:  # PTR for our query
            target, _ = _read_name(data, offset)
            candidate = target.split(".local.")[0].split(".")[0]
            if candidate:
                return candidate
        offset += rdlength
    return ""


# ---------------------------------------------------------------------------
# SSDP / UPnP discovery
# ---------------------------------------------------------------------------

_SSDP_MESSAGE = (
    "M-SEARCH * HTTP/1.1\r\n"
    "HOST: 239.255.255.250:1900\r\n"
    'MAN: "ssdp:discover"\r\n'
    "MX: 2\r\n"
    "ST: upnp:rootdevice\r\n"
    "\r\n"
)


def ssdp_discover(timeout: float = 2.5) -> List[dict]:
    """
    Multicast an M-SEARCH and collect UPnP root-device announcements.
    Returns parsed device descriptions (friendlyName, manufacturer, model).
    """
    found: Dict[str, dict] = {}
    lock = threading.Lock()

    def _listen():
        try:
            sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM, socket.IPPROTO_UDP)
            sock.settimeout(timeout)
            sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            sock.bind(("", 0))
            sock.sendto(_SSDP_MESSAGE.encode("ascii"), ("239.255.255.250", 1900))
            deadline = _now() + timeout
            while _now() < deadline:
                try:
                    data, addr = sock.recvfrom(4096)
                except socket.timeout:
                    break
                text = data.decode("utf-8", "replace")
                location = _header_value(text, "LOCATION")
                server = _header_value(text, "SERVER")
                usn = _header_value(text, "USN") or f"{addr[0]}"
                if not location:
                    continue
                key = location or usn
                with lock:
                    if key not in found:
                        found[key] = {"ip": addr[0], "location": location,
                                      "server": server, "description": None}
            sock.close()
        except OSError:
            return

    t = threading.Thread(target=_listen, daemon=True)
    t.start()
    t.join(timeout + 0.5)

    enriched: List[dict] = []
    for entry in found.values():
        description = _fetch_upnp_description(entry["location"])
        merged = {**entry, "description": description}
        enriched.append(merged)
    return enriched


def _now() -> float:
    import time as _t
    return _t.time()


def _header_value(text: str, header: str) -> str:
    for line in text.splitlines():
        if ":" not in line:
            continue
        key, _, value = line.partition(":")
        if key.strip().upper() == header.upper():
            return value.strip()
    return ""


_UPNP_NS = "{urn:schemas-upnp-org:device-1-0}"


def _fetch_upnp_description(location: str) -> Optional[dict]:
    if not location.lower().startswith("http"):
        return None
    try:
        req = urllib.request.Request(location, headers={"User-Agent": "AetherScan/1.4"})
        with urllib.request.urlopen(req, timeout=3.0) as resp:
            body = resp.read(65536)
        root = ET.fromstring(body)
    except Exception:
        return None
    device = root.find(f"{_UPNP_NS}device")
    if device is None:
        return None

    def _tag(name: str) -> str:
        node = device.find(f"{_UPNP_NS}{name}")
        return (node.text or "").strip() if node is not None and node.text else ""

    return {
        "friendly_name": _tag("friendlyName"),
        "manufacturer": _tag("manufacturer"),
        "model_name": _tag("modelName"),
        "model_number": _tag("modelNumber"),
        "model_description": _tag("modelDescription"),
        "serial": _tag("serialNumber"),
        "device_type": _tag("deviceType").rsplit(":", 1)[-1] if _tag("deviceType") else "",
    }


# ---------------------------------------------------------------------------
# HTTP probing (titles, Server headers)
# ---------------------------------------------------------------------------

_TITLE_RE = re.compile(r"<title[^>]*>(.*?)</title>", re.IGNORECASE | re.DOTALL)
_GENERATOR_RE = re.compile(r'<meta[^>]+name=["\']generator["\'][^>]+content=["\']([^"\']+)',
                           re.IGNORECASE)


def probe_http(ip: str, port: int = 80, timeout: float = 2.5,
               use_tls: bool = False, path: str = "/") -> Optional[dict]:
    """
    Fetch one HTTP resource and extract identity signals.
    Returns None when the port isn't speaking HTTP.
    """
    scheme = "https" if use_tls else "http"
    url = f"{scheme}://{ip}:{port}{path}"
    try:
        ctx = None
        if use_tls:
            import ssl as _ssl
            ctx = _ssl.create_default_context()
            ctx.check_hostname = False
            ctx.verify_mode = _ssl.CERT_NONE
        req = urllib.request.Request(
            url, headers={"User-Agent": "AetherScan/1.4 (network inventory)"},
            method="GET")
        with urllib.request.urlopen(req, timeout=timeout, context=ctx) as resp:
            head = resp.read(65536).decode("utf-8", "replace")
            headers = {k.lower(): v for k, v in resp.headers.items()}
            status = resp.status
    except urllib.request.HTTPError as exc:
        # 401/403 still teaches us about the device (admin panel!).
        try:
            headers = {k.lower(): v for k, v in exc.headers.items()}
            head = exc.read(8192).decode("utf-8", "replace")
            status = exc.code
        except Exception:
            return None
    except Exception:
        return None

    title_m = _TITLE_RE.search(head)
    gen_m = _GENERATOR_RE.search(head)
    title = re.sub(r"\s+", " ", title_m.group(1)).strip()[:120] if title_m else ""
    return {
        "url": url,
        "status": status,
        "title": title,
        "server": headers.get("server", ""),
        "generator": gen_m.group(1) if gen_m else "",
        "www_authenticate": headers.get("www-authenticate", ""),
        "content_type": headers.get("content-type", ""),
    }


def detect_admin_panel(ip: str, timeout: float = 2.0) -> Optional[dict]:
    """Probe the handful of paths devices commonly expose admin UIs on."""
    candidates = [(80, False), (443, True), (8080, False), (8443, True), (8008, False)]
    for port, tls in candidates:
        info = probe_http(ip, port=port, timeout=timeout, use_tls=tls)
        if info is None:
            continue
        interesting = bool(info["title"] or info["www_authenticate"] or
                           info["status"] in (200, 401, 403))
        if interesting:
            return {**info, "admin_candidate": info["status"] in (200, 401)}
    return None


# ---------------------------------------------------------------------------
# Composite fingerprint entry point
# ---------------------------------------------------------------------------


def fingerprint(ip: str, ttl: Optional[int] = None,
                deep: bool = True, online: bool = False) -> dict:
    """
    Run the full identification battery for one IP. `deep=False` skips
    mDNS/UPnP/HTTP probes for fast re-scans.
    """
    signals: dict = {
        "ip": ip,
        "ttl": ttl,
        "os_guess": os_from_ttl(ttl),
        "hostname": "",
        "netbios_name": "",
        "mdns_name": "",
        "upnp": None,
        "http": None,
        "admin": None,
    }

    from .network import reverse_dns
    signals["hostname"] = reverse_dns(ip, timeout=1.0) or ""
    if not deep:
        return signals

    threads: List[threading.Thread] = []

    def _spawn(target) -> threading.Thread:
        t = threading.Thread(target=target, daemon=True)
        threads.append(t)
        t.start()
        return t

    _spawn(lambda: signals.__setitem__("netbios_name", netbios_name(ip)))
    _spawn(lambda: signals.__setitem__("mdns_name", mdns_reverse_name(ip)))

    upnp_hits: List[dict] = []

    def _upnp():
        hits = [d for d in ssdp_discover(timeout=2.0) if d.get("ip") == ip]
        if hits:
            upnp_hits.append(hits[0])

    _spawn(_upnp)

    for t in threads:
        t.join(3.5)

    if upnp_hits:
        signals["upnp"] = upnp_hits[0]
    return signals
