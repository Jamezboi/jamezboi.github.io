"""
core/devices.py — Device model, type inference and the persistent inventory.

The inventory is a tiny SQLite store kept next to the app (`data/aetherscan.db`).
It powers: device history ("first seen / last seen"), custom names and tags,
favorites, event log and scan-run statistics.
"""

from __future__ import annotations

import json
import os
import sqlite3
import threading
import time
from dataclasses import dataclass, field, asdict
from typing import Dict, List, Optional

from . import macdb

DB_LOCK = threading.RLock()

_SCHEMA = """
CREATE TABLE IF NOT EXISTS devices (
    id            TEXT PRIMARY KEY,
    ip            TEXT,
    mac           TEXT,
    custom_name   TEXT,
    hostname      TEXT,
    vendor        TEXT,
    vendor_badge  TEXT,
    device_type   TEXT,
    os_guess      TEXT,
    model         TEXT,
    upnp          TEXT,
    mdns_name     TEXT,
    netbios_name  TEXT,
    ports         TEXT,
    favorite      INTEGER DEFAULT 0,
    is_gateway    INTEGER DEFAULT 0,
    tags          TEXT,
    notes         TEXT,
    first_seen    REAL,
    last_seen     REAL,
    seen_count    INTEGER DEFAULT 1
);
CREATE TABLE IF NOT EXISTS events (
    id      INTEGER PRIMARY KEY AUTOINCREMENT,
    ts      REAL,
    kind    TEXT,
    ip      TEXT,
    mac     TEXT,
    message TEXT,
    meta    TEXT
);
CREATE TABLE IF NOT EXISTS scan_runs (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    started_at   REAL,
    finished_at  REAL,
    subnet       TEXT,
    found        INTEGER,
    new_devices  INTEGER,
    duration_ms  INTEGER
);
CREATE INDEX IF NOT EXISTS idx_events_ts ON events(ts DESC);
CREATE INDEX IF NOT EXISTS idx_devices_last_seen ON devices(last_seen DESC);
"""


def _conn(db_path: str) -> sqlite3.Connection:
    os.makedirs(os.path.dirname(db_path), exist_ok=True)
    conn = sqlite3.connect(db_path, check_same_thread=False)
    conn.row_factory = sqlite3.Row
    return conn


# ---------------------------------------------------------------------------
# Device model
# ---------------------------------------------------------------------------


@dataclass
class Device:
    """Everything we know about one network neighbor."""

    id: str = ""                       # canonical key: MAC or fallback IP
    ip: str = ""
    mac: str = ""
    hostname: str = ""
    custom_name: str = ""
    vendor: str = ""
    vendor_badge: str = "unknown"
    device_type: str = "unknown"       # phone|computer|router|iot|tv|printer|console|nas|vm|camera|unknown
    os_guess: str = ""
    model: str = ""
    upnp: str = ""
    mdns_name: str = ""
    netbios_name: str = ""
    ports: List[dict] = field(default_factory=list)
    favorite: bool = False
    tags: List[str] = field(default_factory=list)
    notes: str = ""
    first_seen: float = 0.0
    last_seen: float = 0.0
    seen_count: int = 1
    is_gateway: bool = False
    locally_administered: bool = False
    era: Optional[dict] = None
    vendor_profile: Optional[dict] = None
    latency_ms: Optional[float] = None
    ttl: Optional[int] = None

    # ---- derived -------------------------------------------------------------

    @property
    def display_name(self) -> str:
        return self.custom_name or self.hostname or self.mdns_name or \
            self.netbios_name or self.friendly_default

    @property
    def friendly_default(self) -> str:
        if self.device_type and self.device_type != "unknown":
            label = self.device_type.capitalize()
        else:
            label = "Device"
        if self.vendor:
            base = self.vendor.split(",")[0].split(" (")[0].strip()
            return f"{base} {label}"
        return label

    def open_ports(self) -> List[int]:
        return sorted(p["port"] for p in self.ports if p.get("open"))

    def to_dict(self) -> dict:
        data = asdict(self)
        data["display_name"] = self.display_name
        data["open_port_count"] = len(self.open_ports())
        data["first_seen_iso"] = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(self.first_seen)) if self.first_seen else None
        data["last_seen_iso"] = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(self.last_seen)) if self.last_seen else None
        return data


# ---------------------------------------------------------------------------
# Device-type inference — a tiny expert system combining every signal we have
# ---------------------------------------------------------------------------

_TYPE_BY_HINT = {
    "phone": "phone", "computer": "computer", "router": "router", "iot": "iot",
    "tv": "tv", "printer": "printer", "console": "console", "nas": "nas",
    "vm": "vm", "camera": "camera",
}

_TYPE_BY_PORT = {
    7547: "router", 53: "router", 5000: "router", 1900: "router",
    445: "computer", 3389: "computer", 5900: "computer",
    9100: "printer", 631: "printer", 515: "printer",
    5001: "nas", 8080: "iot", 8123: "iot", 1883: "iot", 8883: "iot",
    2883: "iot", 51826: "iot", 8443: "iot",
    32400: "nas", 5005: "tv", 8006: "tv", 1935: "tv",
}

_HOSTNAME_HINTS = (
    ("iphone", "phone"), ("ipad", "phone"), ("galaxy", "phone"), ("pixel", "phone"),
    ("android", "phone"), ("samsung", "phone"), ("xiaomi", "phone"), ("redmi", "phone"),
    ("huawei", "phone"), ("oppo", "phone"), ("macbook", "computer"), ("imac", "computer"),
    ("desktop", "computer"), ("laptop", "computer"), ("-pc", "computer"), ("thinkpad", "computer"),
    ("nas", "nas"), ("synology", "nas"), ("qnap", "nas"), ("raspberrypi", "computer"),
    ("chromecast", "tv"), ("apple-tv", "tv"), ("appletv", "tv"), ("roku", "tv"),
    ("firetv", "tv"), ("smart-tv", "tv"), ("printer", "printer"), ("brother", "printer"),
    ("hp-", "printer"), ("echo", "iot"), ("nest", "iot"), ("hue", "iot"),
    ("home", "iot"), ("bridge", "iot"), ("shield", "console"), ("xbox", "console"),
    ("playstation", "console"), ("ps5", "console"), ("ps4", "console"), ("switch", "console"),
    ("switch-", "router"), ("tplink", "router"), ("mi-", "phone"), ("camera", "camera"),
    ("cam-", "camera"), ("nvr", "camera"), ("doorbell", "camera"),
)


def infer_device_type(device: Device, gateway_ip: Optional[str] = None) -> str:
    """Combine hostname, ports, vendor class-hint and gateway status."""
    if gateway_ip and device.ip == gateway_ip:
        return "router"
    blob = " ".join([device.hostname, device.mdns_name, device.netbios_name,
                     device.custom_name, device.model]).lower()
    for needle, kind in _HOSTNAME_HINTS:
        if needle in blob:
            return kind
    for p in device.ports:
        if p.get("open") and p["port"] in _TYPE_BY_PORT:
            kind = _TYPE_BY_PORT[p["port"]]
            if kind != "router" or device.device_type == "unknown":
                return kind
    hint = macdb.lookup_class_hint(device.mac) if device.mac else None
    if hint and hint in _TYPE_BY_HINT:
        return _TYPE_BY_HINT[hint]
    badge = (device.vendor_badge or "").lower()
    badge_types = {
        "vmware": "vm", "virtualbox": "vm", "parallels": "vm",
        "sonos": "iot", "philips": "iot", "tuya": "iot", "broadlink": "iot",
        "espressif": "iot", "arduino": "iot", "nest": "iot",
        "synology": "nas", "qnap": "nas", "western-digital": "nas",
        "brother": "printer", "epson": "printer",
        "sony": "console", "nintendo": "console", "lg": "tv",
        "dell": "computer", "lenovo": "computer", "intel": "computer",
        "raspberry": "computer",
    }
    if badge in badge_types:
        return badge_types[badge]
    return device.device_type or "unknown"


# ---------------------------------------------------------------------------
# Inventory (SQLite-backed)
# ---------------------------------------------------------------------------


class DeviceInventory:
    """Thread-safe persistent store for devices and events."""

    def __init__(self, db_path: str):
        self.db_path = db_path
        self._conn = _conn(db_path)
        with DB_LOCK:
            self._conn.executescript(_SCHEMA)
            self._migrate()
            self._conn.commit()

    def _migrate(self) -> None:
        """Add columns that older installs may be missing (idempotent)."""
        cols = {r["name"] for r in self._conn.execute("PRAGMA table_info(devices)")}
        if "is_gateway" not in cols:
            self._conn.execute("ALTER TABLE devices ADD COLUMN is_gateway INTEGER DEFAULT 0")

    # -- devices ---------------------------------------------------------------

    def upsert(self, device: Device) -> bool:
        """
        Insert or refresh a device. Returns True when this call created a
        brand-new device (used for 'new device joined' alerts).
        """
        if not device.id:
            device.id = device.mac or f"ip:{device.ip}"
        now = time.time()
        with DB_LOCK:
            row = self._conn.execute(
                "SELECT id, first_seen, seen_count, ports, notes, tags, custom_name, "
                "favorite, is_gateway FROM devices WHERE id = ?", (device.id,)).fetchone()
            is_new = row is None
            if is_new:
                device.first_seen = now
                device.last_seen = now
            else:
                device.first_seen = row["first_seen"] or now
                device.last_seen = now
                device.seen_count = (row["seen_count"] or 1) + 1
                if not device.custom_name and row["custom_name"]:
                    device.custom_name = row["custom_name"]
                if not device.notes and row["notes"]:
                    device.notes = row["notes"]
                if not device.favorite and row["favorite"]:
                    device.favorite = bool(row["favorite"])
                if not device.tags and row["tags"]:
                    try:
                        device.tags = json.loads(row["tags"])
                    except json.JSONDecodeError:
                        device.tags = []
                if not device.ports and row["ports"]:
                    try:
                        device.ports = json.loads(row["ports"])
                    except json.JSONDecodeError:
                        device.ports = []
                if not device.is_gateway and row["is_gateway"]:
                    device.is_gateway = bool(row["is_gateway"])
            self._conn.execute(
                """INSERT INTO devices (id, ip, mac, custom_name, hostname, vendor, vendor_badge,
                     device_type, os_guess, model, upnp, mdns_name, netbios_name, ports,
                     favorite, is_gateway, tags, notes, first_seen, last_seen, seen_count)
                   VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
                   ON CONFLICT(id) DO UPDATE SET
                     ip=excluded.ip, mac=excluded.mac, hostname=excluded.hostname,
                     vendor=excluded.vendor, vendor_badge=excluded.vendor_badge,
                     device_type=excluded.device_type, os_guess=excluded.os_guess,
                     model=excluded.model, upnp=excluded.upnp, mdns_name=excluded.mdns_name,
                     netbios_name=excluded.netbios_name, ports=excluded.ports,
                     favorite=excluded.favorite, is_gateway=excluded.is_gateway,
                     tags=excluded.tags, notes=excluded.notes,
                     last_seen=excluded.last_seen, seen_count=excluded.seen_count""",
                (device.id, device.ip, device.mac, device.custom_name, device.hostname,
                 device.vendor, device.vendor_badge, device.device_type, device.os_guess,
                 device.model, device.upnp, device.mdns_name, device.netbios_name,
                 json.dumps(device.ports), int(device.favorite), int(device.is_gateway),
                 json.dumps(device.tags), device.notes, device.first_seen,
                 device.last_seen, device.seen_count))
            self._conn.commit()
        return is_new

    def all_devices(self) -> List[Device]:
        with DB_LOCK:
            rows = self._conn.execute(
                "SELECT * FROM devices ORDER BY last_seen DESC").fetchall()
        return [self._row_to_device(r) for r in rows]

    def get(self, device_id: str) -> Optional[Device]:
        with DB_LOCK:
            row = self._conn.execute(
                "SELECT * FROM devices WHERE id = ?", (device_id,)).fetchone()
        return self._row_to_device(row) if row else None

    def update_fields(self, device_id: str, **fields) -> bool:
        allowed = {"custom_name", "notes", "favorite", "tags", "ports", "device_type"}
        keys = [k for k in fields if k in allowed]
        if not keys:
            return False
        sets = []
        values: List = []
        for key in keys:
            value = fields[key]
            if isinstance(value, (list, bool)):
                value = json.dumps(value) if isinstance(value, list) else int(value)
            sets.append(f"{key} = ?")
            values.append(value)
        values.append(device_id)
        with DB_LOCK:
            self._conn.execute(
                f"UPDATE devices SET {', '.join(sets)} WHERE id = ?", values)
            self._conn.commit()
        return True

    def delete(self, device_id: str) -> None:
        with DB_LOCK:
            self._conn.execute("DELETE FROM devices WHERE id = ?", (device_id,))
            self._conn.commit()

    # -- events ----------------------------------------------------------------

    def log_event(self, kind: str, message: str, ip: str = "",
                  mac: str = "", meta: Optional[dict] = None) -> None:
        with DB_LOCK:
            self._conn.execute(
                "INSERT INTO events (ts, kind, ip, mac, message, meta) VALUES (?,?,?,?,?,?)",
                (time.time(), kind, ip, mac, message,
                 json.dumps(meta) if meta else None))
            self._conn.commit()

    def events(self, limit: int = 100) -> List[dict]:
        with DB_LOCK:
            rows = self._conn.execute(
                "SELECT * FROM events ORDER BY ts DESC LIMIT ?", (limit,)).fetchall()
        out = []
        for r in rows:
            item = dict(r)
            item["iso"] = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(item["ts"]))
            try:
                item["meta"] = json.loads(item["meta"]) if item["meta"] else None
            except json.JSONDecodeError:
                item["meta"] = None
            out.append(item)
        return out

    # -- scan runs -------------------------------------------------------------

    def log_scan_run(self, subnet: str, found: int, new_devices: int,
                     duration_ms: int) -> int:
        with DB_LOCK:
            cur = self._conn.execute(
                "INSERT INTO scan_runs (started_at, finished_at, subnet, found, new_devices, duration_ms) "
                "VALUES (?,?,?,?,?,?)",
                (time.time() - duration_ms / 1000.0, time.time(), subnet, found,
                 new_devices, duration_ms))
            self._conn.commit()
            return cur.lastrowid

    def scan_history(self, limit: int = 50) -> List[dict]:
        with DB_LOCK:
            rows = self._conn.execute(
                "SELECT * FROM scan_runs ORDER BY started_at DESC LIMIT ?", (limit,)).fetchall()
        out = []
        for r in rows:
            item = dict(r)
            item["started_iso"] = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(item["started_at"]))
            out.append(item)
        return out

    def stats(self) -> dict:
        with DB_LOCK:
            dev_count = self._conn.execute("SELECT COUNT(*) FROM devices").fetchone()[0]
            run_count = self._conn.execute("SELECT COUNT(*) FROM scan_runs").fetchone()[0]
            type_rows = self._conn.execute(
                "SELECT device_type, COUNT(*) AS n FROM devices GROUP BY device_type").fetchall()
        return {
            "devices": dev_count,
            "scan_runs": run_count,
            "by_type": {r["device_type"] or "unknown": r["n"] for r in type_rows},
        }

    # -- internals ---------------------------------------------------------------

    @staticmethod
    def _row_to_device(row: sqlite3.Row) -> Device:
        try:
            ports = json.loads(row["ports"]) if row["ports"] else []
        except json.JSONDecodeError:
            ports = []
        try:
            tags = json.loads(row["tags"]) if row["tags"] else []
        except json.JSONDecodeError:
            tags = []
        return Device(
            id=row["id"], ip=row["ip"] or "", mac=row["mac"] or "",
            custom_name=row["custom_name"] or "", hostname=row["hostname"] or "",
            vendor=row["vendor"] or "", vendor_badge=row["vendor_badge"] or "unknown",
            device_type=row["device_type"] or "unknown", os_guess=row["os_guess"] or "",
            model=row["model"] or "", upnp=row["upnp"] or "",
            mdns_name=row["mdns_name"] or "", netbios_name=row["netbios_name"] or "",
            ports=ports, favorite=bool(row["favorite"]), tags=tags,
            is_gateway=bool(row["is_gateway"]),
            notes=row["notes"] or "", first_seen=row["first_seen"] or 0.0,
            last_seen=row["last_seen"] or 0.0, seen_count=row["seen_count"] or 1,
        )
