"""
core/monitor.py — Continuous network watchman.

A background thread re-scans the subnet on an interval and diffs the
result against the inventory, emitting events:
  * device.joined   — a MAC we've never seen (or not seen in `away_grace`)
  * device.left     — a known device went silent
  * device.ip_change— a known MAC moved to a new address (DHCP renewal)
  * gateway.change  — the default gateway MAC changed (evil-twin hint)

Premium feature. Free tier gets a 10-minute demo window.
"""

from __future__ import annotations

import threading
import time
from typing import Callable, Dict, List, Optional

from . import network
from .devices import Device, DeviceInventory


class NetworkMonitor:
    """Periodic sweep + diff engine."""

    def __init__(self, inventory: DeviceInventory, cidr: str,
                 interval_s: int = 60, away_grace_s: int = 300,
                 on_event: Optional[Callable[[dict], None]] = None):
        self.inventory = inventory
        self.cidr = cidr
        self.interval_s = max(15, int(interval_s))
        self.away_grace_s = away_grace_s
        self.on_event = on_event
        self._stop = threading.Event()
        self._thread: Optional[threading.Thread] = None
        self._last_states: Dict[str, dict] = {}
        self.rounds = 0
        self.status = "stopped"

    # -- lifecycle --------------------------------------------------------------

    def start(self) -> bool:
        if self._thread and self._thread.is_alive():
            return False
        self._stop.clear()
        self.status = "running"
        self._thread = threading.Thread(target=self._loop, daemon=True,
                                        name="aetherscan-monitor")
        self._thread.start()
        return True

    def stop(self) -> None:
        self._stop.set()
        self.status = "stopped"
        if self._thread:
            self._thread.join(timeout=3.0)
            self._thread = None

    @property
    def running(self) -> bool:
        return bool(self._thread and self._thread.is_alive() and not self._stop.is_set())

    def to_dict(self) -> dict:
        return {
            "running": self.running,
            "status": self.status,
            "cidr": self.cidr,
            "interval_s": self.interval_s,
            "rounds": self.rounds,
            "tracked": len(self._last_states),
        }

    # -- engine -------------------------------------------------------------------

    def _loop(self) -> None:
        while not self._stop.is_set():
            try:
                self._one_round()
            except Exception as exc:  # never die on a scan hiccup
                self._emit("monitor.error", message=f"Round failed: {exc}")
            self._stop.wait(self.interval_s)

    def _one_round(self) -> None:
        self.rounds += 1
        sweep = network.ping_sweep(self.cidr, workers=96, timeout_ms=400)
        arp = sweep.arp_entries
        now = time.time()
        current: Dict[str, dict] = {}

        for ip, mac in arp.items():
            if not network.is_scannable_ipv4(ip):
                continue
            key = mac or f"ip:{ip}"
            current[key] = {"ip": ip, "mac": mac, "ts": now}

        # --- joins -------------------------------------------------------------
        for key, info in current.items():
            if key not in self._last_states:
                known_before = self.inventory.get(key)
                if known_before is None:
                    self._emit("device.joined", ip=info["ip"], mac=info["mac"],
                               message=f"New device on the network: {info['ip']}",
                               meta={"first_time": True})
                else:
                    gap = now - (known_before.last_seen or 0)
                    if gap > self.away_grace_s:
                        self._emit("device.joined", ip=info["ip"], mac=info["mac"],
                                   message=f"{known_before.display_name} is back online",
                                   meta={"away_seconds": int(gap)})

        # --- leaves / IP moves ---------------------------------------------------
        for key, prev in self._last_states.items():
            if key in current:
                new_ip = current[key]["ip"]
                if new_ip != prev["ip"]:
                    self._emit("device.ip_change", ip=new_ip, mac=prev["mac"],
                               message=f"Device {prev['mac']} moved {prev['ip']} → {new_ip}",
                               meta={"old_ip": prev["ip"]})
                continue
            device = self.inventory.get(key)
            name = device.display_name if device else prev.get("mac", key)
            self._emit("device.left", ip=prev["ip"], mac=prev.get("mac", ""),
                       message=f"{name} went offline",
                       meta={"last_seen": prev["ts"]})

        self._last_states = current

        # Persist presence so the UI timeline has data even after restart.
        for key, info in current.items():
            device = Device(id=key, ip=info["ip"], mac=info["mac"])
            self.inventory.upsert(device)

    def _emit(self, kind: str, ip: str = "", mac: str = "",
              message: str = "", meta: Optional[dict] = None) -> None:
        event = {"kind": kind, "ip": ip, "mac": mac, "message": message,
                 "meta": meta, "ts": time.time()}
        self.inventory.log_event(kind, message, ip=ip, mac=mac, meta=meta)
        if self.on_event:
            try:
                self.on_event(event)
            except Exception:
                pass
