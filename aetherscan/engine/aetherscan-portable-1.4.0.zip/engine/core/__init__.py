"""
AetherScan — Network Intelligence Suite
========================================

Core package: discovery, fingerprinting, security auditing, monitoring
and reporting for small private networks (home / lab / small office).

Everything in this package runs on the Python standard library only —
no third-party dependencies are required to run AetherScan.

Legal notice:
    AetherScan is intended for auditing networks that YOU own or that
    you have explicit written authorization to test. Scanning networks
    without permission may be illegal in your jurisdiction.
"""

__app_name__ = "AetherScan"
__app_codename__ = "Lumen"
__version__ = "1.4.0"
__build__ = 1400
__author__ = "AetherScan Labs"
__copyright__ = "© 2026 AetherScan Labs. All rights reserved."
