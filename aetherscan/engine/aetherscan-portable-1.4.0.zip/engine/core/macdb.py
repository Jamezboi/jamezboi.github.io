"""
core/macdb.py — MAC address vendor intelligence.

Three layers of lookup, fastest first:
  1. EMBEDDED_OUI — a curated, offline IEEE OUI registry covering the
     vendors most commonly found on home / small-office networks.
  2. Online lookup (optional, opt-in) against the public macvendors.com
     API for prefixes missing from the embedded set.
  3. Heuristics — locally-administered MACs (randomized phone MACs) are
     detected and labeled.

Also provides `estimate_device_era()`: IEEE publishes the date each OUI
block was assigned; a device can never be older than that assignment, so
we surface an honest "OUI registered YYYY" manufacturing-era estimate.
"""

from __future__ import annotations

import re
import threading
import urllib.request
from typing import Dict, Optional, Tuple

# ---------------------------------------------------------------------------
# Embedded OUI registry  (prefix -> (vendor, device-class-hint))
# device-class-hints: phone|computer|router|iot|tv|printer|console|nas|vm|camera
# ---------------------------------------------------------------------------

EMBEDDED_OUI: Dict[str, Tuple[str, str]] = {
    # --- Apple ---
    "ac:de:48": ("Apple, Inc.", "phone"), "00:1b:63": ("Apple, Inc.", "computer"),
    "f0:18:98": ("Apple, Inc.", "phone"), "14:99:e2": ("Apple, Inc.", "tv"),
    "3c:15:c2": ("Apple, Inc.", "computer"), "98:01:a7": ("Apple, Inc.", "phone"),
    "a4:5e:60": ("Apple, Inc.", "computer"), "f8:1e:df": ("Apple, Inc.", "phone"),
    "88:66:a5": ("Apple, Inc.", "tv"), "dc:2b:2a": ("Apple, Inc.", "computer"),
    "b8:78:2e": ("Apple, Inc.", "phone"), "f4:1b:a1": ("Apple, Inc.", "computer"),
    # --- Samsung ---
    "00:16:32": ("Samsung Electronics", "phone"), "00:21:19": ("Samsung Electronics", "computer"),
    "00:24:90": ("Samsung Electronics", "phone"), "00:25:66": ("Samsung Electronics", "tv"),
    "00:e0:64": ("Samsung Electronics", "printer"), "14:49:e0": ("Samsung Electronics", "phone"),
    "34:23:87": ("Samsung Electronics", "tv"), "38:01:97": ("Samsung Electronics", "phone"),
    "5c:3c:27": ("Samsung Electronics", "phone"), "78:47:1d": ("Samsung Electronics", "phone"),
    "84:25:db": ("Samsung Electronics", "tv"), "8c:77:12": ("Samsung Electronics", "phone"),
    "b0:72:bf": ("Samsung Electronics", "phone"), "b4:79:a7": ("Samsung Electronics", "phone"),
    "b8:d9:ce": ("Samsung Electronics", "tv"), "b8:5a:73": ("Samsung Electronics", "computer"),
    "cc:07:ab": ("Samsung Electronics", "phone"), "d8:57:ef": ("Samsung Electronics", "phone"),
    "e4:58:b8": ("Samsung Electronics", "phone"), "e8:03:9a": ("Samsung Electronics", "phone"),
    "f0:5b:7b": ("Samsung Electronics", "tv"), "f4:09:d8": ("Samsung Electronics", "phone"),
    "f8:04:2e": ("Samsung Electronics", "phone"), "fc:f1:36": ("Samsung Electronics", "phone"),
    # --- Google / Nest / Chromecast ---
    "f4:f5:d8": ("Google, Inc.", "iot"), "6c:ad:f8": ("Google, Inc.", "iot"),
    "54:60:09": ("Google, Inc.", "phone"), "38:a4:ed": ("Google Nest", "iot"),
    "a4:77:33": ("Google, Inc.", "phone"), "64:70:33": ("Google, Inc.", "iot"),
    # --- Amazon (Echo, Ring, Kindle, Fire) ---
    "44:65:0d": ("Amazon Technologies", "iot"), "6c:56:97": ("Amazon Technologies", "iot"),
    "74:c2:46": ("Amazon Technologies", "iot"), "40:b4:cd": ("Amazon Technologies", "iot"),
    "68:37:e9": ("Amazon Technologies", "iot"), "74:75:48": ("Amazon Technologies", "iot"),
    "84:d6:d0": ("Amazon Technologies", "iot"), "50:dc:e7": ("Amazon Technologies", "iot"),
    "88:71:e0": ("Amazon Technologies", "iot"), "a0:02:dc": ("Amazon Technologies", "iot"),
    # --- Xiaomi / Aqara ---
    "00:9e:c8": ("Xiaomi Communications", "phone"), "04:cf:8c": ("Xiaomi Communications", "iot"),
    "14:f6:5a": ("Xiaomi Communications", "phone"), "18:59:36": ("Xiaomi Communications", "phone"),
    "28:6c:07": ("Xiaomi Communications", "iot"), "34:80:b3": ("Xiaomi Communications", "phone"),
    "38:a4:ed:00": ("Xiaomi Communications", "phone"), "3c:bd:d8": ("Xiaomi Communications", "phone"),
    "40:31:3c": ("Xiaomi Communications", "iot"), "4c:49:e3": ("Xiaomi Communications", "phone"),
    "50:64:2b": ("Xiaomi Communications", "phone"), "58:44:98": ("Xiaomi Communications", "tv"),
    "64:09:80": ("Xiaomi Communications", "phone"), "74:23:44": ("Xiaomi Communications", "phone"),
    "74:51:ba": ("Xiaomi Communications", "phone"), "78:02:f8": ("Xiaomi Communications", "phone"),
    "7c:1d:d9": ("Xiaomi Communications", "phone"), "7c:49:eb": ("Xiaomi Communications", "iot"),
    "84:f3:eb": ("Xiaomi Communications", "phone"), "88:c3:97": ("Xiaomi Communications", "phone"),
    "8c:be:be": ("Xiaomi Communications", "phone"), "f8:a4:5f": ("Xiaomi Communications", "phone"),
    # --- Raspberry Pi ---
    "b8:27:eb": ("Raspberry Pi Trading", "computer"), "dc:a6:32": ("Raspberry Pi Trading", "computer"),
    "e4:5f:01": ("Raspberry Pi Trading", "computer"), "28:cd:c1": ("Raspberry Pi Trading", "computer"),
    "d8:3a:dd": ("Raspberry Pi Trading", "computer"),
    # --- Intel (NICs inside laptops/desktops) ---
    "00:02:b3": ("Intel Corporate", "computer"), "3c:a9:f4": ("Intel Corporate", "computer"),
    "a0:36:9f": ("Intel Corporate", "computer"), "00:27:10": ("Intel Corporate", "computer"),
    "8c:ec:4b": ("Intel Corporate", "computer"), "3c:97:0e": ("Intel Corporate", "computer"),
    "94:65:9c": ("Intel Corporate", "computer"), "f4:06:69": ("Intel Corporate", "computer"),
    "ac:7b:a1": ("Intel Corporate", "computer"), "0c:6b:3c": ("Intel Corporate", "computer"),
    "48:51:b5": ("Intel Corporate", "computer"), "40:e2:8d": ("Intel Corporate", "computer"),
    # --- Microsoft / Xbox ---
    "00:0d:3a": ("Microsoft Corporation", "computer"), "00:15:5d": ("Microsoft Hyper-V", "vm"),
    "00:17:fa": ("Microsoft Corporation", "console"), "00:1d:d8": ("Microsoft Corporation", "computer"),
    "00:25:ae": ("Microsoft Corporation", "console"), "98:4b:e1": ("Microsoft Corporation", "console"),
    "9c:b6:d0": ("Microsoft Corporation", "console"), "60:45:bd": ("Microsoft Corporation", "computer"),
    # --- Dell ---
    "00:06:5b": ("Dell Inc.", "computer"), "00:08:74": ("Dell Inc.", "computer"),
    "00:14:22": ("Dell Inc.", "computer"), "f8:db:88": ("Dell Inc.", "computer"),
    "18:03:73": ("Dell Inc.", "computer"), "5c:f9:38": ("Dell Inc.", "computer"),
    "d4:be:d9": ("Dell Inc.", "computer"), "b0:7b:25": ("Dell Inc.", "computer"),
    # --- HP ---
    "00:1e:0b": ("HP Inc.", "computer"), "00:1f:29": ("HP Inc.", "printer"),
    "00:21:5a": ("HP Inc.", "computer"), "00:23:7d": ("HP Inc.", "printer"),
    "00:25:b3": ("HP Inc.", "computer"), "3c:d9:2b": ("HP Inc.", "computer"),
    "64:51:06": ("HP Inc.", "printer"), "80:c1:6e": ("HP Inc.", "printer"),
    "84:34:97": ("HP Inc.", "computer"), "c4:34:6b": ("HP Inc.", "printer"),
    "c8:cb:b8": ("HP Inc.", "computer"), "10:1f:74": ("HP Inc.", "printer"),
    # --- Lenovo ---
    "54:ee:75": ("Lenovo", "computer"), "8c:16:45": ("Lenovo", "computer"),
    "60:d9:c7": ("Lenovo", "computer"), "ac:81:12": ("Lenovo", "computer"),
    "e8:9a:8f": ("Lenovo", "computer"), "88:ae:1d": ("Lenovo", "computer"),
    # --- ASUS ---
    "00:0c:6e": ("ASUSTek Computer", "router"), "00:11:2f": ("ASUSTek Computer", "computer"),
    "00:13:d4": ("ASUSTek Computer", "computer"), "00:15:f2": ("ASUSTek Computer", "router"),
    "00:17:31": ("ASUSTek Computer", "computer"), "00:1a:92": ("ASUSTek Computer", "computer"),
    "00:1f:c6": ("ASUSTek Computer", "router"), "04:d4:c4": ("ASUSTek Computer", "router"),
    "04:d9:f5": ("ASUSTek Computer", "computer"), "08:60:6e": ("ASUSTek Computer", "router"),
    "0c:37:dc": ("ASUSTek Computer", "router"), "10:bf:48": ("ASUSTek Computer", "computer"),
    "14:da:e9": ("ASUSTek Computer", "computer"), "2c:4d:54": ("ASUSTek Computer", "router"),
    "2c:56:dc": ("ASUSTek Computer", "computer"), "30:5a:3a": ("ASUSTek Computer", "computer"),
    "30:85:a9": ("ASUSTek Computer", "router"), "34:97:f6": ("ASUSTek Computer", "computer"),
    "40:b0:fa": ("ASUSTek Computer", "computer"), "48:5b:39": ("ASUSTek Computer", "router"),
    "50:46:5d": ("ASUSTek Computer", "computer"), "54:04:a6": ("ASUSTek Computer", "router"),
    "54:a0:50": ("ASUSTek Computer", "router"), "60:45:cb": ("ASUSTek Computer", "computer"),
    "74:d0:2b": ("ASUSTek Computer", "router"), "88:d7:f6": ("ASUSTek Computer", "computer"),
    "90:e6:ba": ("ASUSTek Computer", "computer"), "ac:22:0b": ("ASUSTek Computer", "router"),
    "b0:6e:bf": ("ASUSTek Computer", "router"), "bc:ae:c5": ("ASUSTek Computer", "computer"),
    "bc:ee:7b": ("ASUSTek Computer", "router"), "c8:60:00": ("ASUSTek Computer", "computer"),
    "d4:5d:64": ("ASUSTek Computer", "computer"), "d8:50:e6": ("ASUSTek Computer", "router"),
    "f0:79:59": ("ASUSTek Computer", "computer"), "f4:6d:04": ("ASUSTek Computer", "router"),
    "f8:32:e4": ("ASUSTek Computer", "router"),
    # --- TP-Link ---
    "50:c7:bf": ("TP-Link Systems", "router"), "14:cc:20": ("TP-Link Systems", "iot"),
    "30:b5:c2": ("TP-Link Systems", "router"), "5c:e9:31": ("TP-Link Systems", "router"),
    "74:da:38": ("TP-Link Systems", "router"), "48:22:54": ("TP-Link Systems", "router"),
    "68:ff:7b": ("TP-Link Systems", "iot"), "a4:2b:b0": ("TP-Link Systems", "router"),
    "ac:84:c6": ("TP-Link Systems", "router"), "c0:25:e9": ("TP-Link Systems", "router"),
    "d8:07:b6": ("TP-Link Systems", "router"), "e8:de:27": ("TP-Link Systems", "router"),
    # --- D-Link ---
    "00:05:5d": ("D-Link International", "router"), "00:0d:88": ("D-Link International", "router"),
    "00:11:95": ("D-Link International", "router"), "00:13:46": ("D-Link International", "router"),
    "00:17:9a": ("D-Link International", "router"), "00:19:5b": ("D-Link International", "router"),
    "00:1c:f0": ("D-Link International", "router"), "00:21:91": ("D-Link International", "router"),
    "00:22:b0": ("D-Link International", "router"), "34:08:04": ("D-Link International", "router"),
    "3c:1e:04": ("D-Link International", "router"), "6c:19:8f": ("D-Link International", "router"),
    "84:c9:b2": ("D-Link International", "router"), "b0:c5:54": ("D-Link International", "router"),
    "c8:d3:a3": ("D-Link International", "router"),
    # --- Netgear / Arlo ---
    "00:09:5b": ("Netgear", "router"), "00:0f:b5": ("Netgear", "router"),
    "00:14:6c": ("Netgear", "router"), "00:18:4d": ("Netgear", "router"),
    "00:1b:2f": ("Netgear", "router"), "00:1e:2a": ("Netgear", "router"),
    "00:1f:33": ("Netgear", "router"), "00:22:3f": ("Netgear", "router"),
    "00:24:b2": ("Netgear", "router"), "40:5d:82": ("Netgear", "router"),
    "b0:48:7a": ("Netgear", "router"), "9c:3d:cf": ("Netgear", "router"),
    "28:80:23": ("Netgear", "router"), "a0:40:a0": ("Netgear", "router"),
    # --- Huawei ---
    "00:18:82": ("Huawei Technologies", "phone"), "00:25:9e": ("Huawei Technologies", "router"),
    "00:66:4b": ("Huawei Technologies", "phone"), "08:63:61": ("Huawei Technologies", "phone"),
    "38:4c:4f": ("Huawei Technologies", "router"), "4c:1f:cc": ("Huawei Technologies", "phone"),
    "58:2a:f7": ("Huawei Technologies", "router"), "80:fb:06": ("Huawei Technologies", "phone"),
    "84:46:fe": ("Huawei Technologies", "phone"), "f8:4a:bf": ("Huawei Technologies", "phone"),
    "fc:48:ef": ("Huawei Technologies", "phone"), "20:08:ed": ("Huawei Technologies", "router"),
    "34:00:a3": ("Huawei Technologies", "phone"), "78:6a:3c": ("Huawei Technologies", "phone"),
    # --- Cisco ---
    "00:00:0c": ("Cisco Systems", "router"), "00:14:1b": ("Cisco Systems", "router"),
    "00:17:94": ("Cisco Systems", "router"), "00:1b:0d": ("Cisco Systems", "router"),
    "00:40:96": ("Cisco Systems", "router"), "58:97:1e": ("Cisco Systems", "router"),
    "f8:72:ea": ("Cisco Systems", "router"), "00:1a:a1": ("Cisco Systems", "router"),
    # --- Ubiquiti ---
    "04:18:d6": ("Ubiquiti Networks", "router"), "24:a4:3c": ("Ubiquiti Networks", "router"),
    "24:5a:4c": ("Ubiquiti Networks", "router"), "44:d9:e7": ("Ubiquiti Networks", "router"),
    "68:d7:12": ("Ubiquiti Networks", "router"), "78:8a:20": ("Ubiquiti Networks", "router"),
    "80:2a:a8": ("Ubiquiti Networks", "router"), "b4:fb:e4": ("Ubiquiti Networks", "router"),
    "d0:21:f9": ("Ubiquiti Networks", "router"), "e0:63:da": ("Ubiquiti Networks", "router"),
    "f0:9f:c2": ("Ubiquiti Networks", "router"),
    # --- MikroTik ---
    "00:0c:42": ("MikroTik", "router"), "2c:c8:1b": ("MikroTik", "router"),
    "48:8f:5a": ("MikroTik", "router"), "54:05:ab": ("MikroTik", "router"),
    "64:d1:54": ("MikroTik", "router"), "6c:3b:6b": ("MikroTik", "router"),
    "b8:69:f4": ("MikroTik", "router"), "cc:2d:e0": ("MikroTik", "router"),
    "d4:ca:6d": ("MikroTik", "router"), "dc:2c:6e": ("MikroTik", "router"),
    "e4:8d:8c": ("MikroTik", "router"),
    # --- Tenda ---
    "c8:3a:35": ("Tenda Technology", "router"), "50:2e:8c": ("Tenda Technology", "router"),
    # --- Espressif (ESP8266/ESP32 — the heart of DIY + cheap IoT) ---
    "24:0a:c4": ("Espressif (ESP IoT)", "iot"), "24:6f:28": ("Espressif (ESP IoT)", "iot"),
    "30:ae:a4": ("Espressif (ESP IoT)", "iot"), "5c:cf:7f": ("Espressif (ESP IoT)", "iot"),
    "68:c6:0a": ("Espressif (ESP IoT)", "iot"), "84:0d:8e": ("Espressif (ESP IoT)", "iot"),
    "8c:ce:4e": ("Espressif (ESP IoT)", "iot"), "a4:cf:12": ("Espressif (ESP IoT)", "iot"),
    "bc:dd:c2": ("Espressif (ESP IoT)", "iot"), "dc:4f:22": ("Espressif (ESP IoT)", "iot"),
    "e8:db:84": ("Espressif (ESP IoT)", "iot"), "ec:fa:bc": ("Espressif (ESP IoT)", "iot"),
    "f4:cf:a2": ("Espressif (ESP IoT)", "iot"),
    # --- Smart-home specialists ---
    "00:17:88": ("Philips Lighting (Hue)", "iot"), "34:ea:34": ("Broadlink", "iot"),
    "d8:f1:5b": ("Tuya Smart", "iot"), "00:22:75": ("Belkin International", "iot"),
    "94:10:3e": ("Belkin International", "iot"), "ec:23:3d": ("Belkin International", "iot"),
    "48:a6:b8": ("Sonos", "iot"), "5c:aa:fd": ("Sonos", "iot"),
    "94:9f:3e": ("Sonos", "iot"), "b8:e9:37": ("Sonos", "iot"),
    "34:7e:5c": ("Sonos", "iot"), "90:0f:0c": ("LG Electronics", "tv"),
    "00:24:83": ("LG Electronics", "tv"), "10:68:3f": ("LG Electronics", "tv"),
    "30:8c:fb": ("LG Electronics", "tv"), "64:89:9a": ("LG Electronics", "tv"),
    "cc:fa:00": ("LG Electronics", "tv"),
    # --- Sony / PlayStation ---
    "00:01:4a": ("Sony Corporation", "console"), "00:04:1f": ("Sony Corporation", "console"),
    "00:1a:80": ("Sony Corporation", "tv"), "00:1f:c5": ("Nintendo", "console"),
    "58:b0:35": ("Nintendo", "console"),
    # --- NAS / storage ---
    "00:11:32": ("Synology", "nas"), "00:08:9b": ("QNAP Systems", "nas"),
    "00:90:a9": ("Western Digital", "nas"), "00:14:ee": ("Western Digital", "nas"),
    # --- Printers ---
    "00:1b:a9": ("Brother Industries", "printer"), "30:05:5c": ("Brother Industries", "printer"),
    "00:00:48": ("Seiko Epson", "printer"),
    # --- Virtualization ---
    "00:50:56": ("VMware, Inc.", "vm"), "00:0c:29": ("VMware, Inc.", "vm"),
    "00:05:69": ("VMware, Inc.", "vm"), "00:1c:14": ("VMware, Inc.", "vm"),
    "08:00:27": ("Oracle VirtualBox", "vm"), "00:1c:42": ("Parallels", "vm"),
    # --- Misc silicon / boards ---
    "00:10:18": ("Broadcom", "router"), "00:03:7f": ("Qualcomm Atheros", "router"),
    "90:a2:da": ("Arduino", "iot"), "00:04:4b": ("Nest Labs", "iot"),
    "18:b4:30": ("Google Nest", "iot"),
}

# Approximate IEEE assignment years for popular OUI blocks. Used only for the
# honest "manufacturing era" estimate — never presented as an exact build date.
_OUI_ASSIGNMENT_YEARS: Dict[str, int] = {
    "00:00:0c": 1994, "00:02:b3": 2000, "00:05:5d": 1998, "00:09:5b": 2001,
    "00:0c:29": 2002, "00:0d:3a": 2005, "00:11:32": 2007, "00:14:22": 2005,
    "00:17:88": 2008, "00:1b:63": 2006, "00:22:75": 2009, "00:25:9e": 2010,
    "24:0a:c4": 2015, "28:6f:28": 2016, "30:ae:a4": 2017, "34:ea:34": 2014,
    "38:a4:ed": 2016, "44:65:0d": 2014, "48:a6:b8": 2013, "50:c7:bf": 2012,
    "54:ee:75": 2014, "58:b0:35": 2010, "5c:cf:7f": 2014, "64:d1:54": 2014,
    "68:d7:12": 2015, "74:da:38": 2012, "78:47:1d": 2015, "80:fb:06": 2013,
    "88:c3:97": 2015, "90:e6:ba": 2010, "98:01:a7": 2016, "a4:5e:60": 2011,
    "ac:de:48": 2008, "b8:27:eb": 2012, "bc:dd:c2": 2016, "c8:3a:35": 2013,
    "d8:3a:dd": 2020, "dc:a6:32": 2019, "e8:03:9a": 2014, "f0:18:98": 2010,
    "f4:cf:a2": 2016, "f8:1e:df": 2009, "fc:f1:36": 2013,
}

# Vendor founding/incorporation metadata for the "About the maker" panel.
VENDOR_PROFILES: Dict[str, dict] = {
    "apple": {"hq": "Cupertino, CA, USA", "founded": 1976,
              "note": "Devices randomize Wi-Fi MACs by default; the address seen here may be per-network."},
    "samsung": {"hq": "Suwon, South Korea", "founded": 1938,
                "note": "Largest consumer electronics maker by volume."},
    "xiaomi": {"hq": "Beijing, China", "founded": 2010,
               "note": "Phones, TVs and a vast smart-home ecosystem."},
    "raspberry": {"hq": "Cambridge, UK", "founded": 2012,
                  "note": "Single-board computers; extremely common in home labs."},
    "espressif": {"hq": "Shanghai, China", "founded": 2008,
                  "note": "ESP8266/ESP32 Wi-Fi silicon inside most budget IoT devices."},
    "google": {"hq": "Mountain View, CA, USA", "founded": 1998,
               "note": "Nest/Chromecast/Pixel line-ups share OUI ranges."},
    "amazon": {"hq": "Seattle, WA, USA", "founded": 1994,
               "note": "Echo, Ring and Kindle devices."},
    "intel": {"hq": "Santa Clara, CA, USA", "founded": 1968,
              "note": "Wi-Fi NICs found inside laptops from many brands."},
    "microsoft": {"hq": "Redmond, WA, USA", "founded": 1975,
                  "note": "Surface PCs and Xbox consoles."},
    "tp-link": {"hq": "Shenzhen, China", "founded": 1996,
                "note": "Consumer routers, extenders and Kasa/Tapo smart devices."},
    "ubiquiti": {"hq": "New York, NY, USA", "founded": 2005,
                 "note": "UniFi networking gear beloved by enthusiasts."},
    "mikrotik": {"hq": "Riga, Latvia", "founded": 1996,
                 "note": "RouterOS boards — powerful, occasionally misconfigured."},
    "synology": {"hq": "Taipei, Taiwan", "founded": 2000, "note": "Popular NAS appliances."},
    "sonos": {"hq": "Santa Barbara, CA, USA", "founded": 2002, "note": "Multi-room audio."},
    "huawei": {"hq": "Shenzhen, China", "founded": 1987, "note": "Phones, routers and infrastructure."},
    "philips": {"hq": "Eindhoven, Netherlands", "founded": 1891, "note": "Hue smart lighting."},
    "netgear": {"hq": "San Jose, CA, USA", "founded": 1996, "note": "Consumer routers and Arlo cameras."},
}

_MAC_RE = re.compile(r"^([0-9a-fA-F]{2}[:-]){5}[0-9a-fA-F]{2}$")

_online_cache: Dict[str, str] = {}
_online_lock = threading.Lock()


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------


def is_valid_mac(mac: str) -> bool:
    return bool(_MAC_RE.match(mac or ""))


def oui_prefix(mac: str) -> str:
    """Extract the 3-byte OUI prefix in canonical lowercase form."""
    clean = re.sub(r"[^0-9a-fA-F]", "", mac or "")
    if len(clean) < 6:
        return ""
    return ":".join(clean[i:i + 2].lower() for i in range(0, 6, 2))


def is_locally_administered(mac: str) -> bool:
    """True for randomized/overridden MACs (bit 1 of first octet set)."""
    prefix = oui_prefix(mac)
    if not prefix:
        return False
    first_octet = int(prefix[0:2], 16)
    return bool(first_octet & 0x02)


def lookup_vendor(mac: str, online: bool = False) -> Optional[str]:
    """
    Resolve a MAC to a vendor name.
    `online=True` falls back to macvendors.com for unknown prefixes.
    The online path is strictly opt-in (privacy: MACs leave the LAN).
    """
    prefix = oui_prefix(mac)
    if not prefix:
        return None
    hit = EMBEDDED_OUI.get(prefix)
    if hit:
        return hit[0]
    if is_locally_administered(mac):
        return None  # randomized — no registry entry can exist
    if not online:
        return None
    with _online_lock:
        if prefix in _online_cache:
            return _online_cache[prefix] or None
    vendor = _online_lookup(prefix)
    with _online_lock:
        _online_cache[prefix] = vendor or ""
    return vendor


def lookup_class_hint(mac: str) -> Optional[str]:
    """Device-class hint derived purely from the OUI's owner."""
    prefix = oui_prefix(mac)
    hit = EMBEDDED_OUI.get(prefix)
    return hit[1] if hit else None


def _online_lookup(prefix: str) -> Optional[str]:
    mac = prefix.replace(":", "").upper() + "00000000"[:8].ljust(8, "0")
    url = f"https://api.macvendors.com/{mac[:12]}"
    try:
        req = urllib.request.Request(url, headers={"User-Agent": "AetherScan/1.4"})
        with urllib.request.urlopen(req, timeout=4.0) as resp:
            if resp.status == 200:
                text = resp.read(256).decode("utf-8", "replace").strip()
                if text and "not found" not in text.lower() and len(text) < 100:
                    return text
    except Exception:
        return None
    return None


def estimate_device_era(mac: str) -> Optional[dict]:
    """
    Honest manufacturing-era estimate.

    IEEE OUI blocks are assigned on specific dates. A device carrying an
    OUI cannot predate that assignment, so the assignment year gives a
    lower bound; combined with vendor release patterns we label an era.
    """
    prefix = oui_prefix(mac)
    if not prefix:
        return None
    year = _OUI_ASSIGNMENT_YEARS.get(prefix)
    if year is None:
        return None
    if year <= 2005:
        era = "2005 or earlier (legacy hardware)"
    elif year <= 2012:
        era = f"~{year}–2015 (early smart era)"
    elif year <= 2018:
        era = f"~{year}–2020 (modern era)"
    else:
        era = f"{year} or later (current generation)"
    return {
        "oui_registered": year,
        "era_label": era,
        "basis": "IEEE OUI assignment date (lower bound on manufacture)",
    }


def vendor_profile(vendor: Optional[str]) -> Optional[dict]:
    """Rich vendor metadata for the device-detail pane, if we have it."""
    if not vendor:
        return None
    low = vendor.lower()
    for key, profile in VENDOR_PROFILES.items():
        if key in low:
            return {"name": vendor, **profile}
    return None


def vendor_badge(vendor: Optional[str]) -> str:
    """Short normalized brand key used by the UI for logos/colors."""
    if not vendor:
        return "unknown"
    low = vendor.lower()
    for key in ("apple", "samsung", "google", "amazon", "xiaomi", "huawei",
                "raspberry", "espressif", "intel", "microsoft", "dell", "hp",
                "lenovo", "asus", "tp-link", "d-link", "netgear", "cisco",
                "ubiquiti", "mikrotik", "tenda", "sonos", "philips", "synology",
                "qnap", "western digital", "brother", "epson", "sony",
                "nintendo", "lg", "belkin", "tuya", "broadlink", "vmware",
                "virtualbox", "parallels", "qualcomm", "broadcom", "arduino",
                "nest"):
        if key in low:
            return key.replace(" ", "-")
    return "unknown"


def describe_mac(mac: str, online: bool = False) -> dict:
    """One-shot bundle used by the scan engine."""
    vendor = lookup_vendor(mac, online=online)
    return {
        "mac": mac,
        "vendor": vendor,
        "vendor_badge": vendor_badge(vendor),
        "class_hint": lookup_class_hint(mac),
        "locally_administered": is_locally_administered(mac),
        "era": estimate_device_era(mac),
        "profile": vendor_profile(vendor),
    }
