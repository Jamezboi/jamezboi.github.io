"""
core/report.py — Exportable, share-ready audit documentation.

Formats:
  * HTML — self-contained (inline CSS, no external deps), styled to match
           the app; suitable for emailing to a client or archiving.
  * JSON — machine-readable full inventory + findings.
  * CSV  — spreadsheet-friendly device table.
  * MD   — Markdown executive summary for tickets/PRs.

Premium feature.
"""

from __future__ import annotations

import csv
import io
import json
import os
import time
from typing import List, Optional

_CSS = """
:root { color-scheme: light; }
* { box-sizing: border-box; margin: 0; padding: 0; }
body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Inter, Roboto,
       'Helvetica Neue', Arial, sans-serif; background: #f5f5f7; color: #1d1d1f;
       line-height: 1.55; padding: 48px 24px; }
.page { max-width: 980px; margin: 0 auto; }
header.hero { background: linear-gradient(135deg, #0a84ff 0%, #5e5ce6 100%);
  border-radius: 24px; padding: 40px; color: #fff; margin-bottom: 28px; }
header.hero h1 { font-size: 32px; font-weight: 700; letter-spacing: -0.5px; }
header.hero p { opacity: .9; margin-top: 8px; }
.meta { display: flex; gap: 28px; margin-top: 20px; flex-wrap: wrap; }
.meta div span { display: block; font-size: 12px; text-transform: uppercase;
  letter-spacing: .8px; opacity: .7; }
.meta div strong { font-size: 20px; }
section { background: #fff; border-radius: 20px; padding: 28px; margin-bottom: 20px;
  box-shadow: 0 1px 3px rgba(0,0,0,.06); }
section h2 { font-size: 19px; margin-bottom: 14px; letter-spacing: -.3px; }
table { width: 100%; border-collapse: collapse; font-size: 13.5px; }
th { text-align: left; font-size: 11px; text-transform: uppercase; letter-spacing: .6px;
  color: #6e6e73; padding: 8px 10px; border-bottom: 1px solid #e5e5ea; }
td { padding: 9px 10px; border-bottom: 1px solid #f0f0f2; vertical-align: top; }
tr:last-child td { border-bottom: none; }
.score { display: inline-flex; align-items: center; justify-content: center;
  width: 34px; height: 34px; border-radius: 50%; color: #fff; font-weight: 700; }
.score.a { background: #30d158; } .score.b { background: #0a84ff; }
.score.c { background: #ffd60a; color: #1d1d1f; } .score.d { background: #ff9f0a; }
.score.f { background: #ff453a; }
.sev { display: inline-block; padding: 2px 9px; border-radius: 999px; font-size: 11px;
  font-weight: 600; text-transform: uppercase; letter-spacing: .4px; }
.sev.critical { background: #ffe5e4; color: #c41e3a; }
.sev.high { background: #ffedd9; color: #b25000; }
.sev.medium { background: #fff4cc; color: #8a6d00; }
.sev.low { background: #e8f2ff; color: #0066cc; }
.sev.info { background: #ececf0; color: #555; }
footer { text-align: center; color: #86868b; font-size: 12px; margin-top: 32px; }
a { color: #0066cc; }
"""


def _esc(text) -> str:
    return (str(text) if text is not None else "").replace(
        "&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")


class ReportBuilder:
    """Turns inventory + audits into deliverables."""

    def __init__(self, devices: List[dict], network_info: dict,
                 summary: Optional[dict] = None, audits: Optional[List[dict]] = None,
                 app_version: str = "1.4.0"):
        self.devices = devices
        self.network_info = network_info
        self.summary = summary or {}
        self.audits = audits or []
        self.app_version = app_version
        self.generated = time.time()

    # -- HTML -----------------------------------------------------------------

    def to_html(self) -> str:
        now = time.strftime("%b %d, %Y · %H:%M", time.localtime(self.generated))
        dev_count = len(self.devices)
        findings = self.summary.get("counts", {}) or {}
        critical = findings.get("critical", 0)
        high = findings.get("high", 0)
        grade = self.summary.get("grade", "—")
        avg = self.summary.get("average_score", "—")

        rows = []
        for device in sorted(self.devices, key=lambda d: d.get("ip", "")):
            audit = self._audit_for(device.get("ip"))
            score_cell = ""
            if audit:
                score_cell = (f'<span class="score {audit["grade"].lower()}">'
                              f'{audit["score"]}</span>')
            rows.append(
                "<tr>"
                f"<td><strong>{_esc(device.get('display_name'))}</strong><br>"
                f'<span style="color:#86868b;font-size:12px">{_esc(device.get("vendor"))}</span></td>'
                f"<td>{_esc(device.get('ip'))}</td>"
                f"<td style=\"font-family:ui-monospace,Menlo,Consolas,monospace;font-size:12px\">"
                f"{_esc(device.get('mac'))}</td>"
                f"<td>{_esc(device.get('device_type'))}</td>"
                f"<td>{_esc(device.get('os_guess') or '—')}</td>"
                f"<td>{score_cell or '—'}</td>"
                "</tr>")
        device_table = (
            "<table><tr><th>Device</th><th>IP</th><th>MAC</th><th>Type</th>"
            "<th>OS guess</th><th>Score</th></tr>" + "".join(rows) + "</table>"
            if rows else "<p style='color:#86868b'>No devices discovered yet.</p>")

        finding_rows = []
        for audit in sorted(self.audits, key=lambda a: a.get("score", 100)):
            for finding in audit.get("findings", [])[:8]:
                finding_rows.append(
                    "<tr>"
                    f'<td><span class="sev {_esc(finding["severity"])}">{_esc(finding["severity"])}</span></td>'
                    f"<td><strong>{_esc(finding['title'])}</strong><br>"
                    f'<span style="color:#86868b;font-size:12px">{_esc(finding["description"])}</span></td>'
                    f"<td>{_esc(audit.get('ip'))}</td>"
                    f'<td style="color:#6e6e73">{_esc(finding.get("remediation"))}</td>'
                    "</tr>")
        findings_table = (
            "<table><tr><th>Severity</th><th>Finding</th><th>Device</th><th>Remediation</th></tr>"
            + "".join(finding_rows) + "</table>"
            if finding_rows else
            "<p style='color:#30d158;font-weight:600'>✓ No security findings recorded. Either "
            "no audit has run yet, or your network is in great shape.</p>")

        return f"""<!DOCTYPE html>
<html lang="en"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>AetherScan Network Report</title><style>{_CSS}</style></head>
<body><div class="page">
<header class="hero">
  <h1>Network Intelligence Report</h1>
  <p>Generated by AetherScan v{_esc(self.app_version)} · {_esc(self.network_info.get('ssid_label', 'Local network'))}</p>
  <div class="meta">
    <div><span>Devices</span><strong>{dev_count}</strong></div>
    <div><span>Security grade</span><strong>{_esc(grade)}</strong></div>
    <div><span>Avg score</span><strong>{_esc(avg)}</strong></div>
    <div><span>Critical / High</span><strong>{critical} / {high}</strong></div>
    <div><span>Generated</span><strong>{now}</strong></div>
  </div>
</header>
<section><h2>Discovered devices</h2>{device_table}</section>
<section><h2>Security findings</h2>{findings_table}</section>
<section><h2>Environment</h2>
  <table>
    <tr><th>Subnet</th><td>{_esc(self.network_info.get('cidr'))}</td></tr>
    <tr><th>Gateway</th><td>{_esc(self.network_info.get('gateway'))}</td></tr>
    <tr><th>Interface</th><td>{_esc(self.network_info.get('interface'))}</td></tr>
    <tr><th>Host running the scan</th><td>{_esc(self.network_info.get('host'))}</td></tr>
  </table>
  <p style="margin-top:14px;color:#86868b;font-size:12px">This report was produced with
  non-invasive checks only. Findings reference public CVE identifiers where relevant;
  no exploitation was attempted. Use only on networks you own or are authorized to assess.</p>
</section>
<footer>AetherScan Labs · Report {_esc(time.strftime('%Y%m%d-%H%M%S', time.localtime(self.generated)))}</footer>
</div></body></html>"""

    # -- JSON / CSV / Markdown --------------------------------------------------

    def to_json(self) -> str:
        return json.dumps({
            "generated": self.generated,
            "generated_iso": time.strftime("%Y-%m-%dT%H:%M:%S", time.localtime(self.generated)),
            "app_version": self.app_version,
            "network": self.network_info,
            "summary": self.summary,
            "devices": self.devices,
            "audits": self.audits,
        }, indent=2)

    def to_csv(self) -> str:
        buffer = io.StringIO()
        writer = csv.writer(buffer)
        writer.writerow(["Name", "IP", "MAC", "Vendor", "Type", "OS guess",
                         "Model", "Open ports", "First seen", "Last seen",
                         "Audit score", "Audit grade"])
        for d in self.devices:
            audit = self._audit_for(d.get("ip"))
            writer.writerow([
                d.get("display_name"), d.get("ip"), d.get("mac"),
                d.get("vendor"), d.get("device_type"), d.get("os_guess"),
                d.get("model"),
                " ".join(str(p) for p in (d.get("ports") or []) if p.get("open")),
                d.get("first_seen_iso"), d.get("last_seen_iso"),
                audit.get("score") if audit else "",
                audit.get("grade") if audit else "",
            ])
        return buffer.getvalue()

    def to_markdown(self) -> str:
        lines = [
            "# AetherScan Network Report",
            "",
            f"*Generated {time.strftime('%Y-%m-%d %H:%M', time.localtime(self.generated))} "
            f"· v{self.app_version}*",
            "",
            f"- **Devices:** {len(self.devices)}",
            f"- **Security grade:** {self.summary.get('grade', '—')} "
            f"(avg {self.summary.get('average_score', '—')}/100)",
            "",
            "## Devices",
            "",
            "| Device | IP | MAC | Type | Score |",
            "|---|---|---|---|---|",
        ]
        for d in sorted(self.devices, key=lambda x: x.get("ip", "")):
            audit = self._audit_for(d.get("ip"))
            score = f"{audit['score']} ({audit['grade']})" if audit else "—"
            lines.append(f"| {d.get('display_name')} | {d.get('ip')} | "
                         f"`{d.get('mac')}` | {d.get('device_type')} | {score} |")
        critical = [a for a in self.audits for f in a.get("findings", [])
                    if f["severity"] in ("critical", "high")]
        if critical:
            lines += ["", "## Priority findings", ""]
            for finding in critical[:15]:
                lines.append(f"- **[{finding['severity'].upper()}]** {finding['title']}")
        return "\n".join(lines) + "\n"

    # -- helpers ---------------------------------------------------------------

    def _audit_for(self, ip: str) -> Optional[dict]:
        for audit in self.audits:
            if audit.get("ip") == ip:
                return audit
        return None

    def save(self, fmt: str, out_dir: str) -> str:
        os.makedirs(out_dir, exist_ok=True)
        stamp = time.strftime("%Y%m%d-%H%M%S", time.localtime(self.generated))
        payload, ext = {
            "html": (self.to_html(), "html"),
            "json": (self.to_json(), "json"),
            "csv": (self.to_csv(), "csv"),
            "md": (self.to_markdown(), "md"),
        }.get(fmt, (self.to_html(), "html"))
        filename = f"aetherscan-report-{stamp}.{ext}"
        path = os.path.join(out_dir, filename)
        with open(path, "w", encoding="utf-8", newline="") as handle:
            handle.write(payload)
        return path
