"""
core/network.py — Low-level network plumbing.

Responsibilities:
  * Local interface / subnet discovery (Windows, macOS, Linux)
  * CIDR arithmetic helpers (built on the stdlib `ipaddress` module)
  * Parallel ICMP ping sweep (via the OS `ping` binary, no raw sockets,
    no administrator privileges required)
  * ARP table harvesting (`arp -a`) to recover MAC addresses
  * Default gateway detection
  * TTL capture for lightweight OS fingerprinting

Design notes:
  * All blocking helpers accept a `workers` argument and use a
    ThreadPoolExecutor so a /24 sweep finishes in a couple of seconds.
  * Every parser is defensive: OS locale differences, IPv6 noise and
    malformed `arp` output must never raise into the scan engine.
"""

from __future__ import annotations

import concurrent.futures
import ipaddress
import os
import platform
import re
import socket
import subprocess
import sys
import time
from dataclasses import dataclass, field
from typing import Dict, Iterable, List, Optional, Tuple

IS_WINDOWS = platform.system().lower() == "windows"
IS_MACOS = platform.system().lower() == "darwin"

# ---------------------------------------------------------------------------
# Data containers
# ---------------------------------------------------------------------------


@dataclass
class Interface:
    """A local network interface considered scannable."""

    name: str
    ip: str
    netmask: str
    cidr: str  # e.g. 192.168.1.0/24
    broadcast: str
    is_wireless: bool = False
    is_virtual: bool = False

    def hosts(self, limit: int = 1024) -> List[str]:
        """Return candidate host IPs inside this interface's subnet."""
        try:
            net = ipaddress.ip_network(self.cidr, strict=False)
        except ValueError:
            return []
        hosts: List[str] = []
        for host in net.hosts():
            hosts.append(str(host))
            if len(hosts) >= limit:
                break
        return hosts

    def to_dict(self) -> dict:
        return {
            "name": self.name,
            "ip": self.ip,
            "netmask": self.netmask,
            "cidr": self.cidr,
            "broadcast": self.broadcast,
            "is_wireless": self.is_wireless,
            "is_virtual": self.is_virtual,
            "host_count": len(self.hosts(limit=65536)),
        }


@dataclass
class PingResult:
    """Outcome of a single ICMP probe."""

    ip: str
    alive: bool
    ttl: Optional[int] = None
    latency_ms: Optional[float] = None
    error: Optional[str] = None

    def to_dict(self) -> dict:
        return {
            "ip": self.ip,
            "alive": self.alive,
            "ttl": self.ttl,
            "latency_ms": self.latency_ms,
        }


@dataclass
class SweepResult:
    """Aggregate outcome of a full subnet sweep."""

    subnet: str
    scanned: int = 0
    alive: int = 0
    duration_ms: int = 0
    results: List[PingResult] = field(default_factory=list)
    arp_entries: Dict[str, str] = field(default_factory=dict)  # ip -> mac

    def to_dict(self) -> dict:
        return {
            "subnet": self.subnet,
            "scanned": self.scanned,
            "alive": self.alive,
            "duration_ms": self.duration_ms,
            "results": [r.to_dict() for r in self.results],
            "arp_entries": self.arp_entries,
        }


# ---------------------------------------------------------------------------
# Subnet / address helpers
# ---------------------------------------------------------------------------

_PUBLIC_BOGONS = ("169.254.", "0.0.0.0", "127.", "224.", "255.")


def is_scannable_ipv4(ip: str) -> bool:
    """True when the address is a private/RFC1918 IPv4 worth scanning."""
    try:
        addr = ipaddress.ip_address(ip)
    except ValueError:
        return False
    if addr.version != 4:
        return False
    if any(ip.startswith(prefix) for prefix in _PUBLIC_BOGONS):
        return False
    return addr.is_private or addr.is_loopback is False and addr.is_global is False


def safe_cidr(ip: str, netmask_or_prefix: str) -> Optional[str]:
    """Combine an IP and netmask (or '/24' style prefix) into a CIDR."""
    try:
        if netmask_or_prefix.startswith("/"):
            net = ipaddress.ip_network(ip + netmask_or_prefix, strict=False)
        else:
            net = ipaddress.ip_network(f"{ip}/{netmask_or_prefix}", strict=False)
        return str(net)
    except ValueError:
        return None


def netmask_to_prefix(netmask: str) -> int:
    try:
        return ipaddress.ip_network(f"0.0.0.0/{netmask}").prefixlen
    except ValueError:
        return 24


def same_subnet(a: str, b: str, prefix: int) -> bool:
    try:
        net_a = ipaddress.ip_network(f"{a}/{prefix}", strict=False)
        net_b = ipaddress.ip_network(f"{b}/{prefix}", strict=False)
        return net_a.network_address == net_b.network_address
    except ValueError:
        return False


def sort_ips(ips: Iterable[str]) -> List[str]:
    def key(ip: str):
        try:
            return (0, int(ipaddress.ip_address(ip)))
        except ValueError:
            return (1, 0)

    return sorted(ips, key=key)


# ---------------------------------------------------------------------------
# Local interface discovery
# ---------------------------------------------------------------------------

_VIRTUAL_HINTS = ("virtual", "vmware", "virtualbox", "vethernet", "hyper-v",
                  "docker", "wsl", "loopback", "tap", "tun", "bluetooth",
                  "vpng", "openvpn", "tailscale", "zerotier")


def _run(cmd: List[str], timeout: float = 6.0) -> str:
    """Run a subprocess and return decoded stdout ('' on any failure)."""
    try:
        creation = 0x08000000 if IS_WINDOWS else 0  # CREATE_NO_WINDOW
        proc = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            timeout=timeout,
            creationflags=creation,
        )
        return proc.stdout or ""
    except (OSError, subprocess.SubprocessError):
        return ""


def primary_local_ip() -> str:
    """
    Best-effort local IPv4. Trick: open a UDP socket to a public resolver;
    no packets actually leave, but the OS picks the default-route source IP.
    """
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        sock.settimeout(0.5)
        sock.connect(("8.8.8.8", 53))
        return sock.getsockname()[0]
    except OSError:
        try:
            return socket.gethostbyname(socket.gethostname())
        except OSError:
            return "127.0.0.1"
    finally:
        sock.close()


def _parse_windows_interfaces() -> List[Interface]:
    out = _run(["ipconfig", "/all"])
    interfaces: List[Interface] = []
    current: Optional[dict] = None
    lines = out.splitlines()

    ipv4_re = re.compile(r"IPv4[\w\s\(\)]*?:\s*([0-9.]+)")
    mask_re = re.compile(r"Subnet Mask.*?:\s*([0-9.]+)")
    title_re = re.compile(r"^(.+?):$")

    for raw in lines:
        line = raw.strip()
        if not line:
            continue
        title = title_re.match(line)
        looks_like_header = title and any(
            line.lower().startswith(p) for p in ("ethernet", "wireless", "adapter",
                                                 "virtual", "ethernet-adapter", "lan"))
        if looks_like_header:
            if current and current.get("ip") and current.get("mask"):
                interfaces.append(_mk_interface(current))
            current = {"name": title.group(1).strip(), "src": title.group(1)}
            continue
        if current is None:
            continue
        m = ipv4_re.search(line)
        if m:
            current["ip"] = m.group(1).strip()
            continue
        m = mask_re.search(line)
        if m:
            current["mask"] = m.group(1).strip()
            continue
        low = line.lower()
        if "wireless" in low or "wi-fi" in low or "802.11" in low:
            current["wireless"] = True

    if current and current.get("ip") and current.get("mask"):
        interfaces.append(_mk_interface(current))
    return interfaces


def _mk_interface(data: dict) -> Interface:
    name = data.get("name", "unknown")
    ip = data.get("ip", "0.0.0.0")
    mask = data.get("mask", "255.255.255.0")
    cidr = safe_cidr(ip, mask) or f"{ip}/32"
    low = name.lower()
    is_virtual = any(h in low for h in _VIRTUAL_HINTS)
    try:
        broadcast = str(ipaddress.ip_network(cidr, strict=False).broadcast_address)
    except ValueError:
        broadcast = ip
    return Interface(
        name=name,
        ip=ip,
        netmask=mask,
        cidr=cidr,
        broadcast=broadcast,
        is_wireless=bool(data.get("wireless")),
        is_virtual=is_virtual,
    )


def _parse_unix_interfaces() -> List[Interface]:
    out = _run(["ifconfig"]) or _run(["ip", "addr"])
    interfaces: List[Interface] = []
    if out.startswith(("eth", "lo", "w", "en", "utun")) or "flags=" in out or "<" in out:
        # ifconfig-style output
        blocks = re.split(r"\n(?=\S)", out)
        for block in blocks:
            header = re.match(r"(\S+?):?\s*flags", block) or re.match(r"(\S+):", block)
            if not header:
                continue
            name = header.group(1)
            inet = re.search(r"inet\s+(?:addr:)?([0-9.]+)(?:\s+netmask\s+([0-9A-Fa-f.]+))?", block)
            if not inet:
                continue
            ip = inet.group(1)
            mask_raw = inet.group(2) or "255.255.255.0"
            if ":" in mask_raw:  # hex netmask on BSD/macOS
                try:
                    mask_raw = str(ipaddress.ip_address(int(mask_raw, 16)))
                except ValueError:
                    mask_raw = "255.255.255.0"
            low = (name or "").lower()
            interfaces.append(_mk_interface({
                "name": name,
                "ip": ip,
                "mask": mask_raw,
                "wireless": low.startswith(("wl", "en0", "en1")),
            }))
    return interfaces


def local_interfaces() -> List[Interface]:
    """
    Enumerate usable local interfaces. Virtual adapters are deprioritized
    (kept, but flagged) so the UI can default to the real Wi-Fi NIC.
    """
    try:
        if IS_WINDOWS:
            found = _parse_windows_interfaces()
        else:
            found = _parse_unix_interfaces()
    except Exception:
        found = []

    if not found:
        # Absolute fallback: synthesize one interface from the primary IP.
        ip = primary_local_ip()
        found = [_mk_interface({"name": "auto", "ip": ip, "mask": "255.255.255.0"})]

    # Drop loopback / link-local duplicates and dedupe by ip.
    seen = set()
    unique: List[Interface] = []
    for iface in found:
        if iface.ip in seen or iface.ip.startswith("0.0.0.0"):
            continue
        seen.add(iface.ip)
        unique.append(iface)

    unique.sort(key=lambda i: (i.is_virtual, not i.is_wireless, i.name))
    return unique


def default_gateway(interface: Optional[Interface] = None) -> Optional[str]:
    """Detect the default gateway/router IP for the chosen interface."""
    if IS_WINDOWS:
        out = _run(["ipconfig"])
        lines = [l.strip() for l in out.splitlines()]
        for idx, line in enumerate(lines):
            if "Default Gateway" in line:
                m = re.search(r"([0-9]+\.[0-9]+\.[0-9]+\.[0-9]+)", line)
                if m:
                    return m.group(1)
                for follow in lines[idx + 1:idx + 3]:
                    m = re.search(r"([0-9]+\.[0-9]+\.[0-9]+\.[0-9]+)", follow)
                    if m:
                        return m.group(1)
        out = _run(["route", "print", "-4", "0.0.0.0"])
        for line in out.splitlines():
            if line.strip().startswith("0.0.0.0"):
                parts = line.split()
                if len(parts) >= 3:
                    return parts[2]
    else:
        out = _run(["route", "-n", "get", "default"]) if IS_MACOS else _run(["route", "-n"])
        for line in out.splitlines():
            if IS_MACOS and "gateway:" in line:
                m = re.search(r"([0-9]+\.[0-9]+\.[0-9]+\.[0-9]+)", line)
                if m:
                    return m.group(1)
            if not IS_MACOS and line.startswith("0.0.0.0"):
                parts = line.split()
                if len(parts) >= 2:
                    return parts[1]
    # Last resort: x.x.x.1 on the interface subnet.
    if interface is not None:
        try:
            net = ipaddress.ip_network(interface.cidr, strict=False)
            return str(net.network_address + 1)
        except ValueError:
            pass
    return None


# ---------------------------------------------------------------------------
# ICMP ping (via OS binary — portable, no raw sockets, no admin rights)
# ---------------------------------------------------------------------------

_TTL_RE = re.compile(r"ttl[=\s:]+(\d+)", re.IGNORECASE)
_TIME_RE = re.compile(r"time[=<]([\d.]+)\s*ms", re.IGNORECASE)


def ping(ip: str, timeout_ms: int = 600) -> PingResult:
    """Ping one host. Returns aliveness plus TTL + latency when available."""
    if IS_WINDOWS:
        cmd = ["ping", "-n", "1", "-w", str(timeout_ms), ip]
    else:
        cmd = ["ping", "-c", "1", "-W", str(max(1, timeout_ms // 1000)), ip]
    try:
        creation = 0x08000000 if IS_WINDOWS else 0
        proc = subprocess.run(cmd, capture_output=True, text=True,
                              timeout=timeout_ms / 1000.0 + 2.0,
                              creationflags=creation)
        out = (proc.stdout or "") + (proc.stderr or "")
    except subprocess.TimeoutExpired:
        return PingResult(ip=ip, alive=False, error="timeout")
    except OSError as exc:
        return PingResult(ip=ip, alive=False, error=str(exc))

    low = out.lower()
    ttl_m = _TTL_RE.search(out)
    time_m = _TIME_RE.search(out)
    ttl = int(ttl_m.group(1)) if ttl_m else None
    latency = float(time_m.group(1)) if time_m else None

    # Windows ping exits 0 even for "Destination host unreachable" in some
    # cases, so require a TTL in the output as proof of a real reply.
    alive = ("ttl=" in low or "ttl " in low) and "unreachable" not in low
    if not alive and proc_check_aliveness(low):
        alive = True
    return PingResult(ip=ip, alive=alive, ttl=ttl, latency_ms=latency)


def proc_check_aliveness(low_output: str) -> bool:
    """Fallback aliveness heuristics for non-Windows ping output."""
    if sys.platform.startswith("win"):
        return False
    return "1 received" in low_output or "1 packets received" in low_output


def ping_sweep(cidr: str, workers: int = 64, timeout_ms: int = 500,
               include_network_broadcast: bool = False,
               progress_cb=None) -> SweepResult:
    """
    Sweep an entire CIDR in parallel. `progress_cb(done, total, found)` is
    invoked opportunistically for UI progress bars.
    """
    started = time.time()
    result = SweepResult(subnet=cidr)
    try:
        net = ipaddress.ip_network(cidr, strict=False)
    except ValueError:
        result.arp_entries = arp_table()
        return result

    hosts: List[str] = []
    if net.num_addresses <= 2:
        hosts = [str(net.network_address)]
    elif include_network_broadcast:
        hosts = [str(h) for h in net.hosts()]
    else:
        hosts = [str(h) for h in net.hosts()]
    if len(hosts) > 4096:
        hosts = hosts[:4096]

    result.scanned = len(hosts)
    done = 0
    lock_free_counter = {"done": 0}

    def _probe(ip: str) -> PingResult:
        return ping(ip, timeout_ms=timeout_ms)

    with concurrent.futures.ThreadPoolExecutor(max_workers=workers) as pool:
        futures = {pool.submit(_probe, ip): ip for ip in hosts}
        for future in concurrent.futures.as_completed(futures):
            pr = future.result()
            done += 1
            lock_free_counter["done"] = done
            if pr.alive:
                result.alive += 1
                result.results.append(pr)
            if progress_cb and (done % 8 == 0 or done == len(hosts)):
                progress_cb(done, len(hosts), result.alive)

    # Harvest the ARP table AFTER the sweep so the OS has fresh entries.
    result.arp_entries = arp_table()
    # Some devices never answer ICMP but still appear in ARP — include them.
    seen_ips = {r.ip for r in result.results}
    for ip, mac in result.arp_entries.items():
        try:
            if ipaddress.ip_address(ip) in net and ip not in seen_ips:
                result.results.append(PingResult(ip=ip, alive=True))
                result.alive += 1
        except ValueError:
            continue

    result.duration_ms = int((time.time() - started) * 1000)
    return result


# ---------------------------------------------------------------------------
# ARP table harvesting
# ---------------------------------------------------------------------------

_ARP_LINE_RE = re.compile(
    r"(\d{1,3}(?:\.\d{1,3}){3})\s+([0-9a-fA-F]{2}(?:[:-][0-9a-fA-F]{2}){5})"
)


def normalize_mac(raw: str) -> str:
    """Return a MAC in canonical aa:bb:cc:dd:ee:ff form, or ''."""
    hex_digits = re.sub(r"[^0-9a-fA-F]", "", raw or "")
    if len(hex_digits) != 12:
        return ""
    return ":".join(hex_digits[i:i + 2].lower() for i in range(0, 12, 2))


def arp_table() -> Dict[str, str]:
    """Parse the system ARP cache into {ip: normalized_mac}."""
    out = _run(["arp", "-a"])
    table: Dict[str, str] = {}
    for line in out.splitlines():
        m = _ARP_LINE_RE.search(line)
        if not m:
            continue
        ip = m.group(1)
        mac = normalize_mac(m.group(2))
        if not mac:
            continue
        if mac == "ff:ff:ff:ff:ff:ff":
            continue
        if mac.startswith(("01:00:5e", "33:33")):  # multicast neighbors
            continue
        table[ip] = mac
    return table


def arp_lookup(ip: str) -> Optional[str]:
    """Force-populate then read one ARP entry (pings if needed)."""
    table = arp_table()
    if ip in table:
        return table[ip]
    ping(ip, timeout_ms=300)
    return arp_table().get(ip)


# ---------------------------------------------------------------------------
# Misc utilities used across the engine
# ---------------------------------------------------------------------------


def reverse_dns(ip: str, timeout: float = 1.2) -> Optional[str]:
    """Reverse-DNS lookup with a hard timeout (runs in a worker thread)."""
    import threading

    result: Dict[str, Optional[str]] = {"name": None}

    def _work():
        try:
            result["name"] = socket.gethostbyaddr(ip)[0]
        except (socket.herror, socket.gaierror, OSError):
            result["name"] = None

    t = threading.Thread(target=_work, daemon=True)
    t.start()
    t.join(timeout)
    return result["name"]


def tcp_reachable(ip: str, port: int, timeout: float = 0.6) -> bool:
    """Quick TCP connect check used by fingerprinters."""
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.settimeout(timeout)
            return s.connect_ex((ip, port)) == 0
    except OSError:
        return False


def host_bits(cidr: str) -> int:
    try:
        return ipaddress.ip_network(cidr, strict=False).num_addresses
    except ValueError:
        return 0


def env_summary() -> dict:
    """Diagnostics for the About / Debug pane."""
    return {
        "platform": platform.platform(),
        "python": platform.python_version(),
        "os_user": os.environ.get("USERNAME") or os.environ.get("USER", "unknown"),
        "hostname": socket.gethostname(),
        "is_windows": IS_WINDOWS,
        "is_macos": IS_MACOS,
    }
