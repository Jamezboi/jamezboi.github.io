"""
core/vulnscan.py — Defensive security audit engine.

SCOPE AND ETHICS
----------------
Every check in this module is designed to be NON-INVASIVE and safe to run
against your own equipment: it reads banners, checks port exposure,
inspects TLS parameters and HTTP headers, and (only if explicitly enabled)
verifies that admin interfaces do NOT still ship with factory credentials.

Nothing here deploys payloads, corrupts state, or exploits a service. The
goal is to answer one question for a home/lab owner: "which of my devices
would an attacker find an easy target?"

Checks
------
1. risky_ports      — dangerous services exposed (Telnet, TR-069, ADB...)
2. banner_advisories— old product versions matched against a public-CVE hint list
3. tls_weak         — legacy TLS / weak ciphers accepted
4. http_headers     — missing baseline security headers on web UIs
5. admin_exposed    — unauthenticated admin interfaces
6. default_creds    — factory-credential audit (opt-in, 4 classic combos,
                      HTTP Basic only, your own network only)
7. upnp_exposed     — router UPnP WAN services reachable
8. smb_exposed      — SMB reachable from the LAN (EternalBlue surface)
9. printer_raw      — raw printing port exposed
10. iot_plain_buses — MQTT/Modbus listening without TLS

The audit produces a 0–100 security score plus prioritized remediations.
"""

from __future__ import annotations

import base64
import concurrent.futures
import time
import urllib.request
from dataclasses import dataclass, field, asdict
from typing import Dict, List, Optional

from . import portscan
from .fingerprint import probe_http

# ---------------------------------------------------------------------------
# Findings
# ---------------------------------------------------------------------------

SEVERITY_ORDER = {"info": 0, "low": 1, "medium": 2, "high": 3, "critical": 4}
SEVERITY_WEIGHT = {"info": 1, "low": 4, "medium": 9, "high": 16, "critical": 27}


@dataclass
class Finding:
    check_id: str
    title: str
    severity: str          # info|low|medium|high|critical
    description: str
    remediation: str
    evidence: str = ""
    cve_refs: List[str] = field(default_factory=list)

    def to_dict(self) -> dict:
        return asdict(self)


@dataclass
class AuditReport:
    ip: str
    started_at: float = 0.0
    duration_ms: int = 0
    score: int = 100
    grade: str = "A"
    findings: List[Finding] = field(default_factory=list)
    passed: List[str] = field(default_factory=list)

    def to_dict(self) -> dict:
        return {
            "ip": self.ip,
            "started_at": self.started_at,
            "duration_ms": self.duration_ms,
            "score": self.score,
            "grade": self.grade,
            "findings": [f.to_dict() for f in sorted(
                self.findings, key=lambda f: SEVERITY_ORDER.get(f.severity, 0),
                reverse=True)],
            "passed": self.passed,
        }


def grade_for_score(score: int) -> str:
    if score >= 90:
        return "A"
    if score >= 75:
        return "B"
    if score >= 60:
        return "C"
    if score >= 40:
        return "D"
    return "F"


# ---------------------------------------------------------------------------
# Advisory knowledge base — banner substring -> public issue reference.
# Purely informational version heuristics; no exploitation is performed.
# ---------------------------------------------------------------------------

BANNER_ADVISORIES = [
    {"match": "boa/0.9", "id": "Boa discontinued", "refs": ["CVE-2017-9833"],
     "sev": "high",
     "summary": "Boa web server (2005-era) — discontinued, unpatched memory-safety issues; common on old routers/cameras.",
     "fix": "Replace the device or isolate it on a guest VLAN."},
    {"match": "thttpd/2.25b", "id": "thttpd 2.25b", "refs": ["CVE-2012-5640"],
     "sev": "medium", "summary": "Old thttpd build with known DoS issues.",
     "fix": "Check for firmware updates; retire if unsupported."},
    {"match": "goahead", "id": "GoAhead old build", "refs": ["CVE-2017-3185", "CVE-2021-42342"],
     "sev": "medium", "summary": "GoAhead embedded server — multiple historical CVEs depend on exact version.",
     "fix": "Confirm vendor firmware version and update."},
    {"match": "mini_httpd", "id": "mini_httpd", "refs": ["CVE-2018-18778"],
     "sev": "medium", "summary": "mini_httpd builds have a null-deref DoS.",
     "fix": "Update firmware."},
    {"match": "apache/2.2", "id": "Apache 2.2 (EOL)", "refs": ["CVE-2019-0211"],
     "sev": "high", "summary": "Apache 2.2 reached end-of-life in 2017 — no security patches since.",
     "fix": "Migrate to a supported Apache/httpd release."},
    {"match": "apache/1.", "id": "Apache 1.3 (ancient)", "refs": [],
     "sev": "high", "summary": "Apache 1.3 — unsupported this century.",
     "fix": "Retire or isolate the service."},
    {"match": "nginx/0.", "id": "nginx 0.x", "refs": ["CVE-2009-2629"],
     "sev": "high", "summary": "nginx 0.x is ancient; numerous known issues.",
     "fix": "Upgrade to a current nginx stable."},
    {"match": "lighttpd/1.4.3", "id": "lighttpd 1.4.3x", "refs": ["CVE-2018-19052"],
     "sev": "low", "summary": "Older lighttpd 1.4.x line; verify against release notes.",
     "fix": "Update lighttpd."},
    {"match": "openssh_3", "id": "OpenSSH 3.x", "refs": ["CVE-2003-0693"],
     "sev": "high", "summary": "OpenSSH 3.x is from 2002–2003 and predates modern crypto.",
     "fix": "Upgrade the host or firmware."},
    {"match": "openssh_4", "id": "OpenSSH 4.x", "refs": ["CVE-2008-0166"],
     "sev": "medium", "summary": "OpenSSH 4.x — weak key generation era (Debian debacle family).",
     "fix": "Upgrade OpenSSH."},
    {"match": "proftpd 1.2", "id": "ProFTPD 1.2", "refs": ["CVE-2009-3269"],
     "sev": "high", "summary": "ProFTPD 1.2 stack overflow history.",
     "fix": "Upgrade ProFTPD."},
    {"match": "vsftpd 1.", "id": "vsftpd 1.x", "refs": [],
     "sev": "low", "summary": "Very old vsftpd.",
     "fix": "Upgrade vsftpd."},
    {"match": "mikrotik", "id": "MikroTik RouterOS", "refs": ["CVE-2018-14847"],
     "sev": "medium", "summary": "RouterOS versions < 6.40.8 / 6.42 have Winbox directory traversal (CVE-2018-14847).",
     "fix": "Update RouterOS to the current stable."},
]

# Factory credential combos for the opt-in audit. Deliberately tiny and
# read-only: authenticate, note success/failure, disconnect.
DEFAULT_CREDENTIAL_SETS = [
    ("admin", "admin"), ("admin", "password"), ("admin", ""),
    ("root", "root"), ("user", "user"),
]

# Ports whose mere openness is a finding on a HOME network.
RISKY_PORT_FINDINGS = {
    23: ("high", "Telnet service exposed", "Close Telnet; use SSH."),
    2323: ("critical", "Telnet on alternate port 2323", "Typical IoT compromise indicator. Investigate immediately."),
    21: ("medium", "FTP service exposed", "Replace with SFTP/SCP if possible."),
    69: ("high", "TFTP exposed", "Disable TFTP unless specifically required."),
    445: ("medium", "SMB file sharing reachable", "SMB is the EternalBlue (CVE-2017-0144) attack surface; restrict to trusted devices."),
    139: ("medium", "NetBIOS session service reachable", "Disable legacy NetBIOS if unused."),
    3389: ("low", "Remote Desktop reachable", "Enable NLA and strong passwords."),
    5900: ("medium", "VNC remote screen reachable", "VNC often ships with weak/absent auth."),
    7547: ("critical", "TR-069 CWMP management port open", "The port Mirai used to brick 900k Deutsche Telekom routers. Should never face the LAN edge."),
    5555: ("critical", "Android ADB port open", "Full device control with no auth (CVE-2017-13182 family / ADB.Miner)."),
    8291: ("critical", "MikroTik Winbox port open", "CVE-2018-14847 credential extraction on unpatched RouterOS."),
    2375: ("critical", "Docker API without TLS", "Unauthenticated root-level container control."),
    6379: ("high", "Redis reachable", "Redis with no AUTH = arbitrary file write as service user."),
    27017: ("high", "MongoDB reachable", "Verify auth is on (historic ransomware campaigns)."),
    11211: ("high", "Memcached reachable", "UDP amplification source (CVE-2018-1000115)."),
    502: ("medium", "Modbus industrial protocol exposed", "No authentication in the protocol; isolate on a dedicated VLAN."),
    1883: ("medium", "MQTT broker without TLS", "Smart-home bus often left unauthenticated."),
    1433: ("medium", "MSSQL exposed", "Move behind a firewall rule if unused."),
    3306: ("medium", "MySQL exposed", "Bind to localhost if only local apps use it."),
    5432: ("medium", "PostgreSQL exposed", "Verify pg_hba.conf restricts sources."),
    2049: ("high", "NFS exposed", "Export lists frequently over-permissive."),
    10000: ("low", "Webmin panel exposed", "Keep updated (CVE-2019-15107 precedent)."),
    9100: ("info", "Raw printer port", "Anyone on the LAN can print; usually acceptable at home."),
}


# ---------------------------------------------------------------------------
# Individual checks
# ---------------------------------------------------------------------------


def check_risky_ports(report: AuditReport, ports: List[dict]) -> None:
    seen: set = set()
    for p in ports:
        port = p["port"]
        if not p.get("open") or port not in RISKY_PORT_FINDINGS or port in seen:
            continue
        seen.add(port)
        severity, title, fix = RISKY_PORT_FINDINGS[port]
        report.findings.append(Finding(
            check_id=f"port:{port}", title=title, severity=severity,
            description=f"Port {port} is open ({p.get('service') or 'unknown service'}): {title.lower()}.",
            remediation=fix,
            evidence=f"TCP {port}/open ({p.get('service', '')})"))
    if not seen:
        report.passed.append("No high-risk service ports exposed")


def check_banner_advisories(report: AuditReport, ports: List[dict]) -> None:
    matched = False
    for p in ports:
        banner = (p.get("banner") or "").lower()
        if not banner:
            continue
        for advisory in BANNER_ADVISORIES:
            if advisory["match"] in banner:
                matched = True
                report.findings.append(Finding(
                    check_id=f"banner:{advisory['id']}", title=advisory["id"],
                    severity=advisory["sev"], description=advisory["summary"],
                    remediation=advisory["fix"],
                    evidence=(p.get("banner") or "")[:200],
                    cve_refs=advisory["refs"]))
    if not matched:
        report.passed.append("No end-of-life software banners detected")


def check_tls_weak(report: AuditReport, ip: str, ports: List[dict]) -> None:
    tls_ports = [p for p in ports if p.get("open") and p["port"] in
                 (443, 8443, 9443, 5001, 4443)]
    if not tls_ports:
        return
    import ssl
    import socket
    for entry in tls_ports:
        version = ""
        cipher_name = ""
        try:
            ctx = ssl.SSLContext(ssl.PROTOCOL_TLS_CLIENT)
            ctx.check_hostname = False
            ctx.verify_mode = ssl.CERT_NONE
            ctx.set_ciphers("DEFAULT:LOW@SECLEVEL=0")
            with socket.create_connection((ip, entry["port"]), timeout=3.0) as raw:
                with ctx.wrap_socket(raw) as tls_sock:
                    version = tls_sock.version() or ""
                    cipher = tls_sock.cipher()
                    cipher_name = cipher[0] if cipher else ""
        except Exception:
            continue
        if version in ("TLSv1", "SSLv3"):
            report.findings.append(Finding(
                check_id=f"tls:{entry['port']}", severity="high",
                title=f"Legacy protocol {version} accepted on port {entry['port']}",
                description="TLS 1.0/SSLv3 are deprecated (POODLE-era) and fail every modern compliance baseline.",
                remediation="Enforce TLS 1.2+ on the device admin interface."))
        elif version == "TLSv1.1":
            report.findings.append(Finding(
                check_id=f"tls:{entry['port']}", severity="medium",
                title=f"TLS 1.1 accepted on port {entry['port']}",
                description="TLS 1.1 is deprecated since 2020.",
                remediation="Disable TLS 1.0/1.1 in device settings."))
        elif "3des" in cipher_name.lower() or "rc4" in cipher_name.lower() or "null" in cipher_name.lower():
            report.findings.append(Finding(
                check_id=f"tls:{entry['port']}", severity="high",
                title=f"Weak cipher {cipher_name} negotiated",
                description="Legacy bulk cipher negotiated — session confidentiality is effectively broken.",
                remediation="Update firmware or disable legacy cipher suites."))
    if not any(f.check_id.startswith("tls:") for f in report.findings):
        report.passed.append("TLS configuration looks modern")


_BASELINE_HEADERS = ("x-frame-options", "x-content-type-options",
                     "content-security-policy")


def check_http_headers(report: AuditReport, http_info: Optional[dict]) -> None:
    if not http_info or http_info.get("status") != 200:
        return
    missing = [h for h in _BASELINE_HEADERS if h not in (http_info.get("headers") or {})]
    if missing:
        report.findings.append(Finding(
            check_id="http:headers", severity="low",
            title="Web UI missing security headers",
            description=f"Baseline hardening headers absent: {', '.join(missing)}. "
                        "Low impact on a LAN appliance but flagged for completeness.",
            remediation="Enable hardened headers if the firmware allows; otherwise accept the risk."))


def check_admin_exposed(report: AuditReport, admin_info: Optional[dict]) -> None:
    if not admin_info:
        return
    if admin_info.get("status") == 200 and admin_info.get("www_authenticate") == "":
        # A control page that loads with zero authentication.
        suspicious_words = ("admin", "config", "setup", "manage", "login", "gateway")
        blob = f"{admin_info.get('title', '')} {admin_info.get('url', '')}".lower()
        if any(w in blob for w in suspicious_words):
            report.findings.append(Finding(
                check_id="admin:open", severity="high",
                title="Admin-style page loads without authentication",
                description=f"'{admin_info.get('title', admin_info['url'])}' responded 200 with no auth challenge.",
                remediation="Enable password protection on this interface.",
                evidence=admin_info.get("url", "")))


def check_default_credentials(report: AuditReport, ip: str, ports: List[dict],
                              enabled: bool) -> None:
    """
    Opt-in factory-credential audit.
    * Attempts at most the five classic read-only combos.
    * HTTP Basic auth endpoints only.
    * Success is recorded as a finding; nothing else is done with the session.
    """
    if not enabled:
        return
    http_ports = [p["port"] for p in ports
                  if p.get("open") and p["port"] in (80, 443, 8080, 8443)]
    for port in http_ports:
        scheme = "https" if port in (443, 8443) else "http"
        url = f"{scheme}://{ip}:{port}/"
        realm_protected = False
        try:
            req = urllib.request.Request(url, headers={"User-Agent": "AetherScan-audit"})
            urllib.request.urlopen(req, timeout=2.5)
        except urllib.request.HTTPError as exc:
            if exc.code == 401 and "basic" in (exc.headers.get("WWW-Authenticate") or "").lower():
                realm_protected = True
        except Exception:
            continue
        if not realm_protected:
            continue
        for username, password in DEFAULT_CREDENTIAL_SETS:
            token = base64.b64encode(f"{username}:{password}".encode()).decode()
            try:
                req = urllib.request.Request(
                    url, headers={"User-Agent": "AetherScan-audit",
                                  "Authorization": f"Basic {token}"})
                with urllib.request.urlopen(req, timeout=2.5) as resp:
                    if resp.status == 200:
                        report.findings.append(Finding(
                            check_id="creds:default", severity="critical",
                            title=f"Factory credentials active: {username}/{password or '(blank)'}",
                            description="The admin interface accepts a well-known default username/password pair. "
                                        "This is the #1 way consumer devices get hijacked.",
                            remediation="Set a unique administrator password immediately.",
                            evidence=url))
                        return
            except Exception:
                continue
        report.passed.append("Basic-auth admin interface does not accept factory credentials")


def check_upnp_exposed(report: AuditReport, upnp_desc: Optional[dict]) -> None:
    if not upnp_desc:
        return
    desc = upnp_desc.get("description") or {}
    device_type = (desc.get("device_type") or "").lower()
    if "wanipconnection" in device_type or "wandevice" in device_type:
        report.findings.append(Finding(
            check_id="upnp:wan", severity="medium",
            title="Router exposes UPnP WAN connection service",
            description="UPnP lets any LAN device open inbound firewall ports automatically. "
                        "Mirai-family worms enumerate exactly this service.",
            remediation="Disable UPnP on the router unless a game console needs it."))


def check_plain_iot_buses(report: AuditReport, ports: List[dict]) -> None:
    open_map = {p["port"] for p in ports if p.get("open")}
    if 1883 in open_map and 8883 not in open_map:
        report.findings.append(Finding(
            check_id="bus:mqtt", severity="medium",
            title="MQTT broker listening without TLS companion",
            description="Port 1883 (plaintext MQTT) is open with no 8883 (MQTT-over-TLS). "
                        "Many brokers also ship with anonymous access.",
            remediation="Enable broker authentication + TLS, or bind to localhost."))
    if 502 in open_map:
        report.passed.append("Modbus presence recorded (see port finding)")


# ---------------------------------------------------------------------------
# Engine
# ---------------------------------------------------------------------------


class SecurityAuditor:
    """Runs the full non-invasive battery against one device."""

    def __init__(self, config: Optional[dict] = None):
        config = config or {}
        self.timeout = config.get("audit_timeout", 3.0)
        self.credential_audit = bool(config.get("credential_audit", False))

    def audit_device(self, ip: str, ports: Optional[List[dict]] = None,
                     upnp_desc: Optional[dict] = None) -> AuditReport:
        started = time.time()
        report = AuditReport(ip=ip, started_at=started)

        if ports is None:
            ports = []
        open_ports = [p for p in ports if p.get("open")]

        # Discovery-side probes (parallelized).
        http_info: Dict[str, Optional[dict]] = {"web": None, "admin": None,
                                                "headers": {}}

        def _web():
            for port, tls in ((80, False), (443, True)):
                info = probe_http(ip, port=port, use_tls=tls, timeout=self.timeout)
                if info:
                    http_info["web"] = info
                    http_info["headers"] = {k: v for k, v in info.items()}
                    return

        with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
            web_future = pool.submit(_web)
            web_future.result(timeout=self.timeout * 3 + 2)

        # Merge info the caller already gathered (fingerprint stage).
        if upnp_desc:
            desc = upnp_desc.get("description") if isinstance(upnp_desc, dict) else None
            check_upnp_exposed(report, {"description": desc} if desc else None)

        check_risky_ports(report, open_ports)
        check_banner_advisories(report, open_ports)
        check_tls_weak(report, ip, open_ports)
        check_http_headers(report, _headers_view(http_info["web"]))
        check_admin_exposed(report, http_info["web"])
        check_default_credentials(report, ip, open_ports, self.credential_audit)
        check_plain_iot_buses(report, open_ports)

        report.score = _score(report)
        report.grade = grade_for_score(report.score)
        report.duration_ms = int((time.time() - started) * 1000)
        return report

    def quick_exposure_check(self, ip: str) -> AuditReport:
        """Score-only fast path: scan top risky ports, no banners."""
        scanner = portscan.PortScanner(timeout=0.8, workers=64)
        result = scanner.scan(ip, ports=[p for p in RISKY_PORT_FINDINGS],
                              profile="quick", grab_banners=False)
        report = AuditReport(ip=ip, started_at=time.time())
        check_risky_ports(report, [p.to_dict() for p in result.open_ports])
        report.score = _score(report)
        report.grade = grade_for_score(report.score)
        report.duration_ms = result.duration_ms
        return report


def _headers_view(http_info: Optional[dict]) -> Optional[dict]:
    """fingerprint.probe_http returns flat keys; adapt for header check."""
    if not http_info:
        return None
    return {
        "status": http_info.get("status"),
        "headers": {
            "x-frame-options": http_info.get("x-frame-options", ""),
            "x-content-type-options": http_info.get("x-content-type-options", ""),
            "content-security-policy": http_info.get("content-security-policy", ""),
        },
    }


def _score(report: AuditReport) -> int:
    penalty = sum(SEVERITY_WEIGHT.get(f.severity, 0) for f in report.findings)
    # A little forgiveness: two lows shouldn't sink an otherwise clean device.
    penalty = max(0, penalty - min(penalty, 3))
    return max(0, 100 - penalty)


def network_summary(reports: List[AuditReport]) -> dict:
    """Aggregate view for the Security Center dashboard."""
    if not reports:
        return {"devices_audited": 0, "average_score": 100, "grade": "A",
                "counts": {sev: 0 for sev in SEVERITY_ORDER},
                "worst_devices": []}
    total_findings = {sev: 0 for sev in SEVERITY_ORDER}
    for rep in reports:
        for f in rep.findings:
            total_findings[f.severity] = total_findings.get(f.severity, 0) + 1
    avg = sum(r.score for r in reports) // len(reports)
    worst = sorted(reports, key=lambda r: r.score)[:5]
    return {
        "devices_audited": len(reports),
        "average_score": avg,
        "grade": grade_for_score(avg),
        "counts": total_findings,
        "worst_devices": [{"ip": r.ip, "score": r.score, "grade": r.grade,
                           "top": [f.title for f in r.findings[:3]]} for r in worst],
    }
