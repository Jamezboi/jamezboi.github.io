"""
core/portscan.py — Threaded TCP port scanner with service intelligence.

* Connect-scan (fully portable, no raw sockets, no admin rights).
* Three profiles: QUICK (top 40), STANDARD (top 100), DEEP (top 250).
* Each open port is matched against the service registry, which carries
  protocol name, risk weight and a human-readable description — the same
  registry powers the security auditor.
* Banners are grabbed with protocol-aware probes (HTTP HEAD, TLS ClientHello
  via ssl, plain listen for SMTP/FTP/SSH-style greeting services).
"""

from __future__ import annotations

import concurrent.futures
import socket
import ssl
import time
from dataclasses import dataclass, field
from typing import Callable, Dict, List, Optional

# ---------------------------------------------------------------------------
# Service registry — port metadata shared by scanner + security auditor
# ---------------------------------------------------------------------------
# risk: 0 = informational, 1 = low, 2 = medium, 3 = high, 4 = critical

SERVICE_REGISTRY: Dict[int, dict] = {
    20: {"name": "ftp-data", "proto": "FTP", "risk": 1, "desc": "File transfer (data channel)"},
    21: {"name": "ftp", "proto": "FTP", "risk": 2, "desc": "File transfer — often anonymous or legacy"},
    22: {"name": "ssh", "proto": "SSH", "risk": 0, "desc": "Secure shell remote administration"},
    23: {"name": "telnet", "proto": "Telnet", "risk": 4, "desc": "Unencrypted remote shell — Mirai-class botnets scan for this"},
    25: {"name": "smtp", "proto": "SMTP", "risk": 1, "desc": "Mail transfer"},
    53: {"name": "domain", "proto": "DNS", "risk": 0, "desc": "DNS resolver (common on routers)"},
    69: {"name": "tftp", "proto": "TFTP", "risk": 3, "desc": "Trivial FTP — no authentication"},
    80: {"name": "http", "proto": "HTTP", "risk": 0, "desc": "Web interface"},
    81: {"name": "http-alt", "proto": "HTTP", "risk": 1, "desc": "Alternate web interface"},
    88: {"name": "kerberos", "proto": "Kerberos", "risk": 0, "desc": "Authentication service"},
    110: {"name": "pop3", "proto": "POP3", "risk": 1, "desc": "Mail retrieval (cleartext capable)"},
    111: {"name": "rpcbind", "proto": "RPC", "risk": 2, "desc": "ONC RPC portmapper"},
    123: {"name": "ntp", "proto": "NTP", "risk": 0, "desc": "Network time"},
    135: {"name": "msrpc", "proto": "MSRPC", "risk": 2, "desc": "Windows RPC endpoint mapper"},
    139: {"name": "netbios-ssn", "proto": "NetBIOS", "risk": 3, "desc": "Legacy Windows file sharing"},
    143: {"name": "imap", "proto": "IMAP", "risk": 1, "desc": "Mail retrieval"},
    161: {"name": "snmp", "proto": "SNMP", "risk": 2, "desc": "Device management (UDP; detected via banner heuristics)"},
    389: {"name": "ldap", "proto": "LDAP", "risk": 1, "desc": "Directory service"},
    443: {"name": "https", "proto": "HTTPS", "risk": 0, "desc": "Secure web interface"},
    445: {"name": "microsoft-ds", "proto": "SMB", "risk": 3, "desc": "Windows file/printer sharing"},
    465: {"name": "smtps", "proto": "SMTPS", "risk": 0, "desc": "Mail over TLS"},
    500: {"name": "isakmp", "proto": "VPN", "risk": 1, "desc": "IPsec VPN key exchange"},
    514: {"name": "syslog", "proto": "Syslog", "risk": 0, "desc": "Log shipping"},
    515: {"name": "printer", "proto": "LPD", "risk": 1, "desc": "Printer spooler"},
    548: {"name": "afp", "proto": "AFP", "risk": 1, "desc": "AppleShare file sharing"},
    554: {"name": "rtsp", "proto": "RTSP", "risk": 1, "desc": "Camera/media streaming control"},
    587: {"name": "submission", "proto": "SMTP", "risk": 0, "desc": "Mail submission"},
    631: {"name": "ipp", "proto": "IPP", "risk": 1, "desc": "Internet printing"},
    636: {"name": "ldaps", "proto": "LDAPS", "risk": 0, "desc": "Directory over TLS"},
    873: {"name": "rsync", "proto": "rsync", "risk": 2, "desc": "File sync — sometimes unauthenticated"},
    993: {"name": "imaps", "proto": "IMAPS", "risk": 0, "desc": "Mail over TLS"},
    995: {"name": "pop3s", "proto": "POP3S", "risk": 0, "desc": "Mail over TLS"},
    1080: {"name": "socks", "proto": "SOCKS", "risk": 2, "desc": "Proxy"},
    1433: {"name": "mssql", "proto": "MSSQL", "risk": 2, "desc": "Microsoft SQL Server"},
    1521: {"name": "oracle", "proto": "Oracle DB", "risk": 2, "desc": "Oracle database"},
    1883: {"name": "mqtt", "proto": "MQTT", "risk": 2, "desc": "IoT message bus — frequently unauthenticated"},
    1900: {"name": "upnp", "proto": "UPnP", "risk": 2, "desc": "SSDP / UPnP discovery"},
    2049: {"name": "nfs", "proto": "NFS", "risk": 3, "desc": "Network file system"},
    2323: {"name": "telnet-alt", "proto": "Telnet", "risk": 4, "desc": "Telnet on alternate port (IoT backdoor favorite)"},
    2375: {"name": "docker", "proto": "Docker API", "risk": 4, "desc": "Docker daemon WITHOUT TLS"},
    2376: {"name": "docker-tls", "proto": "Docker API", "risk": 1, "desc": "Docker daemon over TLS"},
    2883: {"name": "ward", "proto": "Wardriver", "risk": 3, "desc": "Ward-type IoT management"},
    3000: {"name": "node-dev", "proto": "HTTP", "risk": 1, "desc": "Node/Grafana-style dev web app"},
    3128: {"name": "squid", "proto": "Proxy", "risk": 2, "desc": "Squid cache/proxy"},
    32400: {"name": "plex", "proto": "Plex", "risk": 0, "desc": "Plex media server"},
    3306: {"name": "mysql", "proto": "MySQL", "risk": 2, "desc": "MySQL database"},
    3389: {"name": "rdp", "proto": "RDP", "risk": 2, "desc": "Windows remote desktop"},
    4444: {"name": "tor-oracle", "proto": "Unknown", "risk": 3, "desc": "Common exploit payload port"},
    4840: {"name": "opcua", "proto": "OPC-UA", "risk": 1, "desc": "Industrial automation"},
    5000: {"name": "upnp-alt", "proto": "HTTP", "risk": 1, "desc": "Router admin / UPnP (common on routers & Synology)"},
    5001: {"name": "synology", "proto": "HTTPS", "risk": 1, "desc": "Synology DSM"},
    502: {"name": "modbus", "proto": "Modbus", "risk": 3, "desc": "Industrial PLC protocol — no auth by design"},
    5060: {"name": "sip", "proto": "SIP", "risk": 1, "desc": "VoIP signaling"},
    51826: {"name": "hue", "proto": "Philips Hue", "risk": 0, "desc": "Hue bridge API"},
    5353: {"name": "mdns", "proto": "mDNS", "risk": 0, "desc": "Bonjour/zeroconf"},
    5432: {"name": "postgres", "proto": "PostgreSQL", "risk": 2, "desc": "PostgreSQL database"},
    5555: {"name": "adb", "proto": "Android ADB", "risk": 4, "desc": "Android debug bridge open to the network"},
    5900: {"name": "vnc-0", "proto": "VNC", "risk": 3, "desc": "VNC remote screen"},
    5901: {"name": "vnc-1", "proto": "VNC", "risk": 3, "desc": "VNC remote screen (display :1)"},
    5984: {"name": "couchdb", "proto": "CouchDB", "risk": 2, "desc": "CouchDB HTTP API"},
    6379: {"name": "redis", "proto": "Redis", "risk": 3, "desc": "Redis — often no auth on LAN"},
    6443: {"name": "k8s", "proto": "Kubernetes", "risk": 2, "desc": "Kubernetes API"},
    6667: {"name": "irc", "proto": "IRC", "risk": 2, "desc": "IRC (also Mirai C2)"},
    7547: {"name": "tr069", "proto": "TR-069", "risk": 4, "desc": "ISP router management — Mirai's favorite target"},
    8000: {"name": "http-alt2", "proto": "HTTP", "risk": 1, "desc": "Alternate web (cameras, Python apps)"},
    8006: {"name": "proxmox", "proto": "Proxmox", "risk": 1, "desc": "Proxmox VE web UI"},
    8008: {"name": "http-alt3", "proto": "HTTP", "risk": 1, "desc": "Alternate web"},
    8009: {"name": "ajp13", "proto": "AJP", "risk": 2, "desc": "Tomcat AJP (Ghostcat family)"},
    8080: {"name": "http-proxy", "proto": "HTTP", "risk": 1, "desc": "Alternate web / admin interface"},
    8081: {"name": "http-alt4", "proto": "HTTP", "risk": 1, "desc": "Alternate web"},
    8123: {"name": "hass", "proto": "Home Assistant", "risk": 1, "desc": "Home Assistant API"},
    8291: {"name": "winbox", "proto": "MikroTik", "risk": 4, "desc": "MikroTik Winbox — CVE-2018-14847 territory"},
    8443: {"name": "https-alt", "proto": "HTTPS", "risk": 1, "desc": "Alternate HTTPS admin"},
    8883: {"name": "mqtt-tls", "proto": "MQTT", "risk": 0, "desc": "MQTT over TLS"},
    9000: {"name": "sonarr?", "proto": "HTTP", "risk": 1, "desc": "Alternate web / Portainer"},
    9001: {"name": "torque", "proto": "HTTP", "risk": 1, "desc": "Supervisor / CSFLE"},
    9090: {"name": "websm", "proto": "HTTP", "risk": 1, "desc": "OpenFire / Cockpit"},
    9100: {"name": "jetdirect", "proto": "Printing", "risk": 1, "desc": "Raw printer port"},
    9999: {"name": "distinct", "proto": "Unknown", "risk": 1, "desc": "Various admin panels"},
    10000: {"name": "webmin", "proto": "Webmin", "risk": 2, "desc": "Webmin / Virtualmin"},
    11211: {"name": "memcache", "proto": "Memcached", "risk": 3, "desc": "Memcached UDP amplification"},
    27017: {"name": "mongodb", "proto": "MongoDB", "risk": 3, "desc": "MongoDB — historical ransomware target"},
    49152: {"name": "upnp-1", "proto": "UPnP", "risk": 1, "desc": "UPnP device service"},
    49153: {"name": "upnp-2", "proto": "UPnP", "risk": 1, "desc": "UPnP device service"},
    49154: {"name": "upnp-3", "proto": "UPnP", "risk": 1, "desc": "UPnP device service"},
}

QUICK_PORTS = [80, 443, 22, 23, 445, 139, 3389, 8080, 53, 7547, 5555, 8291,
               5900, 1900, 5000, 8443, 21, 25, 110, 135, 5353, 161, 631, 9100, 1433,
               3306, 5432, 6379, 27017, 1883, 2323, 502, 8006, 32400, 8888, 8883,
               49152, 49153, 49154, 10000]

STANDARD_PORTS = sorted(set(QUICK_PORTS + [
    88, 111, 123, 389, 465, 514, 515, 548, 554, 587, 636, 873, 993, 995, 1080,
    1521, 2049, 2375, 2376, 3000, 3128, 4444, 4840, 5060, 5061, 51826, 5984,
    6443, 6667, 8000, 8008, 8009, 8081, 8123, 9000, 9001, 9090, 9999, 11211,
    1900, 81, 8899, 7070, 8010, 8222, 9418, 25565, 25575, 3478, 5349, 6881,
]))

DEEP_PORTS = sorted(set(STANDARD_PORTS + list(range(1, 1025)) + [
    1080, 1580, 1901, 2082, 2083, 2086, 2095, 2096, 28017, 33060, 4443, 4445,
    5601, 5672, 5800, 5801, 62078, 65024, 8333, 8334, 8444, 8500, 8501, 8686,
    9002, 9003, 9080, 9091, 9200, 9300, 10001, 10050, 10051, 15672, 50000,
]))

PROFILE_PORTS = {
    "quick": QUICK_PORTS,
    "standard": STANDARD_PORTS,
    "deep": DEEP_PORTS,
}


# ---------------------------------------------------------------------------
# Scan results
# ---------------------------------------------------------------------------


@dataclass
class PortResult:
    port: int
    open: bool
    service: str = ""
    protocol: str = ""
    risk: int = 0
    desc: str = ""
    banner: str = ""
    tls: Optional[dict] = None

    def to_dict(self) -> dict:
        return {
            "port": self.port, "open": self.open, "service": self.service,
            "protocol": self.protocol, "risk": self.risk, "desc": self.desc,
            "banner": self.banner, "tls": self.tls,
        }


@dataclass
class PortScanReport:
    ip: str
    profile: str = "standard"
    scanned: int = 0
    open_ports: List[PortResult] = field(default_factory=list)
    duration_ms: int = 0

    def to_dict(self) -> dict:
        return {
            "ip": self.ip, "profile": self.profile, "scanned": self.scanned,
            "duration_ms": self.duration_ms,
            "open_ports": [p.to_dict() for p in self.open_ports],
        }


# ---------------------------------------------------------------------------
# Banner grabbing
# ---------------------------------------------------------------------------

_HTTP_PROBE = ("HEAD / HTTP/1.0\r\nHost: {host}\r\nUser-Agent: AetherScan/1.4\r\n"
               "Accept: */*\r\nConnection: close\r\n\r\n").encode("ascii")


def _grab_banner(ip: str, port: int, timeout: float) -> str:
    """Connect and try to learn what's listening. Never raises."""
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
            sock.settimeout(timeout)
            sock.connect((ip, port))
            try:
                sock.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
            except OSError:
                pass
            is_tls_candidate = port in (443, 8443, 9443, 5001, 8531, 636, 989, 992)
            banner = ""
            if is_tls_candidate:
                banner = _tls_handshake_banner(sock, ip, timeout)
            else:
                # First try listening for a greeting service (SSH, FTP, SMTP...)
                sock.settimeout(min(timeout, 1.2))
                greeting = b""
                try:
                    greeting = sock.recv(256)
                except (socket.timeout, OSError):
                    greeting = b""
                if greeting:
                    banner = greeting.decode("utf-8", "replace").strip()
                else:
                    sock.sendall(_HTTP_PROBE.replace(b"{host}", ip.encode()))
                    sock.settimeout(timeout)
                    try:
                        data = sock.recv(512)
                        banner = data.decode("utf-8", "replace").strip()
                    except (socket.timeout, OSError):
                        banner = ""
            return banner[:400]
    except OSError:
        return ""


def _tls_handshake_banner(sock: socket.socket, ip: str, timeout: float) -> str:
    """Complete a TLS handshake and surface cert + negotiated parameters."""
    try:
        ctx = ssl.create_default_context()
        ctx.check_hostname = False
        ctx.verify_mode = ssl.CERT_NONE
        with ctx.wrap_socket(sock, server_hostname=ip) as tls_sock:
            cert = tls_sock.getpeercert(binary_form=False)
            cipher = tls_sock.cipher()
            version = tls_sock.version()
            parts = [f"tls={version}", f"cipher={cipher[0]}"]
            if cert:
                for element in cert.get("subject", ()):
                    for key, value in element:
                        if key in ("commonName", "organizationName"):
                            parts.append(f"{key}={value}")
                            break
            return " ".join(parts)
    except (OSError, ssl.SSLError):
        return ""


# ---------------------------------------------------------------------------
# Scanner engine
# ---------------------------------------------------------------------------


class PortScanner:
    """Parallel connect scanner. Progress callback: (done, total, open_found)."""

    def __init__(self, timeout: float = 0.7, workers: int = 128):
        self.timeout = timeout
        self.workers = workers

    def scan(self, ip: str, ports: Optional[List[int]] = None,
             profile: str = "standard", grab_banners: bool = True,
             progress_cb: Optional[Callable[[int, int, int], None]] = None
             ) -> PortScanReport:
        started = time.time()
        ports = ports if ports is not None else PROFILE_PORTS.get(profile, STANDARD_PORTS)
        report = PortScanReport(ip=ip, profile=profile, scanned=len(ports))
        open_results: List[PortResult] = []
        state = {"done": 0}

        def _check(port: int) -> Optional[PortResult]:
            if _tcp_open(ip, port, self.timeout):
                return self._describe(ip, port, grab_banners)
            return None

        with concurrent.futures.ThreadPoolExecutor(max_workers=self.workers) as pool:
            futures = [pool.submit(_check, p) for p in ports]
            for future in concurrent.futures.as_completed(futures):
                state["done"] += 1
                result = future.result()
                if result is not None:
                    open_results.append(result)
                if progress_cb and (state["done"] % 25 == 0 or
                                    state["done"] == len(ports)):
                    progress_cb(state["done"], len(ports), len(open_results))

        report.open_ports = sorted(open_results, key=lambda r: r.port)
        report.duration_ms = int((time.time() - started) * 1000)
        return report

    def _describe(self, ip: str, port: int, grab: bool) -> PortResult:
        meta = SERVICE_REGISTRY.get(port, {})
        result = PortResult(
            port=port, open=True,
            service=meta.get("name", "unknown"),
            protocol=meta.get("proto", "TCP"),
            risk=meta.get("risk", 0),
            desc=meta.get("desc", "Unregistered service"),
        )
        if grab:
            result.banner = _grab_banner(ip, port, min(self.timeout * 2, 2.5))
            if result.banner.startswith("tls="):
                result.tls = _parse_tls_banner(result.banner)
        return result


def _tcp_open(ip: str, port: int, timeout: float) -> bool:
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
            sock.settimeout(timeout)
            return sock.connect_ex((ip, port)) == 0
    except OSError:
        return False


def _parse_tls_banner(banner: str) -> Optional[dict]:
    fields = {}
    for chunk in banner.split():
        if "=" in chunk:
            key, _, value = chunk.partition("=")
            fields[key] = value
    return fields or None


def summarize_service(banner: str) -> str:
    """Collapse a raw banner into a friendly product label."""
    if not banner:
        return ""
    head = banner.splitlines()[0][:120] if banner else ""
    low = (banner or "").lower()
    signatures = (
        ("ssh-2.0", "SSH"), ("ssh-1.", "SSH (v1!)"), ("ftp", "FTP"),
        ("smtp", "SMTP"), ("http/1", "HTTP"), ("http/2", "HTTP/2"),
        ("rtsp/", "RTSP camera"), ("upnp/", "UPnP"), ("mqtt", "MQTT"),
        ("redis", "Redis"), ("mysql", "MySQL"), ("postgres", "PostgreSQL"),
        ("mongodb", "MongoDB"), ("vnc", "VNC"), ("rdp", "RDP"),
        ("mikrotik", "MikroTik"), (" smb ", "SMB"),
    )
    for needle, label in signatures:
        if needle in low:
            return label
    return head
