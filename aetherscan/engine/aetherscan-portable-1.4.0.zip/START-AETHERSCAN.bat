@echo off
title AetherScan Engine
start "AetherScan Engine" /D "%~dp0engine" "%~dp0runtime\python.exe" "%~dp0engine\main.py"
