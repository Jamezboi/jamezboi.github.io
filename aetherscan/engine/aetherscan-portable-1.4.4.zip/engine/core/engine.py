"""
core/engine.py — ScanEngine: the conductor that ties discovery,
fingerprinting, port scanning and auditing into one observable pipeline.

Phases (reported to the UI as live progress):
  1. interfaces    — pick/validate the target subnet
  2. sweep         — parallel ICMP ping across the subnet
  3. arp           — harvest MAC addresses from the ARP cache
  4. enrich        — vendor lookup, era estimate, type inference
  5. identify      — reverse DNS / NetBIOS / mDNS / UPnP (premium)
  6. ports         — profile-based TCP scan (premium)
  7. audit         — non-invasive security battery (premium)
  8. persist       — inventory upsert + event log + scan-run stats

The engine is fully cancelable and re-entrant; the API layer simply
forwards engine.progress() to the browser.
"""

from __future__ import annotations

import concurrent.futures
import ipaddress
import threading
import time
from typing import Callable, Dict, List, Optional

from . import fingerprint as fp
from . import macdb, network, portscan, vulnscan
from .devices import Device, DeviceInventory, infer_device_type

# Ports probed across silent hosts during a deep sweep, so devices that
# ignore ICMP still surface in results.
SWEEP_PROBE_PORTS = (80, 443, 445, 22, 3389, 8080, 5000, 7547, 23, 8009, 631, 5353)


def _safe_net(cidr: str) -> Optional[ipaddress.IPv4Network]:
    try:
        return ipaddress.ip_network(cidr, strict=False)
    except ValueError:
        return None


def _in_net(ip: str, net: Optional[ipaddress.IPv4Network]) -> bool:
    if net is None:
        return True
    try:
        return ipaddress.ip_address(ip) in net
    except ValueError:
        return False


def tcp_deep_sweep(cidr: str, known_alive: set, workers: int = 200,
                   progress_cb: Optional[Callable[[int, int, int], None]] = None
                   ) -> Dict[str, int]:
    """Probe common TCP ports across hosts that didn't answer ping.
    Returns {ip: first_responsive_port} for newly discovered hosts."""
    import socket as _socket

    net = _safe_net(cidr)
    if net is None:
        return {}
    try:
        candidates = [str(h) for h in net.hosts() if str(h) not in known_alive]
    except (ValueError, OSError):
        return {}

    found: Dict[str, int] = {}
    lock = threading.Lock()

    def _probe(ip: str) -> None:
        for port in SWEEP_PROBE_PORTS:
            try:
                with _socket.socket(_socket.AF_INET, _socket.SOCK_STREAM) as sock:
                    sock.settimeout(0.45)
                    if sock.connect_ex((ip, port)) == 0:
                        with lock:
                            found[ip] = port
                        return
            except OSError:
                return

    done = 0
    with concurrent.futures.ThreadPoolExecutor(max_workers=workers) as pool:
        futures = [pool.submit(_probe, ip) for ip in candidates]
        for _future in concurrent.futures.as_completed(futures):
            done += 1
            if progress_cb and done % 64 == 0:
                progress_cb(done, len(candidates), len(found))
    return found


class ScanEngine:
    """One instance per app; scans run on a worker thread."""

    def __init__(self, inventory: DeviceInventory, license_manager=None,
                 config: Optional[dict] = None):
        self.inventory = inventory
        self.licenses = license_manager
        self.config = config or {}
        self._thread: Optional[threading.Thread] = None
        self._cancel = threading.Event()
        self._progress_lock = threading.Lock()
        self._progress: dict = {
            "running": False, "phase": "idle", "percent": 0,
            "detail": "", "found": 0, "log": [], "started_at": None,
            "finished_at": None, "error": None, "run_id": 0,
        }
        self._run_counter = 0
        self._last_report: Optional[dict] = None

    # -- state -------------------------------------------------------------------

    def progress(self) -> dict:
        with self._progress_lock:
            return dict(self._progress)

    @property
    def running(self) -> bool:
        with self._progress_lock:
            return bool(self._progress["running"])

    def cancel(self) -> bool:
        if not self.running:
            return False
        self._cancel.set()
        return True

    def _set(self, **kwargs) -> None:
        with self._progress_lock:
            self._progress.update(kwargs)

    def _log(self, message: str) -> None:
        entry = {"t": time.time(),
                 "iso": time.strftime("%H:%M:%S"), "message": message}
        with self._progress_lock:
            self._progress["log"] = (self._progress["log"] + [entry])[-200:]

    # -- entry points -------------------------------------------------------------

    def start_scan(self, cidr: Optional[str] = None,
                   profile: str = "standard",
                   do_audit: bool = True,
                   deep_identify: bool = True,
                   sweep_tcp: Optional[bool] = None,
                   on_done: Optional[Callable[[dict], None]] = None) -> dict:
        """Kick off a full pipeline run. Returns immediately with a handle."""
        if self.running:
            return {"ok": False, "message": "A scan is already running."}

        # Licensing gate
        if self.licenses:
            feature = {"quick": "port_scan_quick",
                       "standard": "port_scan_standard",
                       "deep": "port_scan_deep"}.get(profile, "port_scan_standard")
            gate = self.licenses.gate(feature)
            if gate and self.licenses.tier == "free":  # one free premium scan
                if profile == "standard" and self.licenses.consume_free_credit("scan"):
                    gate = None
            if gate:
                return {"ok": False, "gate": gate, "message": gate["message"]}
            if sweep_tcp is None:
                sweep_tcp = bool(self.config.get("sweep_tcp", False))
            if sweep_tcp:
                gate = self.licenses.gate("deep_sweep")
                if gate:
                    sweep_tcp = False
            if self.licenses.tier == "free":
                remaining = self.licenses.scan_quota_remaining()
                if remaining is not None and remaining <= 0:
                    return {"ok": False, "gate": self.licenses.gate("unlimited_scans"),
                            "message": "Daily free scan limit reached."}
            self.licenses.count_scan()

        if cidr is None:
            interfaces = network.local_interfaces()
            cidr = interfaces[0].cidr if interfaces else "192.168.1.0/24"

        self._run_counter += 1
        self._cancel.clear()
        self._set(running=True, phase="starting", percent=0, detail=cidr,
                  found=0, log=[], started_at=time.time(), finished_at=None,
                  error=None, run_id=self._run_counter)
        self._thread = threading.Thread(target=self._run_pipeline, daemon=True,
                                        name=f"aetherscan-run-{self._run_counter}",
                                        args=(cidr, profile, do_audit,
                                              deep_identify, bool(sweep_tcp), on_done))
        self._thread.start()
        return {"ok": True, "run_id": self._run_counter, "subnet": cidr}

    # -- pipeline -------------------------------------------------------------------

    def _run_pipeline(self, cidr: str, profile: str, do_audit: bool,
                      deep_identify: bool, sweep_tcp: bool,
                      on_done: Optional[Callable]) -> None:
        started = time.time()
        new_devices = 0
        try:
            # ---------------- 1. interfaces ----------------
            self._set(phase="interfaces", percent=2, detail=f"Targeting {cidr}")
            interfaces = network.local_interfaces()
            gateway = network.default_gateway(interfaces[0] if interfaces else None)
            self._log(f"Target subnet {cidr} · gateway {gateway or '?'}")

            # ---------------- 2. sweep ----------------
            self._set(phase="sweep", percent=6, detail="Pinging every address…")

            def _sweep_progress(done: int, total: int, found: int) -> None:
                percent = 6 + int(34 * done / max(1, total))
                self._set(phase="sweep", percent=percent,
                          detail=f"Pinging {cidr} ({done}/{total})",
                          found=found)

            sweep = network.ping_sweep(
                cidr, workers=self.config.get("sweep_workers", 96),
                timeout_ms=self.config.get("ping_timeout_ms", 500),
                progress_cb=_sweep_progress)
            if self._cancel.is_set():
                raise _Canceled()
            self._log(f"Sweep complete: {sweep.alive} responded in "
                      f"{sweep.duration_ms} ms")

            # Deep sweep: TCP-probe hosts that ignored ping so quiet devices
            # (printers, headless IoT, firewalled laptops) still show up.
            if sweep_tcp:
                self._set(phase="sweep", percent=38, detail="Probing silent hosts over TCP…")
                alive_now = {r.ip for r in sweep.results if r.alive} | \
                    set(sweep.arp_entries.keys())
                extra = tcp_deep_sweep(cidr, alive_now,
                                       workers=self.config.get("sweep_workers", 96),
                                       progress_cb=lambda d, t, f: self._set(
                                           phase="sweep", percent=38,
                                           detail=f"TCP probing silent hosts ({d}/{t})"))
                for ip, port in extra.items():
                    sweep.results.append(network.PingResult(ip=ip, alive=True))
                    sweep.arp_entries.setdefault(ip, "")
                    sweep.alive += 1
                if extra:
                    self._log(f"Deep sweep found {len(extra)} device(s) that ignore ping")
                else:
                    self._log("Deep sweep: no additional silent hosts found")

            # ---------------- 3-4. build devices + enrich ----------------
            ttl_map = {r.ip: r.ttl for r in sweep.results}
            latency_map = {r.ip: r.latency_ms for r in sweep.results}
            net = _safe_net(cidr)
            targets = sorted(set(list(sweep.arp_entries.keys()) +
                                 [r.ip for r in sweep.results if r.alive]))
            targets = [t for t in targets
                       if network.is_scannable_ipv4(t) and _in_net(t, net)]
            devices: List[Device] = []
            total = max(1, len(targets))
            for idx, ip in enumerate(targets):
                if self._cancel.is_set():
                    raise _Canceled()
                mac = sweep.arp_entries.get(ip) or network.arp_lookup(ip) or ""
                device = Device(ip=ip, mac=mac)
                device.ttl = ttl_map.get(ip)
                device.latency_ms = latency_map.get(ip)
                device.is_gateway = (ip == gateway)
                if mac:
                    info = macdb.describe_mac(
                        mac, online=self.config.get("online_lookup", False))
                    device.vendor = info["vendor"] or ""
                    device.vendor_badge = info["vendor_badge"]
                    device.locally_administered = info["locally_administered"]
                    device.era = info["era"]
                    device.vendor_profile = info["profile"]
                devices.append(device)
                self._set(phase="enrich", percent=40 + int(10 * idx / total),
                          detail=f"Identifying vendors ({idx + 1}/{total})",
                          found=len(devices))
            self._log(f"Enriched {len(devices)} devices with vendor data")

            # ---------------- 5. identify (premium) ----------------
            identify_ok = (deep_identify and
                           (not self.licenses or self.licenses.allows("fingerprinting")))
            if identify_ok and devices:
                mdns_enabled = (self.licenses is None or
                                self.licenses.allows("mdns_upnp_enrichment"))

                def _identify(device: Device) -> None:
                    signals = fp.fingerprint(device.ip, ttl=device.ttl, deep=mdns_enabled)
                    device.hostname = signals["hostname"]
                    device.netbios_name = signals["netbios_name"]
                    device.mdns_name = signals["mdns_name"]
                    if not device.os_guess:
                        device.os_guess = signals["os_guess"]
                    upnp = signals.get("upnp")
                    if upnp:
                        desc = upnp.get("description") or {}
                        if desc.get("model_name"):
                            device.model = desc["model_name"]
                        if desc.get("manufacturer") and not device.vendor:
                            device.vendor = desc["manufacturer"]
                        if desc.get("friendly_name"):
                            device.upnp = desc["friendly_name"]

                id_workers = min(8, max(2, len(devices)))
                done = 0
                with concurrent.futures.ThreadPoolExecutor(
                        max_workers=id_workers) as id_pool:
                    futures = {id_pool.submit(_identify, d): d for d in devices}
                    for future in concurrent.futures.as_completed(futures):
                        if self._cancel.is_set():
                            raise _Canceled()
                        done += 1
                        self._set(phase="identify",
                                  percent=50 + int(12 * done / len(devices)),
                                  detail=f"Resolving names ({done}/{len(devices)})")
                self._log("Identification pass complete (DNS / NetBIOS / mDNS / UPnP)")

            # ---------------- 6. ports (premium) ----------------
            if self.licenses is None or self.licenses.allows("port_scan_quick"):
                scanner = portscan.PortScanner(
                    timeout=self.config.get("port_timeout_s", 0.6),
                    workers=self.config.get("port_workers", 128))
                port_targets = [d for d in devices
                                if not d.is_gateway or profile != "quick"]
                if profile == "quick":
                    port_targets = devices[:20]  # quick pass: top 20 devices
                for idx, device in enumerate(port_targets):
                    if self._cancel.is_set():
                        raise _Canceled()
                    report = scanner.scan(device.ip, profile=profile,
                                          grab_banners=(profile != "quick"))
                    device.ports = [p.to_dict() for p in report.open_ports]
                    self._set(phase="ports", percent=62 + int(18 * idx / max(1, len(port_targets))),
                              detail=f"Port scan {device.ip} ({idx + 1}/{len(port_targets)})")
                scanned = sum(1 for d in port_targets if d.ports)
                self._log(f"Port scan ({profile}) hit {scanned} devices with open ports")

            # ---------------- type inference ----------------
            for device in devices:
                device.device_type = infer_device_type(device, gateway_ip=gateway)

            # ---------------- 7. audit (premium) ----------------
            audits: List[dict] = []
            if do_audit and (self.licenses is None or self.licenses.allows("security_audit")):
                auditor = vulnscan.SecurityAuditor({
                    "credential_audit": self.config.get("credential_audit", False),
                })
                audit_targets = [d for d in devices if d.ports]
                for idx, device in enumerate(audit_targets):
                    if self._cancel.is_set():
                        raise _Canceled()
                    rep = auditor.audit_device(device.ip, ports=device.ports)
                    audits.append(rep.to_dict())
                    self._set(phase="audit", percent=80 + int(15 * idx / max(1, len(audit_targets))),
                              detail=f"Auditing {device.ip} ({idx + 1}/{len(audit_targets)})")
                self._log(f"Security audit finished — {len(audits)} devices scored")

            # ---------------- 8. persist ----------------
            self._set(phase="persist", percent=97, detail="Saving inventory…")
            for device in devices:
                is_new = self.inventory.upsert(device)
                if is_new and not device.is_gateway:
                    new_devices += 1
                    self.inventory.log_event(
                        "device.discovered",
                        f"Discovered {device.display_name} ({device.ip})",
                        ip=device.ip, mac=device.mac)
            summary = vulnscan.network_summary(
                [vulnscan.AuditReport(ip=a["ip"], score=a["score"],
                                      grade=a["grade"]) for a in audits]) if audits else {}
            self.inventory.log_scan_run(cidr, len(devices), new_devices,
                                        int((time.time() - started) * 1000))

            duration_ms = int((time.time() - started) * 1000)
            self._last_report = {
                "subnet": cidr, "devices": [d.to_dict() for d in devices],
                "audits": audits, "summary": summary,
                "gateway": gateway, "duration_ms": duration_ms,
            }
            self._set(phase="done", percent=100, running=False,
                      detail=f"{len(devices)} devices · {duration_ms} ms",
                      found=len(devices), finished_at=time.time())
            self._log(f"Scan complete — {len(devices)} devices, "
                      f"{new_devices} new, {duration_ms} ms")
            if on_done:
                try:
                    on_done(self._last_report)
                except Exception:
                    pass
        except _Canceled:
            self._set(phase="canceled", running=False, percent=100,
                      detail="Scan canceled", finished_at=time.time())
            self._log("Scan canceled by user")
        except Exception as exc:
            import traceback
            self._set(phase="error", running=False, error=str(exc),
                      detail=str(exc), finished_at=time.time())
            self._log(f"Scan failed: {exc}")
            for line in traceback.format_exc().splitlines():
                self._log(f"  {line}")

    # -- single-device actions ---------------------------------------------------

    def port_scan_device(self, device_id: str, profile: str = "standard") -> dict:
        device = self.inventory.get(device_id)
        if device is None:
            return {"ok": False, "message": "Unknown device"}
        if self.licenses:
            feature = {"quick": "port_scan_quick", "standard": "port_scan_standard",
                       "deep": "port_scan_deep"}.get(profile, "port_scan_standard")
            gate = self.licenses.gate(feature)
            if gate:
                return {"ok": False, "gate": gate}
        scanner = portscan.PortScanner(
            timeout=self.config.get("port_timeout_s", 0.6),
            workers=self.config.get("port_workers", 128))
        report = scanner.scan(device.ip, profile=profile)
        device.ports = [p.to_dict() for p in report.open_ports]
        device.device_type = infer_device_type(device)
        self.inventory.upsert(device)
        self.inventory.update_fields(device.id, ports=device.ports)
        return {"ok": True, "report": report.to_dict()}

    def audit_device(self, device_id: str) -> dict:
        device = self.inventory.get(device_id)
        if device is None:
            return {"ok": False, "message": "Unknown device"}
        if self.licenses:
            gate = self.licenses.gate("security_audit")
            if gate and self.licenses.tier == "free":  # one free audit
                if self.licenses.consume_free_credit("audit"):
                    gate = None
            if gate:
                return {"ok": False, "gate": gate}
        auditor = vulnscan.SecurityAuditor({
            "credential_audit": self.config.get("credential_audit", False)})
        ports = device.ports
        if not ports:
            scanner = portscan.PortScanner(timeout=0.7, workers=128)
            report = scanner.scan(device.ip, profile="standard")
            ports = [p.to_dict() for p in report.open_ports]
            device.ports = ports
            self.inventory.update_fields(device.id, ports=ports)
        rep = auditor.audit_device(device.ip, ports=ports)
        self.inventory.log_event("device.audited",
                                 f"Audited {device.display_name}: score {rep.score}",
                                 ip=device.ip, mac=device.mac,
                                 meta={"score": rep.score})
        return {"ok": True, "report": rep.to_dict()}

    def last_report(self) -> Optional[dict]:
        return self._last_report

    # -- demo mode -----------------------------------------------------------------

    def seed_demo_devices(self) -> int:
        """Generate a realistic demo LAN for UI testing / store screenshots."""
        demo = [
            ("192.168.1.1", "3c:37:86:9a:11:04", "Gateway", "ASUSTek Computer", "router", "ASUS RT-AX86U", 64, [80, 443, 7547]),
            ("192.168.1.20", "ac:de:48:00:11:22", "James's MacBook Pro", "Apple, Inc.", "computer", "MacBookPro18,3", 64, [88, 445, 5000]),
            ("192.168.1.23", "f0:18:98:33:44:55", "James's iPhone", "Apple, Inc.", "phone", "iPhone15,3", 64, []),
            ("192.168.1.31", "b8:27:eb:aa:bb:cc", "home-lab-pi", "Raspberry Pi Trading", "computer", "Raspberry Pi 4B", 64, [22, 80, 8123]),
            ("192.168.1.42", "5c:cf:7f:dd:ee:ff", "Smart Plug (ESP8266)", "Espressif (ESP IoT)", "iot", "ESP8266EX", 64, [80, 1883]),
            ("192.168.1.55", "00:17:88:12:34:56", "Hue Bridge", "Philips Lighting (Hue)", "iot", "BSB002", 64, [80, 443]),
            ("192.168.1.60", "44:65:0d:77:88:99", "Echo Show 8", "Amazon Technologies", "iot", "Echo Show 8", 64, [80]),
            ("192.168.1.77", "00:24:83:aa:bb:cc", "LG OLED C1", "LG Electronics", "tv", "OLED55C1", 64, [3000, 9955]),
            ("192.168.1.90", "00:11:32:12:12:12", "Vault-NAS", "Synology", "nas", "DS920+", 64, [5000, 5001, 445]),
            ("192.168.1.110", "38:01:97:9a:8a:7a", "Galaxy S24", "Samsung Electronics", "phone", "SM-S921B", 64, []),
            ("192.168.1.120", "00:1b:a9:11:22:33", "Brother MFC", "Brother Industries", "printer", "MFC-L2740DW", 64, [80, 631, 9100]),
            ("192.168.1.140", "00:0c:29:ab:cd:ef", "dev-vm-01", "VMware, Inc.", "vm", "ESXi 8.0", 128, [443, 902]),
        ]
        count = 0
        for ip, mac, name, vendor, dtype, model, ttl, ports in demo:
            device = Device(ip=ip, mac=mac, custom_name=name, vendor=vendor,
                            vendor_badge=macdb.vendor_badge(vendor),
                            device_type=dtype, model=model,
                            hostname=name.lower().replace(" ", "-").replace("(", "").replace(")", ""),
                            os_guess=_demo_os(ttl),
                            ttl=ttl)
            device.ports = [{"port": p, "open": True,
                             "service": portscan.SERVICE_REGISTRY.get(p, {}).get("name", "unknown"),
                             "protocol": portscan.SERVICE_REGISTRY.get(p, {}).get("proto", "TCP"),
                             "risk": portscan.SERVICE_REGISTRY.get(p, {}).get("risk", 0),
                             "desc": portscan.SERVICE_REGISTRY.get(p, {}).get("desc", ""),
                             "banner": ""} for p in ports]
            device.era = macdb.estimate_device_era(mac)
            device.vendor_profile = macdb.vendor_profile(vendor)
            device.is_gateway = ip.endswith(".1")
            device.tags = ["demo"]
            self.inventory.upsert(device)
            count += 1
        self.inventory.log_event("demo.seeded",
                                 f"Seeded {count} demo devices (development mode)")
        return count


def _demo_os(ttl: int) -> str:
    if ttl == 64:
        return "Linux / macOS / iOS / Android (TTL 64)"
    if ttl == 128:
        return "Microsoft Windows (TTL 128)"
    return "Unknown"


class _Canceled(Exception):
    """Internal control-flow exception for scan cancellation."""
