"""
server/api.py — REST surface for the web console.

Route table (all JSON):
  GET  /api/status              app + license + engine snapshot
  GET  /api/interfaces          scannable local interfaces
  GET  /api/devices             full inventory
  GET  /api/device/<id>         one device, with profile/era/ports
  POST /api/device/<id>         update custom_name / notes / tags / favorite
  DELETE /api/device/<id>       remove from inventory
  POST /api/scan                start pipeline {cidr, profile, audit, deep}
  POST /api/scan/cancel         cancel running pipeline
  GET  /api/scan/progress       live progress for polling
  GET  /api/scan/last           last completed report
  POST /api/device/<id>/ports   on-demand port scan {profile}
  POST /api/device/<id>/audit   on-demand security audit
  POST /api/device/<id>/ping    liveness probe + refresh TTL/latency
  GET  /api/events              event log
  GET  /api/stats               inventory stats + scan history
  POST /api/monitor/start       continuous monitoring {interval_s}
  POST /api/monitor/stop        stop monitoring
  GET  /api/monitor/status      monitoring state
  POST /api/license/activate    activate key {key, licensed_to}
  POST /api/license/deactivate  revert to trial/free
  GET  /api/license/status      tier, features, trial
  GET  /api/report?fmt=html|json|csv|md&save=1   generate/download report
  POST /api/demo/seed           seed demo devices (dev mode only)
  GET  /api/debug/environment   host diagnostics (About pane)
  POST /api/debug/selftest      run engine self-diagnostics
"""

from __future__ import annotations

import json
import os
import platform
import socket
import threading
import time
from typing import Callable, Optional

from core import __version__, network, report as report_mod, vulnscan
from core.monitor import NetworkMonitor

_ROUTES: dict = {}


def route(method: str, path: str):
    """Register a handler for (method, path)."""
    def decorator(func: Callable):
        _ROUTES[(method, path)] = func
        return func
    return decorator


def _match(pattern: str, actual: str) -> Optional[str]:
    """
    Match '/api/device/<id>' or '/api/device/<id>/ports' against an actual
    path, returning the captured '<id>' segment (or '' for static routes).
    """
    pat_parts = pattern.strip("/").split("/")
    act_parts = actual.strip("/").split("/")
    if len(pat_parts) != len(act_parts):
        return None
    captured: Optional[str] = None
    for p_part, a_part in zip(pat_parts, act_parts):
        if p_part.startswith("<") and p_part.endswith(">"):
            captured = a_part
        elif p_part != a_part:
            return None
    return captured if captured is not None else ""


def dispatch(handler, method: str, path: str, state, body: Optional[dict] = None):
    """Find and run the matching route handler."""
    for (route_method, pattern), func in _ROUTES.items():
        if route_method != method:
            continue
        captured = _match(pattern, path)
        if captured is not None:
            try:
                return func(handler, state, captured, body or {})
            except BrokenPipeError:
                raise
            except Exception as exc:  # surface a clean 500, keep server alive
                return handler._send_json({"error": "internal",
                                           "detail": f"{type(exc).__name__}: {exc}"},
                                          status=500)
    return handler._send_json({"error": "unknown_route", "path": path}, status=404)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _license_view(state) -> dict:
    status = state.licenses.status()
    status["tiers"] = [
        {"id": "free", "price": "$0", "name": "AetherScan Free",
         "blurb": "Discovery, device inventory, vendor intelligence.",
         "features": ["Subnet discovery & ping sweep", "MAC vendor + era estimates",
                      "Device inventory & custom names", "Quick port profile",
                      "8 scans/day"]},
        {"id": "pro", "price": "$24 one-time", "name": "AetherScan Pro",
         "blurb": "The full auditing toolkit for power users.",
         "features": ["Standard port profiles + banners", "Fingerprinting (DNS/mDNS/NetBIOS)",
                      "Security audit & scoring", "Continuous monitoring", "Report exports",
                      "Unlimited scans"]},
        {"id": "ultimate", "price": "$59 one-time", "name": "AetherScan Ultimate",
         "blurb": "Deep enrichment for professionals and labs.",
         "features": ["Deep (1–1024 + curated) port profiles", "UPnP model/serial enrichment",
                      "Webhook alerts", "Priority support"]},
    ]
    return status


def _gate_response(handler, state, gate: Optional[dict]):
    if gate:
        handler._send_json(gate, status=402)
        return True
    return False


# ---------------------------------------------------------------------------
# Status & meta
# ---------------------------------------------------------------------------


@route("GET", "/api/status")
def _api_status(handler, state, captured, body):
    return handler._send_json({
        "ok": True,
        "app": {"name": "AetherScan", "version": __version__, "codename": "Lumen",
                "build": 1410},
        "license": _license_view(state),
        "engine": state.engine.progress(),
        "monitor": state.monitor.to_dict() if state.monitor else
                   {"running": False, "status": "stopped", "rounds": 0},
        "network": _network_view(state),
        "stats": state.inventory.stats(),
        "update": state.update_info,
        "server_time": time.time(),
    })


def _network_view(state) -> dict:
    interfaces = network.local_interfaces()
    primary = interfaces[0] if interfaces else None
    return {
        "hostname": socket.gethostname(),
        "platform": platform.system() + " " + platform.release(),
        "interfaces": [i.to_dict() for i in interfaces],
        "primary": primary.to_dict() if primary else None,
        "gateway": network.default_gateway(primary),
    }


@route("GET", "/api/interfaces")
def _api_interfaces(handler, state, captured, body):
    interfaces = network.local_interfaces()
    return handler._send_json({
        "ok": True,
        "interfaces": [i.to_dict() for i in interfaces],
        "gateway": network.default_gateway(interfaces[0] if interfaces else None),
    })


@route("GET", "/api/debug/environment")
def _api_debug_env(handler, state, captured, body):
    env = network.env_summary()
    env["interfaces"] = [i.to_dict() for i in network.local_interfaces()]
    env["arp_entries"] = len(network.arp_table())
    env["python"] = platform.python_version()
    return handler._send_json({"ok": True, "environment": env})


@route("POST", "/api/debug/selftest")
def _api_debug_selftest(handler, state, captured, body):
    checks = []
    ok_all = True

    def check(name: str, func: Callable[[], bool], detail: str = ""):
        nonlocal ok_all
        try:
            passed = bool(func())
        except Exception as exc:
            passed = False
            detail = str(exc)
        ok_all = ok_all and passed
        checks.append({"name": name, "passed": passed, "detail": detail})

    check("local-ip-resolution", lambda: network.primary_local_ip() != "")
    check("interface-enumeration", lambda: len(network.local_interfaces()) >= 1)
    check("arp-table-readable", lambda: isinstance(network.arp_table(), dict))
    check("gateway-detected", lambda: network.default_gateway() is not None)
    check("oui-db-loaded", lambda: len(__import__("core.macdb", fromlist=["x"]).EMBEDDED_OUI) > 50)
    check("license-store-writable", lambda: state.licenses.scan_quota_remaining() in (None, 0) or True)
    check("inventory-readable", lambda: isinstance(state.inventory.stats(), dict))
    check("loopback-ping", lambda: network.ping("127.0.0.1", timeout_ms=300).alive)
    check("tcp-socket-open", lambda: _self_tcp_check())
    return handler._send_json({"ok": ok_all, "checks": checks,
                               "score": f"{sum(1 for c in checks if c['passed'])}/{len(checks)}"})


def _self_tcp_check() -> bool:
    import threading
    result = {"ok": False}
    server_sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    try:
        server_sock.bind(("127.0.0.1", 0))
        server_sock.listen(1)
        port = server_sock.getsockname()[1]

        def _accept():
            try:
                conn, _ = server_sock.accept()
                conn.close()
            except OSError:
                pass

        t = threading.Thread(target=_accept, daemon=True)
        t.start()
        result["ok"] = network.tcp_reachable("127.0.0.1", port, timeout=1.0)
        t.join(2.0)
    finally:
        server_sock.close()
    return result["ok"]


# ---------------------------------------------------------------------------
# Devices
# ---------------------------------------------------------------------------


@route("GET", "/api/devices")
def _api_devices(handler, state, captured, body):
    devices = [d.to_dict() for d in state.inventory.all_devices()]
    return handler._send_json({"ok": True, "count": len(devices),
                               "devices": devices})


@route("GET", "/api/device/<id>")
def _api_device_get(handler, state, device_id, body):
    device = state.inventory.get(device_id)
    if device is None:
        return handler._send_json({"error": "not_found"}, status=404)
    return handler._send_json({"ok": True, "device": device.to_dict()})


@route("POST", "/api/device/<id>")
def _api_device_update(handler, state, device_id, body):
    device = state.inventory.get(device_id)
    if device is None:
        return handler._send_json({"error": "not_found"}, status=404)
    fields = {}
    if "custom_name" in body:
        fields["custom_name"] = str(body["custom_name"])[:64]
    if "notes" in body:
        fields["notes"] = str(body["notes"])[:2000]
    if "favorite" in body:
        fields["favorite"] = bool(body["favorite"])
    if "tags" in body and isinstance(body["tags"], list):
        fields["tags"] = [str(t)[:32] for t in body["tags"][:10]]
    if fields:
        state.inventory.update_fields(device_id, **fields)
        state.inventory.log_event("device.updated",
                                  f"Updated {device.display_name}",
                                  ip=device.ip, mac=device.mac)
    fresh = state.inventory.get(device_id)
    return handler._send_json({"ok": True, "device": fresh.to_dict()})


@route("DELETE", "/api/device/<id>")
def _api_device_delete(handler, state, device_id, body):
    device = state.inventory.get(device_id)
    if device is None:
        return handler._send_json({"error": "not_found"}, status=404)
    state.inventory.delete(device_id)
    state.inventory.log_event("device.removed",
                              f"Removed {device.display_name} from inventory",
                              ip=device.ip, mac=device.mac)
    return handler._send_json({"ok": True})


@route("POST", "/api/device/<id>/ping")
def _api_device_ping(handler, state, device_id, body):
    device = state.inventory.get(device_id)
    if device is None:
        return handler._send_json({"error": "not_found"}, status=404)
    result = network.ping(device.ip, timeout_ms=800)
    if result.alive:
        device.ttl = result.ttl
        device.latency_ms = result.latency_ms
        device.last_seen = time.time()
        state.inventory.upsert(device)
    return handler._send_json({"ok": True, "ping": result.to_dict()})


@route("POST", "/api/device/<id>/ports")
def _api_device_ports(handler, state, device_id, body):
    result = state.engine.port_scan_device(device_id, profile=body.get("profile", "standard"))
    if not result.get("ok"):
        status = 402 if result.get("gate") else 400
        return handler._send_json(result, status=status)
    return handler._send_json(result)


@route("POST", "/api/device/<id>/audit")
def _api_device_audit(handler, state, device_id, body):
    result = state.engine.audit_device(device_id)
    if not result.get("ok"):
        status = 402 if result.get("gate") else 400
        return handler._send_json(result, status=status)
    return handler._send_json(result)


# ---------------------------------------------------------------------------
# Scanning
# ---------------------------------------------------------------------------


@route("POST", "/api/scan")
def _api_scan_start(handler, state, captured, body):
    result = state.engine.start_scan(
        cidr=body.get("cidr") or None,
        profile=body.get("profile", "standard"),
        do_audit=bool(body.get("audit", True)),
        deep_identify=bool(body.get("deep", True)))
    status = 200 if result.get("ok") else (402 if result.get("gate") else 409)
    return handler._send_json(result, status=status)


@route("POST", "/api/scan/cancel")
def _api_scan_cancel(handler, state, captured, body):
    canceled = state.engine.cancel()
    return handler._send_json({"ok": canceled, "canceled": canceled})


@route("GET", "/api/scan/progress")
def _api_scan_progress(handler, state, captured, body):
    return handler._send_json({"ok": True, "progress": state.engine.progress()})


@route("GET", "/api/scan/last")
def _api_scan_last(handler, state, captured, body):
    report = state.engine.last_report()
    if report is None:
        return handler._send_json({"ok": False, "message": "No completed scan yet"},
                                  status=404)
    return handler._send_json({"ok": True, "report": report})


# ---------------------------------------------------------------------------
# Events, stats, monitor
# ---------------------------------------------------------------------------


@route("GET", "/api/events")
def _api_events(handler, state, captured, body):
    limit = int(handler.path_query().get("limit", "120") or 120)
    return handler._send_json({"ok": True,
                               "events": state.inventory.events(limit=min(limit, 500))})


@route("GET", "/api/stats")
def _api_stats(handler, state, captured, body):
    return handler._send_json({"ok": True,
                               "stats": state.inventory.stats(),
                               "scan_history": state.inventory.scan_history()})


@route("POST", "/api/monitor/start")
def _api_monitor_start(handler, state, captured, body):
    deep = bool(body.get("deep", False))
    if state.licenses:
        gate = state.licenses.gate("monitoring")
        if _gate_response(handler, state, gate):
            return
        if deep:
            gate = state.licenses.gate("deep_monitor")
            if _gate_response(handler, state, gate):
                return
    if state.monitor and state.monitor.running:
        return handler._send_json({"ok": True, "monitor": state.monitor.to_dict(),
                                   "message": "Monitoring already active"})
    interfaces = network.local_interfaces()
    cidr = body.get("cidr") or (interfaces[0].cidr if interfaces else "192.168.1.0/24")
    interval = int(body.get("interval_s", 60))
    monitor = NetworkMonitor(state.inventory, cidr, interval_s=interval,
                             deep=deep,
                             on_event=state.config.get("_on_monitor_event"))
    monitor.start()
    state.monitor = monitor
    state.inventory.log_event("monitor.started",
                              f"Monitoring {cidr} every {interval}s"
                              + (" (deep)" if deep else ""))
    return handler._send_json({"ok": True, "monitor": monitor.to_dict()})


@route("POST", "/api/monitor/stop")
def _api_monitor_stop(handler, state, captured, body):
    if state.monitor:
        state.monitor.stop()
        state.inventory.log_event("monitor.stopped", "Monitoring stopped")
        info = state.monitor.to_dict()
        state.monitor = None
        return handler._send_json({"ok": True, "monitor": info})
    return handler._send_json({"ok": True, "monitor": {"running": False}})


@route("GET", "/api/monitor/status")
def _api_monitor_status(handler, state, captured, body):
    return handler._send_json({"ok": True,
                               "monitor": state.monitor.to_dict() if state.monitor
                               else {"running": False, "status": "stopped",
                                     "rounds": 0, "tracked": 0}})


# ---------------------------------------------------------------------------
# Licensing
# ---------------------------------------------------------------------------


@route("GET", "/api/license/status")
def _api_license_status(handler, state, captured, body):
    return handler._send_json({"ok": True, "license": _license_view(state)})


@route("POST", "/api/license/activate")
def _api_license_activate(handler, state, captured, body):
    key = str(body.get("key", ""))
    licensed_to = str(body.get("licensed_to", ""))
    result = state.licenses.activate(key, licensed_to)
    state.inventory.log_event("license.activated" if result.get("ok")
                              else "license.rejected",
                              result.get("message", ""))
    return handler._send_json(result, status=200 if result.get("ok") else 400)


@route("POST", "/api/license/deactivate")
def _api_license_deactivate(handler, state, captured, body):
    state.licenses.deactivate()
    return handler._send_json({"ok": True, "license": _license_view(state)})


# ---------------------------------------------------------------------------
# Reports
# ---------------------------------------------------------------------------


@route("GET", "/api/report")
def _api_report(handler, state, captured, body):
    if state.licenses:
        gate = state.licenses.gate("reports")
        if _gate_response(handler, state, gate):
            return
    query = handler.path_query()
    fmt = query.get("fmt", "html")
    devices = [d.to_dict() for d in state.inventory.all_devices()]
    audits = (state.engine.last_report() or {}).get("audits", [])
    summary = (state.engine.last_report() or {}).get("summary") or \
        vulnscan.network_summary([])
    interfaces = network.local_interfaces()
    builder = report_mod.ReportBuilder(
        devices=devices,
        network_info={
            "cidr": interfaces[0].cidr if interfaces else "?",
            "gateway": network.default_gateway(interfaces[0] if interfaces else None),
            "interface": interfaces[0].name if interfaces else "?",
            "host": socket.gethostname(),
            "ssid_label": query.get("label", "Local network"),
        },
        summary=summary, audits=audits)
    if query.get("save") == "1":
        path = builder.save(fmt, state.reports_dir)
        state.inventory.log_event("report.saved", f"Saved {fmt} report: {os.path.basename(path)}")
        return handler._send_json({"ok": True, "saved": path})
    payload, ctype = {
        "html": (builder.to_html(), "text/html; charset=utf-8"),
        "json": (builder.to_json(), "application/json; charset=utf-8"),
        "csv": (builder.to_csv(), "text/csv; charset=utf-8"),
        "md": (builder.to_markdown(), "text/markdown; charset=utf-8"),
    }.get(fmt, (builder.to_html(), "text/html; charset=utf-8"))
    handler._send_bytes(payload.encode("utf-8"), ctype)


# ---------------------------------------------------------------------------
# Demo / dev
# ---------------------------------------------------------------------------


@route("POST", "/api/demo/seed")
def _api_demo_seed(handler, state, captured, body):
    if not (state.licenses.is_development or state.config.get("allow_demo_seed")):
        return handler._send_json({"error": "dev_only",
                                   "message": "Demo seeding is available in development mode (--dev)."},
                                  status=403)
    count = state.engine.seed_demo_devices()
    return handler._send_json({"ok": True, "seeded": count})


@route("POST", "/api/demo/clear")
def _api_demo_clear(handler, state, captured, body):
    removed = state.inventory.clear_demo()
    state.inventory.log_event("demo.cleared", f"Removed {removed} demo device(s)")
    return handler._send_json({"ok": True, "removed": removed,
                               "has_demo": state.inventory.has_demo_devices()})


@route("GET", "/api/demo/status")
def _api_demo_status(handler, state, captured, body):
    return handler._send_json({"ok": True, "has_demo": state.inventory.has_demo_devices()})


# ---------------------------------------------------------------------------
# Network utilities (Pro) + raw TCP console (Ultimate)
# ---------------------------------------------------------------------------

_TCP_SESSIONS: dict = {}
_TCP_LOCK = threading.RLock()  # reentrant: gc runs while the caller holds the lock
_TCP_SESSION_TTL = 300.0
_TCP_RECV_CAP = 8192


def _tcp_session_gc() -> None:
    now = time.time()
    with _TCP_LOCK:
        for session_id in [sid for sid, s in _TCP_SESSIONS.items()
                           if now - s["last"] > _TCP_SESSION_TTL]:
            try:
                _TCP_SESSIONS[session_id]["sock"].close()
            except OSError:
                pass
            _TCP_SESSIONS.pop(session_id, None)


def _run_utility(handler, state, command: list, label: str, timeout: float = 12.0):
    """Execute one read-only diagnostic binary and return its output."""
    import subprocess
    from core.network import IS_WINDOWS
    try:
        creation = 0x08000000 if IS_WINDOWS else 0
        proc = subprocess.run(command, capture_output=True, text=True,
                              timeout=timeout, creationflags=creation)
        out = (proc.stdout or "")[:20000]
        return handler._send_json({"ok": True, "tool": label,
                                   "output": out,
                                   "exit_code": proc.returncode})
    except subprocess.TimeoutExpired:
        return handler._send_json({"ok": False, "tool": label,
                                   "output": "", "error": f"timed out after {int(timeout)}s"}, status=504)
    except FileNotFoundError:
        return handler._send_json({"ok": False, "tool": label, "output": "",
                                   "error": f"{command[0]} is not available on this system"},
                                  status=400)


def _safe_host(host: str) -> bool:
    """Utility targets must be LAN-ish addresses or resolvable private names."""
    import ipaddress
    try:
        addr = ipaddress.ip_address(host)
        return addr.is_private
    except ValueError:
        return len(host) <= 128 and all(c.isalnum() or c in "-._" for c in host)


@route("POST", "/api/tools/ping")
def _api_tools_ping(handler, state, captured, body):
    if state.licenses:
        gate = state.licenses.gate("tools_basic")
        if _gate_response(handler, state, gate):
            return
    host = str(body.get("host", "")).strip()
    if not _safe_host(host):
        return handler._send_json({"ok": False, "error": "invalid host"}, status=400)
    return _run_utility(handler, state,
                        ["ping", "-n" if network.IS_WINDOWS else "-c", "4",
                         "-w" if network.IS_WINDOWS else "-W",
                         "1000" if network.IS_WINDOWS else "2", host], "ping")


@route("POST", "/api/tools/traceroute")
def _api_tools_traceroute(handler, state, captured, body):
    if state.licenses:
        gate = state.licenses.gate("tools_basic")
        if _gate_response(handler, state, gate):
            return
    host = str(body.get("host", "")).strip()
    if not _safe_host(host):
        return handler._send_json({"ok": False, "error": "invalid host"}, status=400)
    command = ["tracert", host] if network.IS_WINDOWS else \
        ["traceroute", "-n", "-w", "2", "-q", "1", host]
    return _run_utility(handler, state, command, "traceroute")


@route("POST", "/api/tools/dns")
def _api_tools_dns(handler, state, captured, body):
    if state.licenses:
        gate = state.licenses.gate("tools_basic")
        if _gate_response(handler, state, gate):
            return
    host = str(body.get("host", "")).strip()
    if not _safe_host(host):
        return handler._send_json({"ok": False, "error": "invalid host"}, status=400)
    command = ["nslookup", host] if network.IS_WINDOWS else ["dig", "+short", host]
    return _run_utility(handler, state, command, "dns")


@route("POST", "/api/tools/arp")
def _api_tools_arp(handler, state, captured, body):
    if state.licenses:
        gate = state.licenses.gate("tools_basic")
        if _gate_response(handler, state, gate):
            return
    return _run_utility(handler, state, ["arp", "-a"] if network.IS_WINDOWS
                        else ["arp", "-n"], "arp")


@route("POST", "/api/tools/nmap")
def _api_tools_nmap(handler, state, captured, body):
    """Advanced scan via nmap, if it's installed on the engine host."""
    if state.licenses:
        gate = state.licenses.gate("tools_tcp")
        if _gate_response(handler, state, gate):
            return
    host = str(body.get("host", "")).strip()
    if not _safe_host(host):
        return handler._send_json({"ok": False, "error": "invalid host"}, status=400)
    ports = str(body.get("ports", "")).strip() or "top-100"
    nmap_port_arg = ports
    if ports == "top-1000":
        nmap_port_arg = "--top-ports 1000"
    elif ports == "top-100":
        nmap_port_arg = "--top-ports 100"
    elif not all(c.isdigit() or c in "-," for c in ports) or len(ports) > 32:
        return handler._send_json({"ok": False, "error": "invalid ports"}, status=400)
    import shutil as _shutil
    nmap_bin = _shutil.which("nmap")
    if not nmap_bin:
        for nmap_dir in (
            os.path.join(os.path.expandvars("%LOCALAPPDATA%"), "AetherScan", "nmap"),
            r"C:\Program Files (x86)\Nmap",
            r"C:\Program Files\Nmap",
        ):
            candidate = os.path.join(nmap_dir, "nmap.exe")
            if os.path.isfile(candidate):
                nmap_bin = candidate
                break
    if not nmap_bin:
        return handler._send_json({"ok": False, "tool": "nmap",
          "error": "nmap not found. Install from https://nmap.org/download.html or re-run the launcher."}, status=400)
        return _run_utility(handler, state, [nmap_bin, "-sV", "-T4", "-p", nmap_port_arg, host], "nmap", timeout=120)


@route("POST", "/api/tools/tcp/open")
def _api_tools_tcp_open(handler, state, captured, body):
    if state.licenses:
        gate = state.licenses.gate("tools_tcp")
        if _gate_response(handler, state, gate):
            return
    host = str(body.get("host", "")).strip()
    try:
        port = int(body.get("port", 23))
    except (TypeError, ValueError):
        return handler._send_json({"ok": False, "error": "invalid port"}, status=400)
    if not (1 <= port <= 65535) or not _safe_host(host):
        return handler._send_json({"ok": False, "error": "invalid host or port"}, status=400)
    import secrets as _secrets
    session_id = _secrets.token_urlsafe(12)
    try:
        sock = socket.create_connection((host, port), timeout=5.0)
        sock.settimeout(0.4)
    except OSError as exc:
        return handler._send_json({"ok": False, "error": f"connect failed: {exc}"}, status=400)
    with _TCP_LOCK:
        _tcp_session_gc()
        _TCP_SESSIONS[session_id] = {"sock": sock, "host": host, "port": port,
                                     "buffer": b"", "last": time.time()}
    return handler._send_json({"ok": True, "session": session_id,
                               "host": host, "port": port})


@route("POST", "/api/tools/tcp/send")
def _api_tools_tcp_send(handler, state, captured, body):
    if state.licenses:
        gate = state.licenses.gate("tools_tcp")
        if _gate_response(handler, state, gate):
            return
    session_id = str(body.get("session", ""))
    data = str(body.get("data", ""))
    with _TCP_LOCK:
        session = _TCP_SESSIONS.get(session_id)
    if session is None:
        return handler._send_json({"ok": False, "error": "no such session"}, status=404)
    out = ""
    try:
        if data:
            if not data.endswith("\n"):
                data += "\n"
            session["sock"].sendall(data.encode("utf-8", "replace")[:4096])
        session["last"] = time.time()
        chunks = b""
        try:
            while len(chunks) < _TCP_RECV_CAP:
                chunk = session["sock"].recv(4096)
                if not chunk:
                    break
                chunks += chunk
        except socket.timeout:
            pass
        session["buffer"] = (session["buffer"] + chunks)[-65536:]
        out = session["buffer"].decode("utf-8", "replace")[-8000:]
        closed = chunks == b"" and not data
    except OSError as exc:
        with _TCP_LOCK:
            _TCP_SESSIONS.pop(session_id, None)
        return handler._send_json({"ok": False, "error": f"connection lost: {exc}"},
                                  status=410)
    return handler._send_json({"ok": True, "output": out, "closed": bool(closed)})


@route("POST", "/api/tools/tcp/close")
def _api_tools_tcp_close(handler, state, captured, body):
    if state.licenses:
        gate = state.licenses.gate("tools_tcp")
        if _gate_response(handler, state, gate):
            return
    session_id = str(body.get("session", ""))
    with _TCP_LOCK:
        session = _TCP_SESSIONS.pop(session_id, None)
    if session:
        try:
            session["sock"].close()
        except OSError:
            pass
    return handler._send_json({"ok": True})


# ---------------------------------------------------------------------------
# Network exposure controls (Pro) — control this device's discoverability
# ---------------------------------------------------------------------------

_EXPOSURE_COMMANDS = {
    "status": [
        "powershell", "-NoProfile", "-Command",
        "Get-NetConnectionProfile | ConvertTo-Json -Compress"
    ],
    "visible": [
        "powershell", "-NoProfile", "-Command",
        "Get-NetConnectionProfile | Set-NetConnectionProfile -NetworkCategory Private; "
        "netsh advfirewall firewall set rule group='Network Discovery' new enable=Yes; "
        "netsh advfirewall firewall set rule group='File and Printer Sharing' new enable=Yes"
    ],
    "hidden": [
        "powershell", "-NoProfile", "-Command",
        "Get-NetConnectionProfile | Set-NetConnectionProfile -NetworkCategory Public; "
        "netsh advfirewall firewall set rule group='Network Discovery' new enable=No; "
        "netsh advfirewall firewall set rule group='File and Printer Sharing' new enable=No"
    ],
}


@route("POST", "/network/exposure")
def _api_network_exposure(handler, state, captured, body):
    if state.licenses:
        gate = state.licenses.gate("tools_basic")
        if _gate_response(handler, state, gate):
            return
    action = str(body.get("action", "status"))
    if action not in _EXPOSURE_COMMANDS:
        return handler._send_json({"ok": False, "error": "invalid action"}, status=400)
    return _run_utility(handler, state, _EXPOSURE_COMMANDS[action], f"exposure:{action}")


# ---------------------------------------------------------------------------
# Periodic auto-audit — re-audits all devices on a schedule
# ---------------------------------------------------------------------------

_AUTO_AUDIT_STATE = {"running": False, "interval_min": 60, "timer": None, "last_run": None}


@route("POST", "/audit/auto/start")
def _api_audit_auto_start(handler, state, captured, body):
    if state.licenses:
        gate = state.licenses.gate("security_audit")
        if _gate_response(handler, state, gate):
            return
    interval = max(5, int(body.get("interval_min", 30)))
    _AUTO_AUDIT_STATE["running"] = True
    _AUTO_AUDIT_STATE["interval_min"] = interval
    _AUTO_AUDIT_STATE["last_run"] = time.time()

    def _audit_round():
        devices = state.inventory.all_devices()
        targets = [d for d in devices if d.ports]
        auditor = vulnscan.SecurityAuditor({
            "credential_audit": state.config.get("credential_audit", False)})
        for device in targets[:15]:  # cap to avoid long runs
            try:
                report = auditor.audit_device(device.ip, ports=device.ports)
                state.inventory.log_event(
                    "auto.audit", f"Auto-audit {device.display_name}: score {report.score}",
                    ip=device.ip, mac=device.mac,
                    meta={"score": report.score, "grade": report.grade})
            except Exception:
                pass
        state.inventory.log_event(
            "auto.audit.done", f"Periodic audit round complete ({len(targets)} devices)")

    def _loop():
        while _AUTO_AUDIT_STATE["running"]:
            time.sleep(_AUTO_AUDIT_STATE["interval_min"] * 60)
            if not _AUTO_AUDIT_STATE["running"]:
                break
            _audit_round()
            _AUTO_AUDIT_STATE["last_run"] = time.time()

    threading.Thread(target=_loop, daemon=True, name="aetherscan-auto-audit").start()
    state.inventory.log_event("auto.audit.started", f"Periodic auto-audit every {interval} min")
    return handler._send_json({"ok": True, "running": True, "interval_min": interval})


@route("POST", "/audit/auto/stop")
def _api_audit_auto_stop(handler, state, captured, body):
    _AUTO_AUDIT_STATE["running"] = False
    state.inventory.log_event("auto.audit.stopped", "Periodic auto-audit stopped")
    return handler._send_json({"ok": True, "running": False})


@route("GET", "/audit/auto/status")
def _api_audit_auto_status(handler, state, captured, body):
    return handler._send_json({"ok": True, **{k: v for k, v in _AUTO_AUDIT_STATE.items() if k != "timer"}})


# ---------------------------------------------------------------------------
# Network utilities: TCP connection probe (Pro) — test reachability to a service
# ---------------------------------------------------------------------------

@route("POST", "/network/probe")
def _api_network_probe(handler, state, captured, body):
    if state.licenses:
        gate = state.licenses.gate("tools_basic")
        if _gate_response(handler, state, gate):
            return
    import socket as _s
    host = str(body.get("host", "")).strip()
    port = int(body.get("port", 80))
    if not _safe_host(host) or not (1 <= port <= 65535):
        return handler._send_json({"ok": False, "error": "invalid host or port"}, status=400)
    try:
        start = time.time()
        sock = _s.create_connection((host, port), timeout=3.0)
        elapsed = round((time.time() - start) * 1000)
        sock.close()
        return handler._send_json({"ok": True, "reachable": True, "host": host,
                                   "port": port, "latency_ms": elapsed})
    except Exception as exc:
        return handler._send_json({"ok": True, "reachable": False, "host": host,
                                   "port": port, "error": str(exc)})


@route("POST", "/admin/delete-user")
def _api_admin_delete_user(handler, state, captured, body):
    if state.licenses and not state.licenses.is_development:
        pass  # cloud worker handles admin auth
    email = str(body.get("email", "")).lower()
    if not email:
        return handler._send_json({"ok": False, "error": "email required"}, status=400)
    return handler._send_json({"ok": True, "message": f"Use the Cloudflare dashboard to delete {email} from the users table. D1 console: https://dash.cloudflare.com → Storage & Databases → D1 → aetherscan → Console", "sql": f"DELETE FROM users WHERE email = '{email}'; DELETE FROM user_state WHERE user_id = (SELECT id FROM users WHERE email = '{email}');"})
