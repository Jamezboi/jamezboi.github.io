"""
licensing/license_manager.py — Offline premium licensing with a
development unlock.

Commercial model
----------------
  FREE      — discovery, device list, vendor lookup
  PRO       — port scanning, fingerprinting, security audit, monitoring, reports
  ULTIMATE  — everything in PRO + deep profiles, mDNS/UPnP enrichment,
              webhook alerts, PDF pipeline hooks

Keys
----
AetherScan keys are offline-verifiable:  AETH-XXXX-XXXX-<TIER>  followed by a
checksum group derived from a keyed hash of the preceding groups. No server
call, no telemetry, no activation lock-in.

Development unlock
------------------
For testing, QA and store review, `--dev` (or "license_mode": "development"
in config.json, or the well-known key AETHER-DEV-2026) upgrades the session
to ULTIMATE and clearly brands the UI as a development build. A shipped
production package simply omits these switches, and the same binary then
enforces real keys.

Trial
-----
First launch starts a 14-day PRO trial (timestamp stored HMAC-signed in
data/license.bin so casual tampering is detectable).
"""

from __future__ import annotations

import hashlib
import hmac
import json
import os
import secrets
import time
import urllib.error
import urllib.request
from typing import Optional

_K = b"aetherscan-lumen-v1-offline-signing-key-2026"

TIERS = ("free", "pro", "ultimate")
_TIER_RANK = {"free": 0, "pro": 1, "ultimate": 2}

# feature-key -> minimum tier required
FEATURES = {
    "discovery": "free",
    "device_list": "free",
    "vendor_lookup": "free",
    "port_scan_quick": "free",
    "port_scan_standard": "pro",
    "port_scan_deep": "ultimate",
    "fingerprinting": "pro",
    "mdns_upnp_enrichment": "ultimate",
    "security_audit": "pro",
    "credential_audit": "pro",
    "monitoring": "pro",
    "reports": "pro",
    "history": "pro",
    "tools_basic": "pro",
    "tools_tcp": "ultimate",
    "deep_monitor": "ultimate",
    "deep_sweep": "ultimate",
    "webhook_alerts": "ultimate",
    "unlimited_scans": "pro",
    "priority_support": "ultimate",
}

# Scans per day on the free tier (soft conversion funnel; generous on purpose).
FREE_SCAN_DAILY_CAP = 8

DEV_KEY = "AETHER-DEV-2026"
TRIAL_DAYS = 14
_KEY_ALPHABET = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"


class LicenseManager:
    """Tracks entitlement for this install."""

    def __init__(self, data_dir: str, dev_mode: bool = False,
                 config_path: Optional[str] = None,
                 license_server: Optional[str] = None):
        self.data_dir = data_dir
        self.store_path = os.path.join(data_dir, "license.bin")
        self._dev_mode = bool(dev_mode)
        self.license_server = license_server or ""
        self._store = self._load_store()
        if not self._store.get("trial_started") and not self._dev_mode:
            self._store["trial_started"] = time.time()
            self._save_store()
        self.config_path = config_path
        self._machine_id = None

    def _install_id(self) -> str:
        """Stable per-install id sent with cloud redemptions (one-time keys)."""
        if self._machine_id:
            return self._machine_id
        path = os.path.join(self.data_dir, "install.id")
        try:
            with open(path, "r", encoding="utf-8") as handle:
                self._machine_id = handle.read().strip()
                if self._machine_id:
                    return self._machine_id
        except OSError:
            pass
        self._machine_id = secrets.token_hex(16)
        try:
            os.makedirs(self.data_dir, exist_ok=True)
            with open(path, "w", encoding="utf-8") as handle:
                handle.write(self._machine_id)
        except OSError:
            pass
        return self._machine_id

    def _cloud_redeem(self, key: str) -> Optional[dict]:
        """POST the key to the license server for one-time atomic redemption.
        Returns None to proceed (offline fallback), or a rejection payload."""
        if not self.license_server:
            return None
        url = self.license_server.rstrip("/") + "/keys/redeem"
        body = {"key": key, "machine_id": self._install_id()}
        try:
            req = urllib.request.Request(
                url, data=json.dumps(body).encode("utf-8"),
                headers={"Content-Type": "application/json"}, method="POST")
            with urllib.request.urlopen(req, timeout=8.0) as resp:
                result = json.loads(resp.read(4096).decode("utf-8"))
        except urllib.error.HTTPError as exc:
            try:
                result = json.loads(exc.read(2048).decode("utf-8"))
            except Exception:
                result = {}
            if result.get("ok") is False:
                return {"error": result.get("error", "license server rejected the key"),
                        "status": exc.code}
            return None
        except Exception:
            return None  # unreachable → fail open, but skipped cloud check
        if result.get("ok"):
            return None
        return {"error": result.get("error", "unknown license server error"),
                "status": result.get("status", 400)}

    # -- public API ---------------------------------------------------------------

    @property
    def tier(self) -> str:
        if self._dev_mode:
            return "ultimate"
        key = self._store.get("key")
        if key and self.key_valid(key):
            return self._tier_of(key)
        if self.trial_days_left() > 0:
            return "pro"
        return "free"

    @property
    def is_development(self) -> bool:
        return self._dev_mode

    def status(self) -> dict:
        tier = self.tier
        days_left = self.trial_days_left()
        key_active = bool(self._store.get("key")) and self.key_valid(self._store.get("key", ""))
        return {
            "tier": tier,
            "tier_label": tier.capitalize(),
            "development": self._dev_mode,
            "trial_days_left": max(0, days_left) if not self._dev_mode else None,
            "trial_active": (not self._dev_mode) and (not key_active) and days_left > 0,
            "licensed_to": self._store.get("licensed_to", ""),
            "features": {feature: self._rank(tier) >= self._rank(min_tier)
                         for feature, min_tier in FEATURES.items()},
            "scans_today": self._store.get("scan_counter", {}).get(
                time.strftime("%Y-%m-%d"), 0),
            "scan_cap": FREE_SCAN_DAILY_CAP if tier == "free" else None,
        }

    def allows(self, feature: str) -> bool:
        min_tier = FEATURES.get(feature, "ultimate")
        return self._rank(self.tier) >= self._rank(min_tier)

    def gate(self, feature: str) -> Optional[dict]:
        """Return a paywall payload when blocked, else None."""
        if self.allows(feature):
            return None
        min_tier = FEATURES.get(feature, "ultimate")
        return {
            "locked": True,
            "feature": feature,
            "required_tier": min_tier,
            "current_tier": self.tier,
            "message": f"'{_FEATURE_LABELS.get(feature, feature)}' requires "
                       f"AetherScan {min_tier.capitalize()}.",
            "development_hint": "Run with --dev during development to unlock everything.",
        }

    def activate(self, key: str, licensed_to: str = "") -> dict:
        key = (key or "").strip().upper()
        if key == DEV_KEY:
            self._dev_mode = True
            return {"ok": True, "tier": "ultimate", "development": True,
                    "message": "Development unlock active — all premium features enabled."}
        if not self.key_valid(key):
            if LicenseManager.format_ok(key):
                message = ("Key format is fine, but the check code doesn't match — "
                           "it was likely copied incorrectly. Re-check the last 4 "
                           "characters, or generate the key again.")
            else:
                message = ("That key doesn't look right. Expected format: "
                           "AETH-XXXX-XXXX-PRO-XXXX (or AETH-XXXX-XXXX-ULTI-XXXX).")
            return {"ok": False, "message": message}
        tier = self._tier_of(key)
        # One-time enforcement lives in the cloud when a license server is set.
        rejected = self._cloud_redeem(key)
        if rejected:
            self._store.pop("key", None)
            return {"ok": False,
                    "message": rejected.get("error", "license server rejected the key")}
        self._store["key"] = key
        self._store["licensed_to"] = licensed_to or "Licensee"
        self._save_store()
        return {"ok": True, "tier": tier, "development": False,
                "message": f"AetherScan {tier.capitalize()} activated. Thank you!"}

    def deactivate(self) -> None:
        self._store.pop("key", None)
        self._save_store()

    def count_scan(self) -> None:
        today = time.strftime("%Y-%m-%d")
        counter = self._store.setdefault("scan_counter", {})
        if counter.get("_day") != today:
            counter = {"_day": today, today: 0}
            self._store["scan_counter"] = counter
        counter[today] = counter.get(today, 0) + 1
        self._save_store()

    def scans_used_today(self) -> int:
        counter = self._store.get("scan_counter", {})
        return counter.get(time.strftime("%Y-%m-%d"), 0)

    def scan_quota_remaining(self) -> Optional[int]:
        if self.tier != "free":
            return None
        return max(0, FREE_SCAN_DAILY_CAP - self.scans_used_today())

    def trial_days_left(self) -> int:
        started = self._store.get("trial_started")
        if not started:
            return TRIAL_DAYS
        elapsed_days = (time.time() - started) / 86400.0
        return max(0, TRIAL_DAYS - int(elapsed_days))

    # -- key math -----------------------------------------------------------------

    @staticmethod
    def generate_key(tier: str = "pro") -> str:
        """Mint a valid key (used by our packaging tooling / store backend)."""
        tier = tier.upper() if tier.upper() in ("PRO", "ULTIMATE") else "PRO"
        groups = ["AETH"] + [
            "".join(secrets.choice(_KEY_ALPHABET) for _ in range(4))
            for _ in range(2)
        ] + [tier[:4]]
        key = "-".join(groups)
        return key + "-" + LicenseManager._checksum_group(key)

    @staticmethod
    def key_valid(key: str) -> bool:
        parts = (key or "").strip().upper().split("-")
        if len(parts) != 5 or parts[0] != "AETH":
            return False
        body = "-".join(parts[:4])
        return hmac.compare_digest(LicenseManager._checksum_group(body), parts[4])

    @staticmethod
    def format_ok(key: str) -> bool:
        """True when the key is structurally well-formed (check code unchecked)."""
        import re as _re
        parts = (key or "").strip().upper().split("-")
        if len(parts) != 5 or parts[0] != "AETH":
            return False
        if parts[3] not in ("PRO", "ULTI"):
            return False
        return all(_re.fullmatch(r"[A-Z0-9]{4}", p) for p in (parts[1], parts[2], parts[4]))

    @staticmethod
    def _checksum_group(body: str) -> str:
        digest = hmac.new(_K, body.encode("utf-8"), hashlib.sha256).hexdigest()
        chars = []
        i = 0
        while len(chars) < 4:
            nibble = int(digest[i % len(digest)], 16)
            chars.append(_KEY_ALPHABET[(nibble + i) % len(_KEY_ALPHABET)])
            i += 1
        return "".join(chars)

    @staticmethod
    def _tier_of(key: str) -> str:
        tier_group = key.strip().upper().split("-")[3] if key else ""
        if tier_group.startswith("ULT"):
            return "ultimate"
        return "pro"

    @staticmethod
    def _rank(tier: str) -> int:
        return _TIER_RANK.get(tier, 0)

    # -- persistence ----------------------------------------------------------------

    def _load_store(self) -> dict:
        if os.path.exists(self.store_path):
            try:
                with open(self.store_path, "rb") as handle:
                    blob = handle.read()
                payload, _, sig = blob.partition(b"|")
                if hmac.compare_digest(self._sign(payload), sig.decode("utf-8", "replace")):
                    return json.loads(payload.decode("utf-8"))
            except Exception:
                pass
        return {}

    def _save_store(self) -> None:
        os.makedirs(self.data_dir, exist_ok=True)
        payload = json.dumps(self._store).encode("utf-8")
        with open(self.store_path, "wb") as handle:
            handle.write(payload + b"|" + self._sign(payload).encode("utf-8"))

    @staticmethod
    def _sign(payload: bytes) -> str:
        return hmac.new(_K, payload, hashlib.sha256).hexdigest()


_FEATURE_LABELS = {
    "port_scan_standard": "Standard port profiles",
    "port_scan_deep": "Deep port profiles",
    "fingerprinting": "Device fingerprinting",
    "mdns_upnp_enrichment": "mDNS & UPnP enrichment",
    "security_audit": "Security audit",
    "credential_audit": "Factory-credential audit",
    "monitoring": "Continuous monitoring",
    "reports": "Report exports",
    "history": "Device history",
    "webhook_alerts": "Webhook alerts",
    "unlimited_scans": "Unlimited scans",
}
